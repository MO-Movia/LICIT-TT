import TableColorCommand from './tableColorCommand';
class TableBorderColorCommand extends TableColorCommand {
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    constructor() {
        super('borderColor');
    }
}
export default TableBorderColorCommand;
