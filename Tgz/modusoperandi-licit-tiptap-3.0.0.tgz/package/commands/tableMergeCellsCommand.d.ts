import { EditorView } from 'prosemirror-view';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { Editor } from '@tiptap/react';
declare class TableMergeCellsCommand extends UICommand {
    waitForUserInput(state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, event?: any): Promise<any>;
    executeWithUserInput(state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, inputs?: any): boolean;
    cancel(): void;
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    isEnabled: (_state: EditorState) => boolean;
    getEditor: () => Editor;
    execute: (state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
}
export default TableMergeCellsCommand;
