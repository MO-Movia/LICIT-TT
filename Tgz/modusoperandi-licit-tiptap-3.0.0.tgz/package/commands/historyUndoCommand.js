import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class HistoryUndoCommand extends UICommand {
    getEditor = () => {
        return UICommand.prototype.editor;
    };
    isEnabled = (_state) => {
        const history = _state.history$;
        if (history.done.eventCount === 0) {
            return false;
        }
        else {
            return true;
        }
    };
    execute = (_state, _dispatch, _view) => {
        return this.getEditor().commands.undo();
    };
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default HistoryUndoCommand;
