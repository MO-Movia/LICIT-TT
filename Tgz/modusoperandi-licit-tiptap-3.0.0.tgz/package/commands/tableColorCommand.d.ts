import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { Editor } from '@tiptap/react';
declare class TableColorCommand extends UICommand {
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    _popUp: any;
    attribute: any;
    constructor(attribute: string);
    shouldRespondToUIEvent: (e: React.SyntheticEvent | MouseEvent) => boolean;
    isEnabled: (_state: EditorState) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, event?: React.SyntheticEvent) => Promise<PromiseConstructor>;
    getEditor: () => Editor;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, hex?: string) => boolean;
    cancel(): void;
}
export default TableColorCommand;
