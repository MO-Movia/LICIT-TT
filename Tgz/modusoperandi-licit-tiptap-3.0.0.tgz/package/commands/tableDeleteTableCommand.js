import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TableDeleteTableCommand extends UICommand {
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    getEditor = () => {
        return UICommand.prototype.editor;
    };
    isEnabled = (_state) => {
        return true;
    };
    execute = (_state, _dispatch, _view) => {
        return this.getEditor().commands.deleteTable();
    };
}
export default TableDeleteTableCommand;
