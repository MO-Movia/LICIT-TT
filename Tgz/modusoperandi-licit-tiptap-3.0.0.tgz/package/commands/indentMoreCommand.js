import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class IndentMoreCommand extends UICommand {
    getEditor = () => {
        return UICommand.prototype.editor;
    };
    isEnabled = (_state) => {
        return true;
    };
    execute = (_state, _dispatch, _view) => {
        return this.getEditor().commands.indent();
    };
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default IndentMoreCommand;
