import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class HistoryRedoCommand extends UICommand {
    getEditor = () => {
        return UICommand.prototype.editor || null;
    };
    isEnabled = (_state) => {
        const history = _state.history$;
        return history?.undone?.eventCount > 0 || false;
    };
    execute = (_state, _dispatch, _view) => {
        const editor = this.getEditor();
        if (!editor) {
            console.error('Editor instance is not available.');
            return false;
        }
        return editor.commands.redo();
    };
    waitForUserInput = () => Promise.resolve(null);
    executeWithUserInput = () => false;
    cancel = () => {
        console.log('Cancel called on HistoryRedoCommand.');
    };
    executeCustom = (state, tr) => tr;
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default HistoryRedoCommand;
