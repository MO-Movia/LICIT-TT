import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { Editor } from '@tiptap/react';
declare class HistoryRedoCommand extends UICommand {
    getEditor: () => Editor | null;
    isEnabled: (_state: EditorState) => boolean;
    execute: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    waitForUserInput: () => Promise<null>;
    executeWithUserInput: () => boolean;
    cancel: () => void;
    executeCustom: (state: EditorState, tr: Transform) => Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
}
export default HistoryRedoCommand;
