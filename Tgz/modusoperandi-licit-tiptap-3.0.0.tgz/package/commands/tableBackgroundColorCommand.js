import TableColorCommand from './tableColorCommand';
class TableBackgroundColorCommand extends TableColorCommand {
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    constructor() {
        super('backgroundColor');
    }
}
export default TableBackgroundColorCommand;
