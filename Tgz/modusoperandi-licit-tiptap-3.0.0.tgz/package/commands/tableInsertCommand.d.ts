import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import type { TableGridSizeEditorState } from '../ui/tableGridSizeEditor';
import { Editor } from '@tiptap/react';
declare class TableInsertCommand extends UICommand {
    cancel(): void;
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    _popUp: any;
    shouldRespondToUIEvent: (e: React.SyntheticEvent | MouseEvent) => boolean;
    isEnabled: (state: EditorState) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, event?: React.SyntheticEvent) => Promise<PromiseConstructor>;
    getEditor: () => Editor;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, inputs?: TableGridSizeEditorState) => boolean;
}
export default TableInsertCommand;
