import { EditorState } from 'prosemirror-state';
import { MarkToggleCommand } from '@modusoperandi/licit-ui-commands';
declare class MarkToggleCommandEx extends MarkToggleCommand {
    constructor(markName: string);
    isEnabled: (_state: EditorState) => boolean;
}
export default MarkToggleCommandEx;
