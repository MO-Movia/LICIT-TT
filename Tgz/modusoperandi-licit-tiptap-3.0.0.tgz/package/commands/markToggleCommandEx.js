import { MarkToggleCommand } from '@modusoperandi/licit-ui-commands';
class MarkToggleCommandEx extends MarkToggleCommand {
    constructor(markName) {
        super(markName);
    }
    isEnabled = (_state) => {
        return true;
    };
}
export default MarkToggleCommandEx;
