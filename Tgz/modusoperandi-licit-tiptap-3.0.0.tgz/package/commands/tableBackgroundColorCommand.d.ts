import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import TableColorCommand from './tableColorCommand';
declare class TableBackgroundColorCommand extends TableColorCommand {
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    constructor();
}
export default TableBackgroundColorCommand;
