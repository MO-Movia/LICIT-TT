import { AllSelection, TextSelection } from 'prosemirror-state';
import { clearMarks, clearHeading } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class MarksClearCommand extends UICommand {
    isActive = (_state) => {
        return false;
    };
    isEnabled = (state) => {
        const { selection } = state;
        return (!selection.empty &&
            (selection instanceof TextSelection || selection instanceof AllSelection));
    };
    execute = (state, dispatch, _view) => {
        let tr = clearMarks(state.tr.setSelection(state.selection), state.schema);
        // [FS] IRAD-948 2021-02-22
        // Clear Header formatting
        tr = clearHeading(tr, state.schema);
        if (dispatch && tr.docChanged) {
            dispatch(tr);
            return true;
        }
        return false;
    };
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default MarksClearCommand;
