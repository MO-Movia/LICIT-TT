import nullthrows from 'nullthrows';
import { atAnchorRight, createPopUp, RuntimeService,
// ColorEditor
 } from '@modusoperandi/licit-ui-commands';
import { ColorEditor } from '@modusoperandi/color-picker';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TableColorCommand extends UICommand {
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    _popUp = null;
    attribute = null;
    constructor(attribute) {
        super();
        this.attribute = attribute;
    }
    shouldRespondToUIEvent = (e) => {
        return e.type === UICommand.EventType.MOUSEENTER;
    };
    isEnabled = (_state) => {
        return true;
    };
    waitForUserInput = (_state, _dispatch, _view, event) => {
        // replaced any with PromiseConstructor seems to not cause any errors
        if (this._popUp) {
            return Promise.resolve(undefined);
        }
        const target = nullthrows(event).currentTarget;
        if (!(target instanceof HTMLElement)) {
            return Promise.resolve(undefined);
        }
        const anchor = event ? event.currentTarget : null;
        return new Promise((resolve) => {
            this._popUp = createPopUp(ColorEditor, { hex: null, runtime: RuntimeService.Runtime, Textcolor: null }, {
                anchor,
                popUpId: 'mo-menuList-child',
                position: atAnchorRight,
                autoDismiss: true,
                onClose: (val) => {
                    if (this._popUp) {
                        this._popUp = null;
                        resolve(val);
                    }
                },
            });
        });
    };
    getEditor = () => {
        return UICommand.prototype.editor;
    };
    executeWithUserInput = (_state, _dispatch, _view, hex) => {
        if (hex !== undefined) {
            return this.getEditor().commands.setCellAttribute(this.attribute, hex);
        }
        return false;
    };
    cancel() {
        this._popUp && this._popUp.close(undefined);
    }
}
export default TableColorCommand;
