import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
declare class LinkSetURLCommand extends UICommand {
    _popUp: any;
    isEnabled: (state: EditorState) => boolean;
    waitForUserInput: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<PromiseConstructor>;
    executeWithUserInput: (state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, href?: string) => boolean;
    cancel(): void;
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
}
export default LinkSetURLCommand;
