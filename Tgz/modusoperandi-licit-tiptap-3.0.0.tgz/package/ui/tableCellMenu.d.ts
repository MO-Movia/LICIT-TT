import { EditorState, PluginView } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import CommandMenuButton from './commandMenuButton';
import '../styles/czi-table-cell-menu.css';
type TableCellMenuProps = {
    editorState: EditorState;
    editorView: EditorView;
    pluginView: PluginView;
    actionNode: Node;
};
declare class TableCellMenu extends React.PureComponent<TableCellMenuProps> {
    _menu: any;
    props: TableCellMenuProps;
    render(): React.ReactElement<CommandMenuButton>;
}
export default TableCellMenu;
