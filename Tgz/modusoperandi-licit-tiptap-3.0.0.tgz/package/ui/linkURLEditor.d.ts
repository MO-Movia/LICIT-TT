import * as React from 'react';
import PropTypes from 'prop-types';
import '../styles/czi-form.css';
import '../styles/czi-image-url-editor.css';
type LinkURLEditorProps = {
    href: any;
    close: (props?: any, propName?: string) => Error;
};
declare class LinkURLEditor extends React.PureComponent<LinkURLEditorProps> {
    static propsTypes: {
        href: PropTypes.Requireable<string>;
        close: (props: LinkURLEditorProps, propName: string) => Error;
    };
    state: {
        url: any;
    };
    render(): React.ReactElement<HTMLDivElement>;
    _onKeyDown: (e: React.KeyboardEvent) => void;
    _onURLChange: (e: React.SyntheticEvent) => void;
    _cancel: () => void;
    _apply: () => void;
}
export default LinkURLEditor;
