import * as React from 'react';
import CommandMenuButton from './commandMenuButton';
import { TABLE_COMMANDS_GROUP } from './editorToolbarConfig';
import Icon from './icon';
import '../styles/czi-table-cell-menu.css';
class TableCellMenu extends React.PureComponent {
    _menu = null;
    render() {
        // const { editorState, editorView } = this.props;
        const { editorState, editorView, pluginView, actionNode } = this.props;
        let cmdGrps = null;
        if (pluginView['_menu']) {
            cmdGrps = pluginView['_menu'](editorState, actionNode, TABLE_COMMANDS_GROUP);
        }
        if (!cmdGrps) {
            cmdGrps = TABLE_COMMANDS_GROUP;
        }
        return (React.createElement(CommandMenuButton, { className: "czi-table-cell-menu", commandGroups: cmdGrps, dispatch: editorView.dispatch, editorState: editorState, editorView: editorView, icon: Icon.get('icon_edit'), title: "Edit" }));
    }
}
export default TableCellMenu;
