import * as React from 'react';
import '../styles/czi-editor-frameset.css';
export type EditorFramesetProps = {
    body?: React.ReactElement;
    className?: string;
    embedded?: boolean;
    header?: React.ReactElement;
    height?: string | number;
    toolbarPlacement?: 'header' | 'body' | null;
    toolbar?: React.ReactElement;
    width?: string | number;
};
export declare const FRAMESET_BODY_CLASSNAME = "czi-editor-frame-body";
declare class EditorFrameset extends React.PureComponent {
    static contextType: React.Context<string>;
    props: EditorFramesetProps;
    render(): React.ReactElement;
}
export default EditorFrameset;
