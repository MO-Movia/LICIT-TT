import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import * as React from 'react';
import { CustomButton } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import '../styles/czi-custom-menu-button.css';
import { EditorViewEx } from '../constants';
export interface Arr {
    [key: string]: UICommand;
}
type PropsType = {
    className?: string;
    commandGroups: Array<any>;
    disabled?: boolean;
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView: EditorViewEx;
    icon?: string | React.ReactElement | null;
    label?: string | React.ReactElement | null;
    title?: string;
    sub?: boolean;
    theme?: string;
};
type StateType = {
    expanded: boolean;
};
declare class CommandMenuButton extends React.PureComponent<PropsType, StateType> {
    props: PropsType;
    static contextType: React.Context<string>;
    _menu: any;
    _id: string;
    state: {
        expanded: boolean;
    };
    render(): React.ReactElement<CustomButton>;
    componentWillUnmount(): void;
    _onClick: () => void;
    _hideMenu: () => void;
    _showMenu: () => void;
    _onCommand: () => void;
    _onClose: () => void;
}
export default CommandMenuButton;
