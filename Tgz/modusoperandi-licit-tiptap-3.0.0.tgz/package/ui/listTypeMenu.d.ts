import * as React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import '../styles/listType.css';
declare class ListTypeMenu extends React.PureComponent {
    _activeCommand: UICommand;
    props: {
        className?: string;
        commandGroups: Array<any>;
        disabled?: boolean;
        dispatch: (tr: Transform) => void;
        editorState: EditorState;
        editorView: EditorView;
        onCommand: any;
        icon?: string | React.ReactElement | null;
        label?: string | React.ReactElement | null;
        title?: string;
        theme?: string;
    };
    _menu: any;
    _id: string;
    state: {
        expanded: boolean;
    };
    render(): JSX.Element;
    _onUIEnter: (command: UICommand, event: React.SyntheticEvent) => void;
    _execute: (command: UICommand, e: React.SyntheticEvent) => void;
}
export default ListTypeMenu;
