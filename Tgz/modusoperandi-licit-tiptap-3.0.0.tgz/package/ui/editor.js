import { preLoadFonts } from '../specs/fontTypeMarkSpec';
import '../styles/czi-editor.css';
// FS IRAD-988 2020-06-18
preLoadFonts();
