import * as React from 'react';
import '../styles/czi-custom-menu.css';
import '../styles/czi-custom-scrollbar.css';
import cx from 'classnames';
class CustomMenu extends React.Component {
    render() {
        const { children, isHorizontal, theme } = this.props;
        const menuClasssName = 'czi-custom-menu ' + theme;
        const buttonClassName = cx(menuClasssName + ' czi-custom-scrollbar', {
            'czi-horizontal-menu': isHorizontal
        });
        return (
        // <div className="czi-custom-menu czi-custom-scrollbar">
        //   {this.props.children}
        // </div>
        React.createElement("div", { className: buttonClassName }, children));
    }
}
export default CustomMenu;
