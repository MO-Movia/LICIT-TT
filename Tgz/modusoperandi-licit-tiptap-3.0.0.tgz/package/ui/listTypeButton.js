// [FS] IRAD-1039 2020-09-23
// Command button to handle different type of list types
// Need to add Icons instead of label
import cx from 'classnames';
import * as React from 'react';
import { CustomButton, createPopUp, ThemeContext } from '@modusoperandi/licit-ui-commands';
import uuid from './uuid';
import ListTypeMenu from './listTypeMenu';
import '../styles/czi-custom-menu-button.css';
class ListTypeButton extends React.PureComponent {
    static contextType = ThemeContext;
    _menu = null;
    _id = uuid();
    state = {
        expanded: false,
    };
    render() {
        const { className, label, commandGroups, icon, disabled, title, theme } = this.props;
        const enabled = !disabled &&
            commandGroups.some((group, _ii) => {
                return Object.keys(group).some((_label) => {
                    let disabledVal = true;
                    try {
                        disabledVal = false;
                    }
                    catch (ex) {
                        disabledVal = false;
                    }
                    return !disabledVal;
                });
            });
        const { expanded } = this.state;
        const buttonClassName = cx(className, {
            'czi-custom-menu-button': true,
            expanded,
        });
        // const theme = this.context;
        return (React.createElement(CustomButton, { className: buttonClassName, disabled: !enabled, icon: icon, id: this._id, label: label, onClick: this._onClick, theme: theme, title: title }));
    }
    componentWillUnmount() {
        this._hideMenu();
    }
    _onClick = () => {
        const expanded = !this.state.expanded;
        this.setState({
            expanded,
        });
        expanded ? this._showMenu() : this._hideMenu();
    };
    _hideMenu = () => {
        const menu = this._menu;
        this._menu = null;
        menu && menu.close();
    };
    _showMenu = () => {
        const menu = this._menu;
        const menuProps = {
            ...this.props,
            onCommand: this._onCommand,
        };
        if (menu) {
            menu.update(menuProps);
        }
        else {
            this._menu = createPopUp(ListTypeMenu, menuProps, {
                anchor: document.getElementById(this._id),
                onClose: this._onClose,
            });
        }
    };
    _onCommand = () => {
        this.setState({ expanded: false });
        this._hideMenu();
    };
    _onClose = () => {
        if (this._menu) {
            this.setState({ expanded: false });
            this._menu = null;
        }
    };
}
export default ListTypeButton;
