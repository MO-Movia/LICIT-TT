import '../styles/czi-custom-radio-button.css';
import { PointerSurface, preventEventDefault, } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
import cx from 'classnames';
import uuid from './uuid';
class CustomRadioButton extends React.PureComponent {
    _name = uuid();
    render() {
        const { title, className, checked, label, inline, name, onSelect, disabled, ...pointerProps } = this.props;
        const klass = cx(className, 'czi-custom-radio-button', {
            checked: checked,
            inline: inline,
        });
        return (React.createElement(PointerSurface, { ...pointerProps, className: klass, disabled: disabled, onClick: onSelect, title: title || label },
            React.createElement("input", { checked: checked, className: "czi-custom-radio-button-input", disabled: disabled, name: name || this._name, onChange: preventEventDefault, tabIndex: disabled ? null : 0, type: "radio" }),
            React.createElement("span", { className: "czi-custom-radio-button-icon" }),
            React.createElement("span", { className: "czi-custom-radio-button-label" }, label)));
    }
}
export default CustomRadioButton;
