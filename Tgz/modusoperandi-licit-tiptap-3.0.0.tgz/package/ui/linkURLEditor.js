import * as React from 'react';
import PropTypes from 'prop-types';
import sanitizeURL from '../sanitizeURL';
import { CustomButton, preventEventDefault, } from '@modusoperandi/licit-ui-commands';
import '../styles/czi-form.css';
import '../styles/czi-image-url-editor.css';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
const BAD_CHARACTER_PATTER = /\s/;
class LinkURLEditor extends React.PureComponent {
    // [FS] IRAD-1005 2020-07-07
    // Upgrade outdated packages.
    // To take care of the property type declaration.
    static propsTypes = {
        href: PropTypes.string,
        close: function (props, propName) {
            const fn = props[propName];
            if (!fn.prototype ||
                (typeof fn.prototype.constructor !== 'function' &&
                    fn.prototype.constructor.length !== 1)) {
                return new Error(propName + 'must be a function with 1 arg of type string');
            }
            return null;
        },
    };
    state = {
        url: this.props.href,
    };
    render() {
        const { href } = this.props;
        const { url } = this.state;
        const error = url ? BAD_CHARACTER_PATTER.test(url) : false;
        const theme = UICommand.theme;
        let label = 'Apply';
        let disabled = false;
        if (href) {
            label = url ? 'Apply' : 'Remove';
            disabled = error;
        }
        else {
            disabled = error || !url;
        }
        let klassName = "czi-image-url-editor " + theme;
        let klassName_form = "czi-form " + theme;
        return (React.createElement("div", { className: klassName },
            React.createElement("form", { className: klassName_form, onSubmit: preventEventDefault },
                React.createElement("fieldset", null,
                    React.createElement("legend", null, "Add a Link"),
                    React.createElement("input", { autoFocus: true, onChange: this._onURLChange, onKeyDown: this._onKeyDown, placeholder: "Paste a URL", spellCheck: false, type: "text", value: url || '' })),
                React.createElement("div", { className: "czi-form-buttons" },
                    React.createElement(CustomButton, { label: "Cancel", onClick: this._cancel }),
                    React.createElement(CustomButton, { active: true, disabled: disabled, label: label, onClick: this._apply })))));
    }
    _onKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            this._apply();
        }
    };
    _onURLChange = (e) => {
        const inputEle = e.target;
        if (inputEle) {
            const url = inputEle.value;
            this.setState({
                url,
            });
        }
    };
    _cancel = () => {
        this.props.close();
    };
    _apply = () => {
        const { url } = this.state;
        if (url && !BAD_CHARACTER_PATTER.test(url)) {
            this.props.close(sanitizeURL(url));
        }
    };
}
export default LinkURLEditor;
