import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { CustomButton } from '@modusoperandi/licit-ui-commands';
import '../styles/czi-custom-menu-button.css';
type ListTypeButtonType = {
    className?: string;
    commandGroups: Array<any>;
    disabled?: boolean;
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView: EditorView;
    icon?: string | React.ReactElement | null;
    label?: string | React.ReactElement | null;
    title?: string;
    theme?: string;
};
declare class ListTypeButton extends React.PureComponent<ListTypeButtonType> {
    static contextType: React.Context<string>;
    props: ListTypeButtonType;
    _menu: any;
    _id: string;
    state: {
        expanded: boolean;
    };
    render(): React.ReactElement<CustomButton>;
    componentWillUnmount(): void;
    _onClick: () => void;
    _hideMenu: () => void;
    _showMenu: () => void;
    _onCommand: () => void;
    _onClose: () => void;
}
export default ListTypeButton;
