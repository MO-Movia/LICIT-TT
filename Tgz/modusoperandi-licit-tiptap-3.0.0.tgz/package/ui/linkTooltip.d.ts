import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { CustomButton } from '@modusoperandi/licit-ui-commands';
import '../styles/czi-link-tooltip.css';
declare class LinkTooltip extends React.PureComponent {
    props: {
        editorView: EditorView;
        href: string;
        onCancel: (view: EditorView) => void;
        onEdit: (view: EditorView) => void;
        onRemove: (view: EditorView) => void;
    };
    _unmounted: boolean;
    state: {
        hidden: boolean;
    };
    render(): React.ReactElement<CustomButton>;
    _openLink: (href: string) => void;
}
export default LinkTooltip;
