import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import CommandMenuButton from './commandMenuButton';
export type editorType = EditorView & {
    disabled: boolean;
};
type PropsType = {
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView?: editorType;
};
export declare const FONT_PT_SIZES: number[];
declare class FontSizeCommandMenuButton extends React.PureComponent<PropsType> {
    props: PropsType;
    render(): React.ReactElement<CommandMenuButton>;
}
export default FontSizeCommandMenuButton;
