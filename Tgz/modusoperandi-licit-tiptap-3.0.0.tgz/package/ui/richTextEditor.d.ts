import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { Editor } from '@tiptap/react';
import EditorFrameset from './editorFrameset';
import type { EditorFramesetProps } from './editorFrameset';
import type { EditorProps } from './editor';
type EditorContainer = {
    editor?: Editor;
};
type RichTextEditorProps = EditorContainer & EditorFramesetProps & EditorProps & RichTextEditorState & {
    children?: any;
};
type RichTextEditorState = {
    editorView?: EditorView;
};
declare class RichTextEditor extends React.PureComponent<RichTextEditorProps, RichTextEditorState> {
    props: RichTextEditorProps;
    state: RichTextEditorState;
    _id: string;
    constructor(props: RichTextEditorProps, context: Record<string, unknown>);
    render(): React.ReactElement<EditorFrameset>;
    _dispatchTransaction: (tr: Transform) => void;
    _onReady: (editorView: EditorView) => void;
}
export default RichTextEditor;
