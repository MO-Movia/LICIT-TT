import * as React from 'react';
import { EditorContent } from '@tiptap/react';
import EditorFrameset from './editorFrameset';
import EditorToolbar from './editorToolbar';
import Frag from './frag';
import uuid from './uuid';
class RichTextEditor extends React.PureComponent {
    _id;
    constructor(props, context) {
        super(props, context);
        this._id = uuid();
        this.state = {
            contentHeight: NaN,
            contentOverflowHidden: false,
            editorView: null,
        };
    }
    render() {
        const { 
        //autoFocus,
        children, className, disabled, embedded, header, height, 
        //onChange,
        //nodeViews,
        //placeholder,
        readOnly, width, toolbarConfig } = this.props;
        const { editorState /*, runtime*/ } = this.props;
        const { editorView } = this.props;
        //Seybi : This causes delay in edit
        // this.props.editor.setEditable(!readOnly);
        const toolbar = !!readOnly === true ? null : (React.createElement(EditorToolbar, { disabled: disabled, dispatchTransaction: this._dispatchTransaction, editorState: editorState, editorView: editorView, readOnly: readOnly, toolbarConfig: toolbarConfig }));
        const body = (React.createElement(Frag, null,
            React.createElement(EditorContent, { editor: this.props.editor, height: height, width: width }),
            children));
        return (React.createElement(EditorFrameset, { body: body, className: className, embedded: embedded, header: header, height: height, toolbar: toolbar, width: width }));
    }
    _dispatchTransaction = (tr) => {
        this.props.editor.view.dispatch(tr);
    };
    _onReady = (editorView) => {
        if (editorView !== this.state.editorView) {
            this.setState({ editorView });
            const { onReady } = this.props;
            onReady && onReady(editorView);
        }
    };
}
export default RichTextEditor;
/*<Editor
          autoFocus={autoFocus}
          disabled={disabled}
          dispatchTransaction={this._dispatchTransaction}
          editorState={editorState}
          embedded={embedded}
          id={this._id}
          nodeViews={nodeViews}
          onChange={onChange}
          onReady={this._onReady}
          placeholder={placeholder}
          readOnly={readOnly}
          runtime={runtime}
        />*/
