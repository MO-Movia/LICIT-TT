import * as React from 'react';
import '../styles/czi-frag.css';
class Frag extends React.Component {
    render() {
        return React.createElement("div", { className: "czi-frag" }, this.props.children);
    }
}
export default Frag;
