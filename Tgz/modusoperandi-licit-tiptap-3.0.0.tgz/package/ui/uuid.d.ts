import '../styles/czi-custom-button.css';
export default function uuid(): string;
