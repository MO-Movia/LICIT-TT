import '../styles/czi-custom-menu-item.css';
import { CustomButton, TextAlignCommand, ThemeContext, } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
class CustomMenuItemSeparator extends React.PureComponent {
    render() {
        return React.createElement("div", { className: "czi-custom-menu-item-separator" });
    }
}
class CustomMenuItem extends React.PureComponent {
    static Separator = CustomMenuItemSeparator;
    static contextType = ThemeContext;
    render() {
        // [FS] IRAD-1044 2020-09-22
        // Added a new class to adjust the width of the custom style menu dropdown.
        // const theme = this.context;
        // const className = 'czi-custom-menu-item';
        let className = 'czi-custom-menu-item ' + this.props.theme;
        if (this.props.value instanceof TextAlignCommand) {
            const command = this.props.value;
            if (command?._alignment) {
                className = 'czi-custom-menu-item-button ' + this.props.theme;
            }
        }
        return (React.createElement(CustomButton, { ...this.props, className: className, theme: this.props.theme }));
    }
}
export default CustomMenuItem;
