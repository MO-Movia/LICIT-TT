import * as React from 'react';
import '../styles/czi-table-grid-size-editor.css';
type TableGridSizeEditorProps = {
    close?: (val: TableGridSizeEditorState) => void;
    x?: any;
    y?: any;
    selected?: any;
};
export type TableGridSizeEditorState = {
    cols: number;
    rows: number;
};
declare class TableGridSizeEditor extends React.PureComponent<TableGridSizeEditorProps, TableGridSizeEditorState> {
    _ex: number;
    _ey: number;
    _mx: number;
    _my: number;
    _rafID: number;
    _ref: any;
    _entered: boolean;
    props: {
        close: (val: TableGridSizeEditorState) => void;
    };
    state: TableGridSizeEditorState;
    componentWillUnmount(): void;
    render(): React.ReactElement;
    _onRef: (ref: React.ReactInstance) => void;
    _onMouseEnter: (e: React.MouseEvent) => void;
    _onMouseMove: (e: MouseEvent) => void;
    _updateGridSize: () => void;
    _onMouseDown: (e: React.SyntheticEvent) => void;
}
export default TableGridSizeEditor;
