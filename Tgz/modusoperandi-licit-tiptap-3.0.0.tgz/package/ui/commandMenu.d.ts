import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import CustomMenuItem from './customMenuItem';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import CommandMenuButton, { Arr } from './commandMenuButton';
type PropsType = {
    commandGroups: Array<Arr>;
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView?: EditorView;
    onCommand?: () => void;
    title?: string;
    theme?: string;
};
declare class CommandMenu extends React.PureComponent<PropsType> {
    _activeCommand?: UICommand;
    props: PropsType;
    render(): React.ReactElement;
    _renderCustomMenuItem: (label: string, command: UICommand, editorState: EditorState, icon: any, theme: string) => React.ReactElement<CustomMenuItem>;
    _renderMenuButton: (label: string, commandGroups: Array<Arr>, theme: string) => React.ReactElement<CommandMenuButton>;
    _onUIEnter: (command: UICommand, event: React.SyntheticEvent) => void;
    _execute: (command: UICommand, e: React.SyntheticEvent) => void;
}
export default CommandMenu;
