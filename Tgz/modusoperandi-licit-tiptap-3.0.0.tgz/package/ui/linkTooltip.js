import * as React from 'react';
import scrollIntoView from 'smooth-scroll-into-view-if-needed';
import sanitizeURL from '../sanitizeURL';
import { CustomButton } from '@modusoperandi/licit-ui-commands';
import '../styles/czi-link-tooltip.css';
function isBookMarkHref(href) {
    return !!href && href.indexOf('#') === 0 && href.length >= 2;
}
class LinkTooltip extends React.PureComponent {
    _unmounted = false;
    state = {
        hidden: false,
    };
    render() {
        const { href, editorView, onEdit, onRemove } = this.props;
        // [FS] IRAD-1013 2020-07-09
        // Change button in "Apply Link" missing in LICIT.
        return (React.createElement("div", { className: "czi-link-tooltip" },
            React.createElement("div", { className: "czi-link-tooltip-body" },
                React.createElement("div", { className: "czi-link-tooltip-row" },
                    React.createElement(CustomButton, { className: "czi-link-tooltip-href", label: href, onClick: this._openLink, title: href, value: href }),
                    React.createElement(CustomButton, { label: "Change", onClick: onEdit, value: editorView }),
                    React.createElement(CustomButton, { label: "Remove", onClick: onRemove, value: editorView })))));
    }
    _openLink = (href) => {
        if (isBookMarkHref(href)) {
            const id = href.substr(1);
            const el = document.getElementById(id);
            if (el) {
                const { onCancel, editorView } = this.props;
                onCancel(editorView);
                (async () => {
                    // https://www.npmjs.com/package/smooth-scroll-into-view-if-needed
                    await scrollIntoView(el, {
                        scrollMode: 'if-needed',
                        // block: 'nearest',
                        // inline: 'nearest',
                        behavior: 'smooth',
                    });
                })();
            }
            return;
        }
        if (href) {
            window.open(sanitizeURL(href));
        }
    };
}
export default LinkTooltip;
