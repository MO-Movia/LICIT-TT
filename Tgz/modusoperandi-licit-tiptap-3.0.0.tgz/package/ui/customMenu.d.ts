import * as React from 'react';
import '../styles/czi-custom-menu.css';
import '../styles/czi-custom-scrollbar.css';
declare class CustomMenu extends React.Component<any, any> {
    render(): React.ReactElement;
}
export default CustomMenu;
