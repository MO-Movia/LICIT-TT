import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import ListTypeButton from './listTypeButton';
import { EditorViewEx } from '../constants';
declare class ListTypeCommandButton extends React.PureComponent {
    static contextType: React.Context<string>;
    props: {
        dispatch: (tr: Transform) => void;
        editorState: EditorState;
        editorView?: EditorViewEx;
    };
    render(): React.ReactElement<ListTypeButton>;
}
export default ListTypeCommandButton;
