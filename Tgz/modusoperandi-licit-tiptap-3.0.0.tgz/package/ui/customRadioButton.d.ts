import '../styles/czi-custom-radio-button.css';
import { PointerSurface, PointerSurfaceProps } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
declare class CustomRadioButton extends React.PureComponent {
    props: PointerSurfaceProps & {
        checked?: boolean;
        inline?: boolean;
        label?: string | React.ReactElement | null;
        name?: string;
        onSelect?: (val: any, e: React.SyntheticEvent) => void;
    };
    _name: string;
    render(): React.ReactElement<PointerSurface>;
}
export default CustomRadioButton;
