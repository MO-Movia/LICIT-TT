import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import CommandButton from './commandButton';
import CommandMenuButton, { Arr } from './commandMenuButton';
import { CustomButton } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import '../styles/czi-editor-toolbar.css';
import { EditorViewEx } from '../constants';
import { ToolbarMenuConfig } from '../types';
declare class EditorToolbar extends React.PureComponent {
    static contextType: React.Context<string>;
    _body: any;
    props: {
        disabled?: boolean;
        dispatchTransaction?: (tr: Transform) => void;
        editorState: EditorState;
        editorView: EditorViewEx;
        onReady?: (view: EditorView) => void;
        readOnly?: boolean;
        toolbarConfig?: ToolbarMenuConfig[];
    };
    state: {
        expanded: boolean;
        wrapped: boolean;
    };
    render(): React.ReactElement<CustomButton>;
    processMenuItems(menuItems: any): any;
    groupMenuItems: (items: any) => any[];
    _renderButtonsGroup: (group: Record<string, UICommand | React.PureComponent>, index: number) => React.ReactElement;
    _renderButtonsGroup_1: (group: any, index: number) => React.ReactElement;
    _renderMenuButton: (label: string, commandGroups: Array<Arr>) => React.ReactElement<CommandMenuButton>;
    _renderButton: (label: string, command: UICommand, theme: string) => React.ReactElement<CommandButton>;
    _onBodyRef: (ref: React.ReactInstance) => void;
    _checkIfContentIsWrapped: () => void;
    _toggleExpansion: (expanded: boolean) => void;
}
export default EditorToolbar;
