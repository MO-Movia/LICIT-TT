import * as React from 'react';
import '../styles/czi-frag.css';
declare class Frag extends React.Component<any, any> {
    render(): React.ReactNode;
}
export default Frag;
