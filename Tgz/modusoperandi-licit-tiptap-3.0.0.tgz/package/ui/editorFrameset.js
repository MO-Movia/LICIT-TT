import cx from 'classnames';
import * as React from 'react';
import { ThemeContext } from '@modusoperandi/licit-ui-commands';
import '../styles/czi-editor-frameset.css';
export const FRAMESET_BODY_CLASSNAME = 'czi-editor-frame-body';
function toCSS(val) {
    if (!val || val === 'auto') {
        // '', 0, null, false, 'auto' are all treated as undefined
        // instead of auto...
        return undefined;
    }
    if (isNaN(val)) {
        return `${val}`;
    }
    // return `${val}px`;
    return `${val}vh`;
}
class EditorFrameset extends React.PureComponent {
    static contextType = ThemeContext;
    render() {
        const { body, className, embedded, header, height, toolbarPlacement, toolbar, width, } = this.props;
        const mainStyle = {
            width: toCSS(width),
            height: toCSS(height),
        };
        const mainClassName = cx(className, {
            'czi-editor-frameset': true,
            // Layout is fixed when either width or height is set.
            'with-fixed-layout': mainStyle.width || mainStyle.height,
            embedded: embedded,
        });
        // added for theme
        const theme = this.context;
        const frameHeadClassName = cx('czi-editor-frame-head', theme);
        const toolbarHeader = toolbarPlacement === 'header' || !toolbarPlacement ? toolbar : null;
        const toolbarBody = toolbarPlacement === 'body' && toolbar;
        return (React.createElement("div", { className: mainClassName, style: mainStyle },
            React.createElement("div", { className: "czi-editor-frame-main" },
                React.createElement("div", { className: frameHeadClassName },
                    header,
                    toolbarHeader),
                React.createElement("div", { className: FRAMESET_BODY_CLASSNAME },
                    toolbarBody,
                    React.createElement("div", { className: "czi-editor-frame-body-scroll" }, body)),
                React.createElement("div", { className: "czi-editor-frame-footer" }))));
    }
}
export default EditorFrameset;
