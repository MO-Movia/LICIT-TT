import React from 'react';
import '../styles/czi-icon.css';
import '../styles/icon-font.css';
declare class Icon extends React.PureComponent {
    static contextType: React.Context<string>;
    state: {
        image1: any;
    };
    static get(type: string, title?: string, theme?: string): React.CElement<any, any>;
    props: {
        type: string;
        title?: string;
        theme?: string;
    };
    render(): React.ReactElement;
    componentDidMount(): Promise<void>;
}
export default Icon;
