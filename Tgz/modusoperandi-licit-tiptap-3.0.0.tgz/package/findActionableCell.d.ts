import { Node } from 'prosemirror-model';
import { EditorState } from 'prosemirror-state';
type Result = {
    node: Node;
    pos: number;
};
export default function findActionableCell(state: EditorState): Result | null;
export {};
