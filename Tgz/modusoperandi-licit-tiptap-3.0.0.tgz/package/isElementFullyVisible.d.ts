export default function isElementFullyVisible(el: HTMLElement): boolean;
