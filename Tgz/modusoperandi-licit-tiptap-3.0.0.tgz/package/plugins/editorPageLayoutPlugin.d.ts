import { Plugin } from 'prosemirror-state';
declare class EditorPageLayoutPlugin extends Plugin {
    constructor();
}
export default EditorPageLayoutPlugin;
