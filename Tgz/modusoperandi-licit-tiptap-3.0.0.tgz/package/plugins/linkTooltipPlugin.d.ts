import { EditorState, Plugin, TextSelection } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import '../styles/czi-pop-up.css';
import { EditorViewEx } from '../constants';
declare class LinkTooltipPlugin extends Plugin {
    constructor();
}
export declare class LinkTooltipView {
    _anchorEl: any;
    _popup: any;
    _editor: any;
    constructor(editorView: EditorView);
    update(view: EditorViewEx, _lastState: EditorState): void;
    destroy(): void;
    _onCancel: (view: EditorView) => void;
    _onClose: () => void;
    _onEdit: (view: EditorView) => void;
    _onRemove: (view: EditorView) => void;
    _onEditEnd: (view: EditorView, initialSelection: TextSelection, href?: string) => void;
}
export default LinkTooltipPlugin;
