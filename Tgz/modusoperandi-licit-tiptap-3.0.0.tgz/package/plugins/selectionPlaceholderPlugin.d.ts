import { EditorState, Plugin } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import '../styles/czi-selection-placeholder.css';
declare class SelectionPlaceholderPlugin extends Plugin {
    constructor();
}
export declare function showSelectionPlaceholder(state: EditorState, tr?: Transform): Transform;
export declare function hideSelectionPlaceholder(state: EditorState, tr?: Transform): Transform;
export default SelectionPlaceholderPlugin;
