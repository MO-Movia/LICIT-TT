import { Plugin } from 'prosemirror-state';
import '../styles/czi-pop-up.css';
declare class TableCellMenuPlugin extends Plugin {
    constructor();
}
export default TableCellMenuPlugin;
