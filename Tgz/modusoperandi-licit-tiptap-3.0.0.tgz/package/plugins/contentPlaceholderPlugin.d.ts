import { Plugin } from 'prosemirror-state';
import '../styles/czi-editor.css';
declare class ContentPlaceholderPlugin extends Plugin {
    constructor();
}
export default ContentPlaceholderPlugin;
