import { Plugin } from 'prosemirror-state';
export default function createTableResizingPlugin(): Plugin;
