import { Plugin } from 'prosemirror-state';
export declare function lookUpTableWrapper(event: Event): HTMLElement | null;
export declare function dispatchMouseEvent(type: string, clientX: number): void;
export declare function calculateMaxClientX(event: MouseEvent, targetTable: HTMLElement): number;
export default function createTableResizingPlugin(): Plugin;
