import { EditorState, Plugin, PluginKey } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { DecorationSet } from 'prosemirror-view';
import '../styles/czi-cursor-placeholder.css';
export declare const SPEC: {
    key: PluginKey<any>;
    state: {
        init(): DecorationSet;
        apply(tr: any, set: any): any;
    };
    props: {
        decorations: (state: any) => any;
    };
};
declare class CursorPlaceholderPlugin extends Plugin {
    constructor();
}
export declare function findCursorPlaceholderPos(state: EditorState): number | null;
export declare function showCursorPlaceholder(state: EditorState): Transform;
export declare function hideCursorPlaceholder(state: EditorState): Transform;
export default CursorPlaceholderPlugin;
