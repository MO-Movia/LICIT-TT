export declare function toClosestFontPtSize(styleValue: string): number;
