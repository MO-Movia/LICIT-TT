export default function canUseCSSFont(fontName: string): Promise<boolean>;
