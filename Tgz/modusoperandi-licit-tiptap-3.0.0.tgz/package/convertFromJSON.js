export function getEffectiveSchema(defaultSchema, defaultPlugins, plugins) {
    let editorSchema = defaultSchema;
    // Loads plugins and its corresponding schema in editor
    const effectivePlugins = defaultPlugins;
    if (plugins) {
        for (const p of plugins) {
            if (!effectivePlugins.includes(p)) {
                effectivePlugins.push(p);
                if ('getEffectiveSchema' in p) {
                    editorSchema = p.getEffectiveSchema(editorSchema);
                }
                if ('initKeyCommands' in p) {
                    effectivePlugins.push(p.initKeyCommands());
                }
            }
        }
    }
    return editorSchema;
}
