export default function toHexColor(source: string): string;
