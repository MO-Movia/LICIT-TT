import { ReactElement } from 'react';
import { Editor } from '@tiptap/core';
import { JSONContent } from '@tiptap/react';
import './styles/licit.css';
import { Plugin } from 'prosemirror-state';
import { Schema } from 'prosemirror-model';
import { EditorRuntime, ToolbarMenuConfig } from './types';
import { EditorView } from 'prosemirror-view';
/**
 * LICIT properties:
 *  docID {string} [] Collaborative Doument ID
 *  collabServiceURL {string} [/collaboration-service] Collaboration Service URL
 *  debug {boolean} [false] To enable/disable ProseMirror Debug Tools, available only in development.
 *  width {string} [100%] Width of the editor.
 *  height {string} [100%] Height of the editor.
 *  readOnly {boolean} [false] To enable/disable editing mode.
 *  onChange {@callback} [null] Fires after each significant change.
 *  @param data {JSON} Modified document data.
 *  onReady {@callback} [null] Fires when the editor is fully ready.
 *  @param ref {LICIT} Rerefence of the editor.
 *  data {JSON} [null] Document data to be loaded into the editor.
 *  disabled {boolean} [false] Disable the editor.
 *  embedded {boolean} [false] Disable/Enable inline behaviour.
 *  plugins [plugins] External ProseMirror Plugins into the editor.
 *  theme {string} [light] light/dark theme support for toolbar.
 */
export interface ChangeCB {
    (data: JSONContent, isEmpty: boolean, view: EditorView): void;
}
export interface ReadyCB {
    (ref: Editor): void;
}
export interface LicitProps {
    docID?: string;
    collabServiceURL?: string;
    debug?: boolean;
    width?: string;
    height?: string;
    readOnly?: boolean;
    data?: JSONContent;
    disabled?: boolean;
    embedded?: boolean;
    plugins?: Plugin[];
    runtime?: EditorRuntime;
    onChange?: ChangeCB;
    onReady?: ReadyCB;
    theme?: string;
    toolbarConfig?: ToolbarMenuConfig[];
}
export declare const configCollab: (docID: string, instanceID: string, ref: {
    collaboration: boolean;
    currentUser: Record<string, unknown>;
}, collabServiceURL: string) => void;
export declare const updateSpecAttrs: (i: number, collection: Array<unknown>, existingSchema: Schema, attrName: string) => void;
export declare const Licit: ({ docID, plugins, width, height, runtime, data, readOnly, embedded, collabServiceURL, debug, disabled, onChange, onReady, theme, toolbarConfig }: LicitProps) => ReactElement;
