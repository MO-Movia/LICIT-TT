type ScrollHandle = {
    dispose: () => void;
};
export default function bindScrollHandler(target: Element, callback: () => void): ScrollHandle;
export {};
