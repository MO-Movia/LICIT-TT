import { EditorState } from 'prosemirror-state';
export default function findActiveFontSize(state: EditorState): string;
