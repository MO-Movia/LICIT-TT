import { fromHTMlElement } from '@modusoperandi/licit-ui-commands';
export default function isElementFullyVisible(el) {
    const { x, y, w, h } = fromHTMlElement(el);
    // Only checks the top-left point.
    const nwEl = w && h ? el.ownerDocument.elementFromPoint(x + 1, y + 1) : null;
    if (!nwEl) {
        return false;
    }
    if (nwEl === el) {
        return true;
    }
    if (nwEl?.tagName === 'TABLE' && el?.tagName === 'TD') {
        return true;
    }
    if (el.contains(nwEl)) {
        return true;
    }
    return false;
}
