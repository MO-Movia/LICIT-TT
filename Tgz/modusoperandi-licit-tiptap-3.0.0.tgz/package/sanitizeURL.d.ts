export default function sanitizeURL(url?: string): string;
