import Keymap from 'browserkeymap';
export declare function tooltip(keymap?: Keymap): string | null;
export declare function findShortcutByKeymap(keymap: Keymap): string | null;
export declare const KEY_SPLIT_LIST_ITEM: any;
export declare const ALL_KEYS: any[];
export declare function findKeymapByDescription(description: string): Keymap | null;
export declare function findShortcutByDescription(description: string): string | null;
