export declare const TableCellEx: import("@tiptap/core").Node<import("@tiptap/extension-table-cell").TableCellOptions, any>;
