import { Extension } from '@tiptap/core';
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        indent: {
            indent: () => ReturnType;
            outdent: () => ReturnType;
        };
    }
}
type IndentOptions = {
    names: Array<string>;
    indentRange: number;
    minIndentLevel: number;
    maxIndentLevel: number;
    defaultIndentLevel: number;
    HTMLAttributes: Record<string, unknown>;
};
export declare const Indent: Extension<IndentOptions, never>;
export declare const clamp: (val: number, min: number, max: number) => number;
export {};
