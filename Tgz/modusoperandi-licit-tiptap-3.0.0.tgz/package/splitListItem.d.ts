import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export default function splitListItem(tr: Transform, schema: Schema): Transform;
declare function splitEmptyListItem(tr: Transform, schema: Schema): Transform;
export { splitEmptyListItem };
