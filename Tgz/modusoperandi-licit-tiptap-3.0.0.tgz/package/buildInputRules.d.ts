import { InputRule } from 'prosemirror-inputrules';
import { NodeType, Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
export declare function orderedListRule(nodeType: NodeType): InputRule;
export default function buildInputRules(schema: Schema): Plugin;
