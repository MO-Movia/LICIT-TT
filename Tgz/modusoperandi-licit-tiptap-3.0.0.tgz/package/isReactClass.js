export default function isReactClass(maybe) {
    if (typeof maybe !== 'function') {
        return false;
    }
    const proto = maybe.prototype;
    if (!proto) {
        return false;
    }
    return !!proto.isReactComponent;
}
