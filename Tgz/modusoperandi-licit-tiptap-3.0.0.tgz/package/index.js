// [FS] IRAD-978 2020-06-05
// Export Licit as a component
export { Licit } from './licit';
