import type { MarkSpec } from 'prosemirror-model';
import OrderedMap from 'orderedmap';
export declare function updateEditorMarks(specMarks: OrderedMap<MarkSpec>): OrderedMap<MarkSpec>;
