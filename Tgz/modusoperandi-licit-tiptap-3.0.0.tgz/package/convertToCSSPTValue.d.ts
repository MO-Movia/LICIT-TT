export declare const PX_TO_PT_RATIO = 0.75292857;
export declare const PT_TO_PX_RATIO: number;
export default function convertToCSSPTValue(styleValue: string): number;
