import { NodeSpec } from 'prosemirror-model';
import OrderedMap from 'orderedmap';
export declare function updateEditorNodes(specNodes: OrderedMap<NodeSpec>): OrderedMap<NodeSpec>;
