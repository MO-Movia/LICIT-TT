import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
export type NodeSpec = {
    attrs?: Record<string, unknown>;
    content?: string;
    draggable?: boolean;
    group?: string;
    inline?: boolean;
    name?: string;
    defining?: boolean;
    parseDOM?: Record<string, unknown>[];
    toDOM?: (node: any) => (string | number | Record<string, unknown>)[];
};
export type MarkSpec = {
    attrs?: Record<string, unknown>;
    inline?: boolean;
    defining?: boolean;
    draggable?: boolean;
    excludes?: string;
    group?: string;
    inclusive?: boolean;
    name?: string;
    spanning?: boolean;
    parseDOM: Array<Record<string, unknown>>;
    toDOM: (node: any) => (string | number | Record<string, unknown>)[];
};
export type EditorProps = {};
export type DirectEditorProps = EditorProps & {
    clipboardSerializer: any;
    dispatchTransaction: (tr: Transform) => void;
    editable: () => boolean;
    nodeViews: any;
    state: EditorState;
    transformPastedHTML: (html: string) => string;
    handleDOMEvents: any;
};
export type RenderCommentProps = {
    commentThreadId: string;
    isActive: boolean;
    requestCommentThreadDeletion: () => void;
    requestCommentThreadReflow: () => void;
};
export type ImageLike = {
    height: number;
    id: string;
    src: string;
    width: number;
};
export type ToolbarMenuConfig = {
    menuPosition: number;
    key: string;
    menuCommand: any;
    isPlugin?: boolean;
    group: string;
};
export type RecentColor = {
    id: number;
    color: string;
};
export type EditorRuntime = {
    canProxyImageSrc?: (src: string) => boolean;
    getProxyImageSrc?: (src: string) => string;
    canUploadImage?: () => boolean;
    uploadImage?: (obj: Blob) => Promise<ImageLike>;
    canComment?: () => boolean;
    createCommentThreadID?: () => string;
    renderComment?: (props: RenderCommentProps) => React.ReactElement | null;
    canLoadHTML?: () => boolean;
    loadHTML?: () => Promise<string>;
};
