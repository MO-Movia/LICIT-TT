export declare const BACKSPACE = 8;
export declare const DELETE = 46;
export declare const DOWN_ARROW = 40;
export declare const ENTER = 13;
export declare const LEFT_ARROW = 37;
export declare const RIGHT_ARROW = 39;
export declare const TAB = 9;
export declare const UP_ARROW = 38;
