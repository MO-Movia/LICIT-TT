import React from 'react';
import ReactDOM from 'react-dom';
import { Extension } from '@tiptap/core';
import { getSchema, useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import './styles/licit.css';
import Underline from '@tiptap/extension-underline';
import { v4 as uuidv4 } from 'uuid';
import Collaboration from '@tiptap/extension-collaboration';
import CollaborationCursor from '@tiptap/extension-collaboration-cursor';
import * as Y from 'yjs';
import { IndexeddbPersistence } from 'y-indexeddb';
import RichTextEditor from './ui/richTextEditor';
import DefaultEditorPlugins from './defaultEditorPlugins';
import { TextSelection } from 'prosemirror-state';
import { getEffectiveSchema } from './convertFromJSON';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { Schema } from 'prosemirror-model';
import Subscript from '@tiptap/extension-subscript';
import Superscript from '@tiptap/extension-superscript';
import TextAlign from '@tiptap/extension-text-align';
import { HEADING, noop, PARAGRAPH, ThemeProvider } from '@modusoperandi/licit-ui-commands';
import { updateEditorMarks } from './editorMarks';
import { updateEditorNodes } from './editorNodes';
import { Indent } from './extensions/indent';
import { WebrtcProvider } from 'y-webrtc';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCellEx from './extensions/tableCellEx';
import TableHeader from '@tiptap/extension-table-header';
import ParagraphNodeSpec from './specs/paragraphNodeSpec';
import * as awarenessProtocol from 'y-protocols/awareness';
import * as math from 'lib0/math';
import * as random from 'lib0/random';
import cx from 'classnames';
const effectiveSchema = null;
let editorSchema = null;
let licitPlugins = null;
let provider = null;
let ydoc = null;
let devTools;
let applyDevTools;
export const configCollab = (docID, instanceID, ref, collabServiceURL) => {
    if (docID && 0 < docID.length) {
        ref.collaboration = true;
        if (!provider) {
            let useDefaultProvider = true;
            ydoc = new Y.Doc();
            if (collabServiceURL) {
                try {
                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                    provider = new WebrtcProvider('tiptap-licit-' + docID, ydoc, {
                        signaling: [collabServiceURL],
                        password: null,
                        awareness: new awarenessProtocol.Awareness(ydoc),
                        maxConns: 20 + math.floor(random.rand() * 15),
                        filterBcConns: true,
                        peerOpts: {},
                    });
                    useDefaultProvider = false;
                }
                catch { }
            }
            if (useDefaultProvider) {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                provider = new WebrtcProvider('tiptap-licit-' + docID, ydoc);
            }
        }
        const getRandomElement = (list) => {
            return list[Math.floor(Math.random() * list.length)];
        };
        const getRandomColor = () => {
            return getRandomElement([
                '#958DF1',
                '#F98181',
                '#FBBC88',
                '#FAF594',
                '#70CFF8',
                '#94FADB',
                '#B9F18D',
            ]);
        };
        ref.currentUser = {
            name: instanceID,
            color: getRandomColor(),
        };
        // For offline editing, store the Y document in the browser
        const dbProvider = new IndexeddbPersistence(docID, ydoc);
        dbProvider.on('synced', () => {
            //'content from the database is loaded'
        });
    }
};
const prepareEffectiveSchema = (defaultExtensions, plugins) => {
    if (!effectiveSchema) {
        const schema = getSchema(defaultExtensions);
        const updateNodeAttrs = (nodeName, licitNode) => {
            const tiptapNode = schema.spec.nodes.get(nodeName);
            const keys = Object.keys(licitNode.attrs);
            keys.forEach((key) => {
                if (!tiptapNode.attrs[key]) {
                    tiptapNode.attrs[key] = licitNode.attrs[key];
                }
            });
        };
        updateNodeAttrs(PARAGRAPH, ParagraphNodeSpec);
        const nodes = updateEditorNodes(schema.spec.nodes);
        const marks = updateEditorMarks(schema.spec.marks);
        const defaultEditorSchema = new Schema({
            nodes: nodes,
            marks: marks,
        });
        const defaultEditorPlugins = new DefaultEditorPlugins(defaultEditorSchema).get();
        editorSchema = getEffectiveSchema(defaultEditorSchema, defaultEditorPlugins, plugins);
        licitPlugins = Extension.create({
            addProseMirrorPlugins() {
                return [...defaultEditorPlugins];
            },
        });
    }
};
const updateSpec = (schema, attrName, existingSchema) => {
    const keys = Object.keys(schema[attrName]);
    const keysUpdate = [];
    keys.forEach((key) => {
        if (!editorSchema[attrName][key]) {
            editorSchema[attrName][key] = schema[attrName][key];
            keysUpdate.push(key);
        }
    });
    const collection = schema.spec[attrName]['content'];
    // update current array with the latest info
    for (let i = 0; i < collection.length; i += 2) {
        if (keysUpdate.find((element) => element === collection[i])) {
            existingSchema.spec[attrName] = existingSchema.spec[attrName].update(collection[i], collection[i + 1]);
        }
        else {
            updateSpecAttrs(i, collection, existingSchema, attrName);
        }
    }
};
export const updateSpecAttrs = (i, collection, existingSchema, attrName) => {
    const attrsTipTap = collection[i + 1]['attrs'];
    if (attrsTipTap) {
        const content = existingSchema.spec[attrName]['content'];
        for (let j = 0; j < content.length; j += 2) {
            if (content[j] === collection[i]) {
                const attrsLicit = content[j + 1]['attrs'];
                const attrKeys = Object.keys(attrsTipTap);
                attrKeys.forEach((key) => {
                    if (!attrsLicit[key]) {
                        attrsLicit[key] = attrsTipTap[key];
                    }
                });
            }
        }
    }
};
const initDevTool = (debug, editorView) => {
    // [FS] IRAD-1575 2021-09-27
    if (debug) {
        if (!devTools) {
            devTools = new Promise(async (resolve, reject) => {
                try {
                    // Method is exported as both the default and named, Using named
                    // for clarity and future proofing.
                    const applyPMDevTools = await import('prosemirror-dev-tools');
                    // got the pm dev tools instance.
                    applyDevTools = applyPMDevTools.default;
                    // Attach debug tools to current editor instance.
                    applyDevTools(editorView);
                    resolve(() => {
                        // [FS] IRAD-1571 2021-10-08
                        // Prosemirror Dev Tools handles as if one only instance is used in a page and
                        // hence handling removal here gracefully.
                        const place = document.querySelector('.'.concat('__prosemirror-dev-tools__'));
                        if (place) {
                            ReactDOM.unmountComponentAtNode(place);
                            place.innerHTML = '';
                        }
                    });
                }
                catch (error) {
                    reject();
                }
            });
        }
        // Attach debug tools to current editor instance.
        if (devTools && applyDevTools) {
            applyDevTools(editorView);
        }
    }
};
const destroyDevTool = () => {
    // [FS] IRAD-1569 2021-09-15
    // Unmount dev tools when component is destroyed,
    // so that toggle effect is not occuring when the document is retrieved each time.
    if (devTools) {
        // Call the applyDevTools method again to trigger DOM removal
        // prosemirror-dev-tools has outstanding pull-requests that affect
        // dom removal. this may need to be addressed once those have been merged.
        devTools.then((removeDevTools) => removeDevTools());
    }
};
const onBeforeCreate = (params) => {
    if (!params.schema) {
        const editor = params.props.editor;
        UICommand.prototype.editor = editor;
        updateSpec(editor.schema, 'marks', editorSchema);
        updateSpec(editor.schema, 'nodes', editorSchema);
        editor.schema = new Schema({
            nodes: editorSchema.spec.nodes,
            marks: editorSchema.spec.marks,
        });
        params.schema = editor.schema;
    }
};
const onCreate = (editor, editorView, debug, onReady) => {
    // The editor is ready.
    if (onReady) {
        onReady(editor);
        initDevTool(debug, editorView);
    }
};
const onUpdate = (editor, onChange) => {
    // The content has changed.
    if (onChange) {
        onChange(editor.getJSON(), editor.isEmpty, editor.view);
    }
};
const getCollabExtensions = (collaboration, currentUser) => {
    return collaboration
        ? [
            Collaboration.configure({
                document: ydoc,
            }),
            CollaborationCursor.configure({
                provider: provider,
                user: currentUser,
            }),
        ]
        : [];
};
export const Licit = ({ docID, plugins, width, height, runtime, data, readOnly, embedded, collabServiceURL, debug, disabled, onChange, onReady, theme, toolbarConfig }) => {
    const instanceID = uuidv4();
    // [FS] IRAD-981 2020-06-10
    // Component's configurations.
    // [FS] IRAD-1552 2021-08-26
    // Collaboration server / client should allow string values for document identifiers.
    docID = docID || ''; // Empty means collaborative.
    // [FS] IRAD-1553 2021-08-26
    // Configurable Collaboration Service URL.
    collabServiceURL = collabServiceURL || '';
    debug = debug || false;
    // Default width and height to undefined
    width = width || undefined;
    height = height || undefined;
    onChange = onChange || noop;
    onReady = onReady || noop;
    readOnly = readOnly || false;
    data = data || null;
    disabled = disabled || false;
    embedded = embedded || false; // [FS] IRAD-996 2020-06-30
    // [FS] 2020-07-03
    // Handle Image Upload from Angular App
    runtime = runtime || null;
    plugins = plugins || null;
    // Theme property for toolbar. By default uses light theme.
    theme = theme || 'dark';
    toolbarConfig = toolbarConfig || null;
    let currentUser = null;
    let collaboration = false;
    const defaultExtensions = [
        StarterKit.configure({
            codeBlock: false,
        }),
        Subscript,
        Superscript,
        Underline,
        TextAlign.configure({
            types: [HEADING, PARAGRAPH],
        }),
        Indent,
        Table.configure({
            resizable: true,
        }),
        TableRow,
        TableHeader,
        TableCellEx,
    ];
    const collabCfg = { collaboration, currentUser };
    configCollab(docID, instanceID, collabCfg, collabServiceURL);
    collaboration = collabCfg.collaboration;
    currentUser = collabCfg.currentUser;
    prepareEffectiveSchema(defaultExtensions, plugins);
    const editor = useEditor({
        extensions: [
            ...defaultExtensions,
            ...getCollabExtensions(collaboration, currentUser),
            licitPlugins,
        ],
        onBeforeCreate(props) {
            // Before the view is created.
            onBeforeCreate({ props, schema: effectiveSchema });
        },
        content: data,
    });
    const goToEnd = () => {
        const view = editor.view;
        const tr = view.state.tr;
        view.dispatch(tr.setSelection(TextSelection.atEnd(view.state.doc)).scrollIntoView());
        view.focus();
    };
    if (editor) {
        editor.on('create', (props) => {
            // The editor is ready.
            onCreate(props.editor, props.editor.view, debug, onReady);
        });
        editor.on('update', (props) => {
            // The content has changed.
            onUpdate(props.editor, onChange);
        });
        editor.on('destroy', (_props) => {
            // The editor is being destroyed.
            destroyDevTool();
        });
        const eView = editor.view;
        eView.runtime = runtime;
        let wrapperClass = 'prosemirror-editor-wrapper' + ' ' + theme;
        const mainClassName = cx(wrapperClass, {
            embedded: embedded,
        });
        return (React.createElement(ThemeProvider, { theme: theme },
            React.createElement("div", { className: mainClassName },
                React.createElement(RichTextEditor, { disabled: disabled, editor: editor, editorState: editor.state, editorView: eView, embedded: embedded, height: height, readOnly: readOnly, toolbarConfig: toolbarConfig, width: width }))));
    }
    else {
        return React.createElement("div", null);
    }
};
