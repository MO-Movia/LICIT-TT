import { EditorView } from 'prosemirror-view';
export type EditorViewEx = EditorView & {
    readOnly?: boolean;
    disabled?: boolean;
    runtime?: any;
    placeholder?: any;
};
export declare const LAYOUT: {
    DESKTOP_SCREEN_4_3: string;
    DESKTOP_SCREEN_16_9: string;
    US_LETTER_LANDSCAPE: string;
    US_LETTER_PORTRAIT: string;
    A4_LANDSCAPE: string;
    A4_PORTRAIT: string;
};
export declare const ATTRIBUTE_LAYOUT = "data-layout";
export declare const ATTRIBUTE_LIST_STYLE_TYPE = "data-list-style-type";
export type EditorFocused = EditorView & {
    focused: boolean;
    runtime?: any;
    readOnly?: any;
};
