import { EditorState } from 'prosemirror-state';
export default function isEditorStateEmpty(editorState: EditorState): boolean;
