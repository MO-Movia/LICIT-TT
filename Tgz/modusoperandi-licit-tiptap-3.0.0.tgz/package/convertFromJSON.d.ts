import { Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
export interface LicitPlugin extends Plugin {
    getEffectiveSchema: (schema: Schema) => Schema;
    initKeyCommands: () => Plugin;
    initButtonCommands: (theme: unknown) => any;
}
export declare function getEffectiveSchema(defaultSchema: Schema, defaultPlugins: Array<Plugin>, plugins?: Array<Plugin>): Schema;
