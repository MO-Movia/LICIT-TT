export type Rect = {
    h: number;
    w: number;
    x: number;
    y: number;
};
export default function htmlElementToRect(el: HTMLElement): Rect;
