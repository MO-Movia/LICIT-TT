type ClientRectLikeReadOnly = {
    x: number;
    y: number;
    width: number;
    height: number;
    top: number;
    right: number;
    bottom: number;
    left: number;
};
type ResizeCallback = (r: ResizeObserverEntry) => void;
export type ResizeObserverEntry = {
    target: Element;
    contentRect: ClientRectLikeReadOnly;
};
export declare function observe(node: HTMLElement, callback: (ResizeObserverEntry: any) => void): void;
export declare function unobserve(node: HTMLElement, callback?: ResizeCallback): void;
declare const _default: {
    observe: typeof observe;
    unobserve: typeof unobserve;
};
export default _default;
