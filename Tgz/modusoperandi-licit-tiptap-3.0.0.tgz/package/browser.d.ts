declare const browser: {
    isMac: () => boolean;
};
export default browser;
