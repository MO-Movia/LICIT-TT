import { EditorState } from 'prosemirror-state';
export declare const FONT_TYPE_NAME_DEFAULT = "Arial";
export default function findActiveFontType(state: EditorState): string;
