import { MarkSpec } from 'prosemirror-model';
export declare const DOM_ATTRIBUTE_SIZE = "data-spacer-size";
export declare const SPACER_SIZE_TAB = "tab";
export declare const SPACER_SIZE_TAB_LARGE = "tab-large";
export declare const HAIR_SPACE_CHAR = "\u200A";
declare const SpacerMarkSpec: MarkSpec;
export default SpacerMarkSpec;
