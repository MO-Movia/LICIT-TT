import { MarkSpec } from 'prosemirror-model';
declare const TextColorMarkSpec: MarkSpec;
export default TextColorMarkSpec;
