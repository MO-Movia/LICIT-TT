import { MarkSpec } from 'prosemirror-model';
declare const TextSelectionMarkSpec: MarkSpec;
export default TextSelectionMarkSpec;
