import type { MarkSpec } from 'prosemirror-model';
declare const StrongMarkSpec: MarkSpec;
export default StrongMarkSpec;
