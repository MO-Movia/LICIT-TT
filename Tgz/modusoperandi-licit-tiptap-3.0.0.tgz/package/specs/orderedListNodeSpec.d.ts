import type { NodeSpec } from 'prosemirror-model';
export declare const ATTRIBUTE_COUNTER_RESET = "data-counter-reset";
export declare const ATTRIBUTE_FOLLOWING = "data-following";
declare const OrderedListNodeSpec: NodeSpec;
export default OrderedListNodeSpec;
