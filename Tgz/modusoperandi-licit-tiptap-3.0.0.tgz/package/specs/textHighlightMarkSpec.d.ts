import { MarkSpec } from 'prosemirror-model';
declare const TextHighlightMarkSpec: MarkSpec;
export default TextHighlightMarkSpec;
