import { NodeSpec } from 'prosemirror-model';
declare const BulletListNodeSpec: NodeSpec;
export default BulletListNodeSpec;
