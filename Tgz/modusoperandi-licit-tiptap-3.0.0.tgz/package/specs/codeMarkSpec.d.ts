import type { MarkSpec } from 'prosemirror-model';
declare const CodeMarkSpec: MarkSpec;
export default CodeMarkSpec;
