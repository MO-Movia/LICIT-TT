import { NodeSpec } from 'prosemirror-model';
declare const HardBreakNodeSpec: NodeSpec;
export default HardBreakNodeSpec;
