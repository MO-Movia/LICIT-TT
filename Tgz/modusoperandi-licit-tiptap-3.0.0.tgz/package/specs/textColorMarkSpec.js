import toCSSColor from '../toCSSColor';
const TextColorMarkSpec = {
    attrs: {
        color: { default: null }, //  Allow missing color
        overridden: { default: false },
    },
    inline: true,
    group: 'inline',
    parseDOM: [
        {
            tag: 'span[style*=color]',
            getAttrs: (dom) => {
                const { color } = dom.style;
                const overridden = dom.getAttribute('overridden') === 'true'; // Extract overridden flag
                return {
                    color: toCSSColor(color),
                    overridden
                };
            },
        },
    ],
    toDOM(node) {
        const { color, overridden } = node.attrs;
        const attrs = { style: '' };
        if (color) {
            attrs.style = `color: ${color};`;
            attrs['overridden'] = overridden?.toString();
        }
        return ['span', attrs, 0];
    },
};
export default TextColorMarkSpec;
