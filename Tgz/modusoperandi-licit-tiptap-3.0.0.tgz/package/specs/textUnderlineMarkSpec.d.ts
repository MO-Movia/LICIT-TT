import type { MarkSpec } from 'prosemirror-model';
declare const TextUnderlineMarkSpec: MarkSpec;
export default TextUnderlineMarkSpec;
