import { MarkSpec } from 'prosemirror-model';
declare const FontSizeMarkSpec: MarkSpec;
export default FontSizeMarkSpec;
