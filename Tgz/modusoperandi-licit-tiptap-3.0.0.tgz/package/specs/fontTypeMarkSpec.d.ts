import { MarkSpec } from 'prosemirror-model';
export declare const FONT_TYPE_NAMES: string[];
export declare function preLoadFonts(): void;
declare const FontTypeMarkSpec: MarkSpec;
export default FontTypeMarkSpec;
