import type { MarkSpec } from 'prosemirror-model';
declare const TextNoWrapMarkSpec: MarkSpec;
export default TextNoWrapMarkSpec;
