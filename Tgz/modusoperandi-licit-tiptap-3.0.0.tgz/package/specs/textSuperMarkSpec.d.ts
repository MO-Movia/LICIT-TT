import type { MarkSpec } from 'prosemirror-model';
declare const TextSuperMarkSpec: MarkSpec;
export default TextSuperMarkSpec;
