import type { MarkSpec } from 'prosemirror-model';
declare const TextSubMarkSpec: MarkSpec;
export default TextSubMarkSpec;
