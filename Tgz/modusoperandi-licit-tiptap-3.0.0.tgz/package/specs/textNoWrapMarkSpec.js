const NO_WRAP_DOM = ['nobr', 0];
const TextNoWrapMarkSpec = {
    parseDOM: [{ tag: 'nobr' }],
    toDOM() {
        return NO_WRAP_DOM;
    },
};
export default TextNoWrapMarkSpec;
