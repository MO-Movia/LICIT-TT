import type { MarkSpec } from 'prosemirror-model';
declare const EMMarkSpec: MarkSpec;
export default EMMarkSpec;
