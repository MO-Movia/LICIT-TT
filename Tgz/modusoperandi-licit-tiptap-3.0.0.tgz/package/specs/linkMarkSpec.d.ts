import type { MarkSpec } from 'prosemirror-model';
declare const LinkMarkSpec: MarkSpec;
export default LinkMarkSpec;
