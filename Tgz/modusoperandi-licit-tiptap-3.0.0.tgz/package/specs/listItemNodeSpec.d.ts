import { NodeSpec } from 'prosemirror-model';
export declare const ATTRIBUTE_LIST_STYLE_TYPE = "data-list-style-type";
declare const ListItemNodeSpec: NodeSpec;
export default ListItemNodeSpec;
