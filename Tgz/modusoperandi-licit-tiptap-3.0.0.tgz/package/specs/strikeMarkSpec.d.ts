import type { MarkSpec } from 'prosemirror-model';
declare const StrikeMarkSpec: MarkSpec;
export default StrikeMarkSpec;
