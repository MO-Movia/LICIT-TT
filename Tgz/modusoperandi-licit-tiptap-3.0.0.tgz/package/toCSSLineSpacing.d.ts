export declare const LINE_SPACING_100 = "125%";
export declare const LINE_SPACING_115 = "138%";
export declare const LINE_SPACING_150 = "165%";
export declare const LINE_SPACING_200 = "232%";
export default function toCSSLineSpacing(source: any): string;
