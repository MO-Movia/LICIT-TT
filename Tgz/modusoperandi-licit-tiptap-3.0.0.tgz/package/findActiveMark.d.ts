import { Mark, MarkType, Node } from 'prosemirror-model';
export default function findActiveMark(doc: Node, from: number, to: number, markType: MarkType): Mark | null;
