import ResizeObserver from 'resize-observer-polyfill';
import nullthrows from 'nullthrows';
let instance = null;
const nodesObserving = new Map();
function onResizeObserve(entries) {
    entries.forEach(handleResizeObserverEntry);
}
function handleResizeObserverEntry(entry) {
    const node = entry.target;
    const callbacks = nodesObserving.get(node);
    const executeCallback = (cb) => cb(entry);
    callbacks && callbacks.forEach(executeCallback);
}
export function observe(node, callback) {
    const el = node;
    const observer = instance || (instance = new ResizeObserver(onResizeObserve));
    if (nodesObserving.has(el)) {
        // Already observing node.
        const callbacks = nullthrows(nodesObserving.get(el));
        callbacks.push(callback);
    }
    else {
        const callbacks = [callback];
        nodesObserving.set(el, callbacks);
        observer.observe(el);
    }
}
export function unobserve(node, callback) {
    const observer = instance;
    if (!observer) {
        return;
    }
    const el = node;
    observer.unobserve(el);
    if (callback) {
        // Remove the passed in callback from the callbacks of the observed node
        // And, if no more callbacks then stop observing the node
        const callbacks = nodesObserving.has(el)
            ? nullthrows(nodesObserving.get(el)).filter((cb) => cb !== callback)
            : null;
        if (callbacks && callbacks.length) {
            nodesObserving.set(el, callbacks);
        }
        else {
            nodesObserving.delete(el);
        }
    }
    else {
        // Delete all callbacks for the node.
        nodesObserving.delete(el);
    }
    if (!nodesObserving.size) {
        // We have nothing to observe. Stop observing, which stops the
        // ResizeObserver instance from receiving notifications of
        // DOM resizing. Until the observe() method is used again.
        // According to specification a ResizeObserver is deleted by the garbage
        // collector if the target element is deleted.
        observer.disconnect();
        instance = null;
    }
}
export default {
    observe,
    unobserve,
};
