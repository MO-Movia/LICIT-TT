export default function isReactClass(maybe: unknown): boolean;
