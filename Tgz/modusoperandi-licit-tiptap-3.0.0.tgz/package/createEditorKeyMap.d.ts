export default function createEditorKeyMap(): any;
