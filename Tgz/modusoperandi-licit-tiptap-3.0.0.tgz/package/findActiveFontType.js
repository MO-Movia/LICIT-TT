import { MARK_FONT_TYPE } from '@modusoperandi/licit-ui-commands';
import findActiveMark from './findActiveMark';
// This should map to `--czi-content-font-size` at `czi-editor.css`.
export const FONT_TYPE_NAME_DEFAULT = 'Arial';
export default function findActiveFontType(state) {
    const { schema, doc, selection, tr } = state;
    const markType = schema.marks[MARK_FONT_TYPE];
    if (!markType) {
        return FONT_TYPE_NAME_DEFAULT;
    }
    const { from, to, empty } = selection;
    if (empty) {
        const storedMarks = tr.storedMarks ||
            state.storedMarks ||
            (selection.$cursor &&
                selection.$cursor.marks &&
                selection.$cursor.marks()) ||
            [];
        const sm = storedMarks.find((m) => m.type === markType);
        return (sm && sm.attrs.name) || FONT_TYPE_NAME_DEFAULT;
    }
    const mark = findActiveMark(doc, from, to, markType);
    const fontName = mark && mark.attrs.name;
    if (!fontName) {
        return FONT_TYPE_NAME_DEFAULT;
    }
    return fontName;
}
