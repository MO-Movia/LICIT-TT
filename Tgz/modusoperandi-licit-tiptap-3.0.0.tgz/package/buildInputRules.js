import { ellipsis, emDash, inputRules, smartQuotes, wrappingInputRule, } from 'prosemirror-inputrules';
// This file is forked from
// // https://github.com/ProseMirror/prosemirror-example-setup/blob/master/src/inputrules.js
// : (NodeType) → InputRule
// Given a list node type, returns an input rule that turns a number
// followed by a dot at the start of a textblock into an ordered list.
/// Given a list node type, returns an input rule that turns a number
/// followed by a dot at the start of a textblock into an ordered list.
export function orderedListRule(nodeType) {
    return wrappingInputRule(/^(\d+)\.\s$/, nodeType, (match) => ({ order: +match[1] }), (match, node) => node.childCount + node.attrs.order == +match[1]);
}
// : (Schema) → Plugin
// A set of input rules for creating the basic block quotes, lists,
// code blocks, and heading.
export default function buildInputRules(schema) {
    let rules = smartQuotes.concat(ellipsis, emDash), type;
    if ((type = schema.nodes.ordered_list))
        rules.push(orderedListRule(type));
    return inputRules({ rules });
}
