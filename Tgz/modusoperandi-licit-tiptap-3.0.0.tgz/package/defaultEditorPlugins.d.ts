import { Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
export default class DefaultEditorPlugins {
    plugins: Array<Plugin>;
    constructor(schema: Schema);
    get(): Array<Plugin>;
}
