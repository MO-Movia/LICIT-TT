import { Node, Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { InfoIconView } from './infoIconView';
export declare const INFO_ICON = "infoicon";
export declare const KEY_INFO_ICON: any;
export declare class InfoIconPlugin extends Plugin {
    constructor();
    getEffectiveSchema(schema: Schema): Schema;
    initKeyCommands(): unknown;
    initButtonCommands(theme: string): unknown;
}
export declare function bindInfoIconView(node: Node, view: EditorView, curPos: boolean | (() => number)): InfoIconViewExt;
declare class InfoIconViewExt extends InfoIconView {
    constructor(node: Node, view: EditorView, getCurPos: any);
}
export {};
