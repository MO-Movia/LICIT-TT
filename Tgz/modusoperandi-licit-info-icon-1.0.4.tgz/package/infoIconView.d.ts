import { Node } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { PopUpHandle } from '@modusoperandi/licit-ui-commands';
type CBFn = () => void;
export type Style = {
    styles?: {
        underline?: any;
        textHighlight?: string;
    };
};
export declare class InfoIconView {
    node: Node;
    outerView: EditorView;
    getPos: any;
    _popUp: PopUpHandle | null;
    _popUp_subMenu: PopUpHandle | null;
    dom: globalThis.Node;
    offsetLeft: Element;
    nodePosition: number;
    constructor(node: Node, view: EditorView, getPos: CBFn);
    showSourceText(e: MouseEvent): void;
    getNodePosEx(left: number, top: number): number;
    addEventListenerToView(): void;
    removeEventListenerToView(): void;
    hideSourceText(_e: MouseEvent): void;
    selectNode(e: MouseEvent): void;
    isPNodeNull(pNode: any): boolean;
    parentNodeType(pNode: any): boolean;
    getNodePosition(e: MouseEvent): number;
    _onClose: () => void;
    onCancel: (view: EditorView) => void;
    destroyPopup(): void;
    onInfoSubMenuMouseOut: () => void;
    onEditInfo: (view: EditorView) => void;
    createInfoObject(editorView: EditorView, mode: number): {
        infoIcon: any;
        description: any;
        mode: number;
        editorView: EditorView;
        from: any;
        to: any;
    };
    updateInfoIcon(view: EditorView, infoicon: any): void;
    updateInfoObject(tr: Transform, infoIcon: any): Transform;
    isInfoIconNode(position: number): boolean;
    onInfoRemove: (view: EditorView) => void;
    showInfoIcon(): void;
    open(e: MouseEvent): void;
    setContentRight(e: any, parent: any, tooltip: any, _ttContent: any): void;
    close(): void;
    update(node: Node): boolean;
    destroy(): void;
    stopEvent(_event: Event): boolean;
    ignoreMutation(): boolean;
}
export {};
