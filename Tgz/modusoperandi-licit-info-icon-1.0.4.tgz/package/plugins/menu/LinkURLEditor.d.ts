import * as React from 'react';
import { EditorView } from 'prosemirror-view';
import './czi-form.css';
import './czi-image-url-editor.css';
export declare const ENTER = 13;
type LinkProps = {
    href: string;
    view: EditorView;
    close: (url?: any) => string;
};
export declare class LinkURLEditor extends React.PureComponent<LinkProps> {
    state: {
        url: string;
    };
    render(): React.JSX.Element;
    _onKeyDown: (e: any) => void;
    _onURLChange: (e: any) => void;
    _cancel: () => void;
    _apply: () => boolean;
}
export {};
