import { EditorState, Plugin } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { MarkType } from 'prosemirror-model';
export declare function markActive(state: EditorState, type: MarkType): boolean;
export declare function getLink(view: EditorView): string;
export declare const addLinkCommand: (view: any) => Promise<unknown>;
declare const _default: () => Plugin<any>;
export default _default;
