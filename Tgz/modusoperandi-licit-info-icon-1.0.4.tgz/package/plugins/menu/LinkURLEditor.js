// @flow
import * as React from 'react';
import { sanitizeURL } from './sanitizeURL';
import { toggleMark } from 'prosemirror-commands';
import { preventEventDefault, CustomButton } from '@modusoperandi/licit-ui-commands';
import './czi-form.css';
import './czi-image-url-editor.css';
export const ENTER = 13;
const BAD_CHARACTER_PATTER = /\s/;
export class LinkURLEditor extends React.PureComponent {
    state = {
        url: this.props.href,
    };
    render() {
        const { href } = this.props;
        const { url } = this.state;
        const error = url ? BAD_CHARACTER_PATTER.test(url) : false;
        return (React.createElement("div", { className: "czi-image-url-editor" },
            React.createElement("form", { className: "czi-form", onSubmit: preventEventDefault },
                React.createElement("fieldset", null,
                    React.createElement("legend", null, "Add a Link"),
                    React.createElement("input", { autoFocus: true, onChange: this._onURLChange, onKeyDown: this._onKeyDown, placeholder: "Paste a URL", spellCheck: false, type: "text", value: url || '' })),
                React.createElement("div", { className: "czi-form-buttons" },
                    React.createElement(CustomButton, { label: "Cancel", onClick: this._cancel }),
                    React.createElement(CustomButton, { active: true, disabled: (href ? error : (error || !url)), label: "Apply", onClick: this._apply })))));
    }
    _onKeyDown = (e) => {
        if (e.keyCode === ENTER) {
            e.preventDefault();
            this._apply();
        }
    };
    _onURLChange = (e) => {
        const url = e.target.value;
        this.setState({
            url,
        });
    };
    _cancel = () => {
        this.props.close();
    };
    _apply = () => {
        const { url } = this.state;
        toggleMark(this.props.view.state.schema.marks.link, {
            href: url,
        })(this.props.view.state, this.props.view.dispatch);
        this.props.view.focus();
        this.props.close(sanitizeURL(url));
        return false;
    };
}
