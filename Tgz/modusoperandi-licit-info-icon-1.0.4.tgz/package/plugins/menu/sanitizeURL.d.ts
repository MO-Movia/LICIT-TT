export declare function sanitizeURL(url?: string): string;
