import { MarkSpec } from 'prosemirror-model';
declare const _default: () => import("prosemirror-state").Plugin<any>;
export default _default;
export type Marks = 'em' | 'strong';
export declare const marks: {
    em: MarkSpec;
    strong: MarkSpec;
};
