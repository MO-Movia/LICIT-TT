import { baseKeymap, toggleMark } from 'prosemirror-commands';
import { undo, redo } from 'prosemirror-history';
import { keymap } from 'prosemirror-keymap';
export default () => keymap({
    ...baseKeymap,
    'Mod-z': undo,
    'Shift-Mod-z': redo,
    'Mod-b': toggleMark(marks.strong),
    'Mod-i': toggleMark(marks.em),
});
export const marks = {
    em: {
        parseDOM: [{ tag: 'em' }, { tag: 'i' }, { style: 'font-style=italic' }],
        toDOM: () => ['em', 0],
    },
    strong: {
        parseDOM: [{ tag: 'strong' }, { tag: 'b' }, { style: 'font-weight=bold' }],
        toDOM: () => ['strong', 0],
    },
};
