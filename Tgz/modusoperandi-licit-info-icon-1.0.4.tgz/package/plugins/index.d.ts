export declare const plugins: import("prosemirror-state").Plugin<any>[];
