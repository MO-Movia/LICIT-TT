export declare const FONTAWESOMEICONS: FaIcons[];
export type FaIcons = {
    name: string;
    unicode: string;
    selected: boolean;
};
