import * as React from 'react';
import './infoicon-note.css';
type AlertProps = {
    initialValue: Record<string, never>;
    title: string;
    content: string;
    close: () => void;
};
export declare class AlertInfo extends React.PureComponent<AlertProps, AlertProps> {
    constructor(props: AlertProps);
    render(): React.ReactNode;
}
export {};
