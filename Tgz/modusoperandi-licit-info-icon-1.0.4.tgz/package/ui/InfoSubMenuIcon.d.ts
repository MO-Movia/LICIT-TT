import * as React from 'react';
type InfoSubMenuProps = {
    type: string;
    title?: string;
};
export declare class InfoSubMenuIcon extends React.PureComponent {
    props: InfoSubMenuProps;
    static get(type: string, title?: string): React.ReactNode;
    render(): React.JSX.Element;
}
export {};
