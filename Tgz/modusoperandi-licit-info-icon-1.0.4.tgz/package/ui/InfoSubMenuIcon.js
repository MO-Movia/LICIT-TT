import cx from 'classnames';
import * as React from 'react';
const VALID_CHARS = /[a-z_]+/;
const cached = {};
export class InfoSubMenuIcon extends React.PureComponent {
    // Get the static Icon.
    static get(type, title) {
        const key = `${type || ''}-${title || ''}`;
        const icon = cached[key] || React.createElement(InfoSubMenuIcon, { title: title, type: type });
        cached[key] = icon;
        return icon;
    }
    render() {
        const { type, title } = this.props;
        let className = '';
        let children = '';
        if (!type || !VALID_CHARS.test(type)) {
            className = cx('czi-icon-unknown');
            children = title || type;
        }
        else {
            className = cx('czi-icon', { [type]: true });
            children = type;
        }
        return React.createElement("span", { className: className }, children);
    }
}
