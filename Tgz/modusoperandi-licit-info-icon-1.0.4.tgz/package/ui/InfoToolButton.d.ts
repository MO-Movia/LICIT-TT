import * as React from 'react';
import type { PointerSurfaceProps } from '@modusoperandi/licit-ui-commands';
type InfoToolButtonProps = PointerSurfaceProps & {
    icon?: string | React.ReactNode | null;
    label?: string | React.ReactNode | null;
};
export declare class InfoToolButton extends React.PureComponent {
    props: InfoToolButtonProps;
    render(): React.JSX.Element;
}
export {};
