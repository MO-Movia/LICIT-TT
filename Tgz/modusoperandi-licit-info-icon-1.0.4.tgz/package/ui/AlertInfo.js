import * as React from 'react';
import './infoicon-note.css';
export class AlertInfo extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            initialValue: props.initialValue,
            title: props.title,
            content: props.content,
            close: props.close
        };
    }
    render() {
        const title = this.props.title || 'Info Plugin Error!';
        const content = this.props.content ||
            'Unable to load the info plugin.';
        return (React.createElement("div", { className: "molcit-infoicon-alert" },
            React.createElement("strong", null, title),
            React.createElement("span", null, content)));
    }
}
