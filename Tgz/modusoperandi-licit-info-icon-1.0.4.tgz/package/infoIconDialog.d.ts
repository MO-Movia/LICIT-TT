import * as React from 'react';
import './ui/infoIconDialog.css';
import { EditorView } from 'prosemirror-view';
import 'font-awesome/css/font-awesome.min.css';
import 'prosemirror-menu/style/menu.css';
import { FaIcons } from './ui/FaIcon';
type InfoDialogProps = {
    infoIcon: {
        name: any;
        unicode: any;
    };
    description: string;
    editorView: EditorView;
    mode: number;
    from: number;
    to: number;
    faIcons: any;
    selectedIconName: string;
    isOpen: boolean;
    isEditorEmpty: boolean;
    isButtonEnabled: boolean;
    close: (val?: any) => void;
};
export declare class InfoIconDialog extends React.PureComponent<InfoDialogProps, InfoDialogProps> {
    _popUp: any;
    view: EditorView;
    constructor(props: InfoDialogProps);
    componentDidMount(): void;
    render(): React.ReactNode;
    _cancel: () => void;
    selectInfoIcon: (clickedIcon: any) => void;
    _insert: () => void;
    validateInsert(): void;
    _onAdd(_event: React.SyntheticEvent): void;
    setVisible(isOpen: any): void;
    _onRemove(): void;
    disableInfoWIndow(isEditable: boolean): void;
    getCacheIcons(): FaIcons[];
    insertButtonEnble(docJson: any): void;
}
export {};
