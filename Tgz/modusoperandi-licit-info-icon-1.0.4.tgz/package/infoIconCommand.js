import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { InfoIconDialog } from './infoIconDialog';
import { createPopUp } from '@modusoperandi/licit-ui-commands';
import { getNode } from './constants';
import { DOMSerializer, Fragment } from 'prosemirror-model';
export class InfoIconCommand extends UICommand {
    _popUp = null;
    _alertPopup = null;
    _color = '';
    constructor(color) {
        super();
        this._color = color;
    }
    isEnabled = (state) => {
        return this._isEnabled(state);
    };
    createInfoObject(editorView, mode) {
        return {
            infoIcon: '',
            description: '',
            mode: mode, //0 = new , 1- modify, 2- delete
            editorView: editorView,
            selectedIconName: '',
        };
    }
    waitForUserInput = (_state, _dispatch, view, _event) => {
        if (this._popUp) {
            return Promise.resolve(undefined);
        }
        return new Promise((resolve) => {
            this._popUp = createPopUp(InfoIconDialog, this.createInfoObject(view, 1), {
                modal: true,
                IsChildDialog: false,
                autoDismiss: false,
                onClose: (val) => {
                    if (this._popUp) {
                        this._popUp = null;
                        resolve(val);
                    }
                },
            });
        });
    };
    executeWithUserInput = (state, dispatch, _view, infoIcon) => {
        if (dispatch) {
            const { selection } = state;
            let { tr } = state;
            tr = tr.setSelection(selection);
            const from = state.selection.from;
            const to = state.selection.to;
            const node = getNode(from, to, tr);
            if (node && infoIcon) {
                const div = document.createElement('div');
                const fragm = this.getFragm(infoIcon);
                div.appendChild(fragm);
                const desc = div.innerHTML;
                const infoicon = state.schema.nodes['infoicon'];
                let newAttrs = {};
                Object.assign(newAttrs, infoicon['attrs']);
                newAttrs = this.createInfoIconAttrs(from, to, desc, infoIcon);
                const infoiconNode = infoicon.create(null);
                const $head = state.selection.$head;
                let listNodeAttr = null;
                let listPos = 0;
                for (let d = $head.depth; d > 0; d--) {
                    if (this.isList($head, d)) {
                        listNodeAttr = { ...$head.node(d).attrs };
                        listPos = $head['path'][d + 4];
                        break;
                    }
                }
                tr = tr.insert(to, Fragment.from(infoiconNode));
                tr = tr.setNodeMarkup(to, undefined, newAttrs);
                if (listNodeAttr) {
                    tr = tr.setNodeMarkup(listPos, undefined, listNodeAttr);
                }
            }
            dispatch(tr);
        }
        return false;
    };
    cancel() {
        return null;
    }
    createInfoIconAttrs(from, to, desc, infoIcon) {
        const newAttrs = {};
        Object.assign(newAttrs, infoIcon['attrs']);
        newAttrs['from'] = from;
        newAttrs['to'] = to;
        newAttrs['description'] = desc;
        newAttrs['infoIcon'] = infoIcon.infoIcon;
        return newAttrs;
    }
    getFragm(infoIcon) {
        return DOMSerializer.fromSchema(infoIcon.editorView.state.schema).serializeFragment(this.getDocContent(infoIcon));
    }
    getDocContent(infoIcon) {
        return infoIcon.editorView.state.doc.content;
    }
    isList($head, d) {
        return !!($head.node(d).type.name === 'ordered_list' ||
            $head.node(d).type.name === 'bullet_list');
    }
    getParentNodeSize(state) {
        return state.selection.$head.parent.nodeSize - 2;
    }
    getParentStartPos(head) {
        return head.pos - head.parentOffset;
    }
    _isEnabled = (state) => {
        const tr = state.tr;
        if (!tr.selection.empty) {
            return false;
        }
        return true;
    };
    renderLabel() {
        return;
    }
    isActive() {
        return true;
    }
    executeCustom(_state, tr) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
