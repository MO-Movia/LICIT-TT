import * as React from 'react';
import { InfoToolButton } from './ui/InfoToolButton';
import { InfoSubMenuIcon } from './ui/InfoSubMenuIcon';
import './ui/infoicon-note.css';
export class InfoIconSubMenu extends React.PureComponent {
    state = {
        hidden: false,
    };
    render() {
        const { onEdit, onRemove, editorView, onMouseOut } = this.props;
        const disabled = editorView['readOnly'];
        return (React.createElement("div", { className: "molcit-infoicon-submenu", onMouseLeave: onMouseOut, role: 'menu', tabIndex: 0 },
            React.createElement("div", { className: "molcit-infoicon-submenu-body" },
                React.createElement("div", { className: "molcit-infoicon-submenu-row" },
                    React.createElement(InfoToolButton, { disabled: disabled, icon: InfoSubMenuIcon.get('edit'), onClick: onEdit, value: editorView }),
                    React.createElement(InfoToolButton, { disabled: disabled, icon: InfoSubMenuIcon.get('delete'), onClick: onRemove, value: editorView })))));
    }
}
