import * as React from 'react';
import { FaIcons } from './ui/FaIcon';
import './ui/infoicon-note.css';
type SearchInfoProps = {
    icons: any;
    selectedIcon: FaIcons;
    close: (val?: any) => void;
};
export declare class SearchInfoIcon extends React.PureComponent<SearchInfoProps, SearchInfoProps> {
    _popUp: any;
    constructor(props: SearchInfoProps);
    render(): React.ReactNode;
    _cancel: () => void;
    _save: () => void;
    enableInfoWIndow(): void;
    showAlert(): void;
    searchIcon: (e: any) => void;
    selectInfoIcon: (icon: FaIcons) => void;
    getCacheIcons(): FaIcons[];
}
export {};
