import * as React from 'react';
import { EditorView } from 'prosemirror-view';
import './ui/infoicon-note.css';
type CustomButtonProps = {
    editorView: EditorView;
    onEdit: (view: EditorView) => void;
    onRemove: (view: EditorView) => void;
    onMouseOut: () => void;
};
export declare class InfoIconSubMenu extends React.PureComponent {
    props: CustomButtonProps;
    state: {
        hidden: boolean;
    };
    render(): React.JSX.Element;
}
export {};
