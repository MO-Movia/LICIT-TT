declare const DarkThemeIcon = "/assets/images/dark/Icon_Infoicon.svg";
declare const LightThemeIcon = "/assets/images/light/Icon_Infoicon.svg";
export { DarkThemeIcon, LightThemeIcon };
