import { Node } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare const INFO_ICON = "infoicon";
export declare const MARKFROM = "markFrom";
export declare const PARAGRAPH = "paragraph";
export declare const SELECTEDINFOICON = "selectedInfoIcons";
export type KeyValuePair = {
    [key: string]: unknown;
};
export declare function getNode(from: number, to: number, tr: Transform): Node;
