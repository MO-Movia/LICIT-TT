export const INFO_ICON = 'infoicon';
export const MARKFROM = 'markFrom';
export const PARAGRAPH = 'paragraph';
export const SELECTEDINFOICON = 'selectedInfoIcons';
//to get the selected node
export function getNode(from, to, tr) {
    let selectedNode = null;
    tr.doc.nodesBetween(from, to, (node, _startPos) => {
        if (node.type.name === 'paragraph') {
            if (null == selectedNode) {
                selectedNode = node;
            }
        }
    });
    return selectedNode;
}
