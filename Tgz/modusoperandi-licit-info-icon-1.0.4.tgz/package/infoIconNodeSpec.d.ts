import { NodeSpec } from 'prosemirror-model';
export declare const InfoIconNodeSpec: NodeSpec;
