import * as React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import type { PopUpHandle } from '@modusoperandi/licit-ui-commands';
export declare class InfoIconCommand extends UICommand {
    _popUp: PopUpHandle | null;
    _alertPopup: PopUpHandle | null;
    _color: string;
    constructor(color?: string);
    isEnabled: (state: EditorState) => boolean;
    createInfoObject(editorView: EditorView, mode: number): {
        infoIcon: string;
        description: string;
        mode: number;
        editorView: EditorView;
        selectedIconName: string;
    };
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, view?: EditorView, _event?: React.SyntheticEvent) => Promise<unknown>;
    executeWithUserInput: (state: EditorState, dispatch: (tr: Transform) => void | undefined, _view: EditorView | undefined, infoIcon: any) => boolean;
    cancel(): void;
    createInfoIconAttrs(from: any, to: any, desc: any, infoIcon: any): {};
    getFragm(infoIcon: any): HTMLElement | DocumentFragment;
    getDocContent(infoIcon: any): any;
    isList($head: any, d: any): boolean;
    getParentNodeSize(state: EditorState): number;
    getParentStartPos(head: any): number;
    _isEnabled: (state: EditorState) => boolean;
    renderLabel(): void;
    isActive(): boolean;
    executeCustom(_state: EditorState, tr: Transform): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
}
