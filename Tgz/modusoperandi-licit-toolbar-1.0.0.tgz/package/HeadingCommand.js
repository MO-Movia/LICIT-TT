import { toggleHeading } from './toggleHeading';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export class HeadingCommand extends UICommand {
    constructor(level) {
        super();
        this.isActive = (_state) => {
            return true;
        };
        this.execute = (state, dispatch, _view) => {
            const { schema, selection } = state;
            const tr = toggleHeading(state.tr.setSelection(selection), schema, this._level);
            if (tr.docChanged) {
                dispatch === null || dispatch === void 0 ? void 0 : dispatch(tr);
                return true;
            }
            else {
                return false;
            }
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this.renderLabel = () => {
            return null;
        };
        this.executeCustom = (_state, tr) => {
            return tr;
        };
        this._level = level;
    }
    cancel() {
        return null;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
