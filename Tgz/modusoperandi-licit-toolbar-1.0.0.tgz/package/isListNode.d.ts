import { Node } from 'prosemirror-model';
export declare function isListNode(node: Node): boolean;
