import { TextSelection } from 'prosemirror-state';
import { BLOCKQUOTE, HEADING, LIST_ITEM, PARAGRAPH } from './NodeNames';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export function setTextAlign(tr, schema, alignment) {
    const { selection, doc } = tr;
    if (!selection || !doc) {
        return tr;
    }
    const { from, to } = selection;
    const { nodes } = schema;
    const blockquote = nodes[BLOCKQUOTE];
    const listItem = nodes[LIST_ITEM];
    const heading = nodes[HEADING];
    const paragraph = nodes[PARAGRAPH];
    const tasks = [];
    alignment = alignment || null;
    const allowedNodeTypes = new Set([blockquote, heading, listItem, paragraph]);
    doc.nodesBetween(from, to, (node, pos, _parentNode) => {
        const nodeType = node.type;
        const align = node.attrs.align || null;
        if (align !== alignment && allowedNodeTypes.has(nodeType)) {
            tasks.push({
                node,
                pos,
                nodeType,
            });
        }
        return true;
    });
    if (!tasks.length) {
        return tr;
    }
    tasks.forEach((job) => {
        const { node, pos, nodeType } = job;
        let { attrs } = node;
        if (alignment) {
            attrs = Object.assign(Object.assign({}, attrs), { align: alignment });
        }
        else {
            attrs = Object.assign(Object.assign({}, attrs), { align: null });
        }
        tr = tr.setNodeMarkup(pos, nodeType, attrs, node.marks);
    });
    return tr;
}
export class TextAlignCommand extends UICommand {
    constructor(alignment) {
        super();
        this.isActive = (state) => {
            const { selection, doc } = state;
            const { from, to } = selection;
            let keepLooking = true;
            let active = false;
            doc.nodesBetween(from, to, (node, _pos) => {
                if (keepLooking && node.attrs.align === this._alignment) {
                    keepLooking = false;
                    active = true;
                }
                return keepLooking;
            });
            return active;
        };
        this.isEnabled = (state) => {
            if (state) {
                return true;
            }
            return false;
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this.execute = (state, dispatch, _view) => {
            const { schema, selection } = state;
            const tr = setTextAlign(state.tr.setSelection(selection), schema, this._alignment);
            if (tr.docChanged) {
                dispatch === null || dispatch === void 0 ? void 0 : dispatch(tr);
                return true;
            }
            else {
                return false;
            }
        };
        // [FS] IRAD-1087 2020-10-01
        // New method to execute new styling implementation  text align
        this.executeCustom = (state, tr, from, to) => {
            const { schema } = state;
            tr = setTextAlign(tr.setSelection(TextSelection.create(tr.doc, from, to)), schema, this._alignment);
            return tr;
        };
        this._alignment = alignment;
    }
    cancel() {
        return null;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    renderLabel() {
        return null;
    }
}
