import { SetDocAttrStep, UICommand } from '@modusoperandi/licit-doc-attrs-step';
import DocLayoutEditor from '../ui/DocLayoutEditor';
import { createPopUp } from '@modusoperandi/licit-ui-commands';
function setDocLayout(tr, _schema, width, layout) {
    const { doc } = tr;
    if (!doc) {
        return tr;
    }
    tr = tr.step(new SetDocAttrStep('width', width || null));
    tr = tr.step(new SetDocAttrStep('layout', layout || null));
    return tr;
}
class DocLayoutCommand extends UICommand {
    constructor() {
        super(...arguments);
        this._popUp = null;
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.isEnabled = (_state) => {
            return true;
        };
        this.isActive = (_state) => {
            return !!this._popUp;
        };
        this.waitForUserInput = (state, _dispatch, _view, _event) => {
            if (this._popUp) {
                return Promise.resolve(undefined);
            }
            const { doc } = state;
            return new Promise((resolve) => {
                const props = {
                    initialValue: doc.attrs,
                };
                this._popUp = createPopUp(DocLayoutEditor, props, {
                    modal: true,
                    onClose: (val) => {
                        if (this._popUp) {
                            this._popUp = null;
                            resolve(val);
                        }
                    },
                });
            });
        };
        this.executeWithUserInput = (state, dispatch, view, inputs) => {
            if (dispatch) {
                const { selection, schema } = state;
                let { tr } = state;
                tr = tr.setSelection(selection);
                if (inputs) {
                    const { width, layout } = inputs;
                    tr = setDocLayout(tr, schema, width, layout);
                }
                this.getEditor().view.dispatch(tr);
                view && view.focus();
            }
            return false;
        };
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default DocLayoutCommand;
