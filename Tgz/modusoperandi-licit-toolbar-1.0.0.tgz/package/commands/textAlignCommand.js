import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TextAlignCommand extends UICommand {
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    constructor(alignment) {
        super();
        this.alignment = null;
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.isEnabled = (_state) => {
            return true;
        };
        this.execute = (_state, _dispatch, _view) => {
            return this.getEditor().commands.setTextAlign(this.alignment);
        };
        this.alignment = alignment;
    }
}
export default TextAlignCommand;
