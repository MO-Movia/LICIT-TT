import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class HistoryRedoCommand extends UICommand {
    constructor() {
        super(...arguments);
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.isEnabled = (_state) => {
            const history = _state.history$;
            if (history.undone.eventCount === 0) {
                return false;
            }
            else {
                return true;
            }
        };
        this.execute = (_state, _dispatch, _view) => {
            return this.getEditor().commands.redo();
        };
    }
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default HistoryRedoCommand;
