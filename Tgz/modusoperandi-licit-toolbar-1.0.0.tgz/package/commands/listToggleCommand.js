import { findParentNodeOfType } from 'prosemirror-utils';
import { ORDERED_LIST, BULLET_LIST, IMAGE, toggleList, isNodeSelectionForNodeType, noop, } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export class ListToggleCommand extends UICommand {
    constructor(ordered, type) {
        super();
        this.isActive = (state) => {
            let bOK = false;
            if (this._ordered) {
                bOK = !!this._findList(state, ORDERED_LIST);
            }
            else {
                bOK = !!this._findList(state, BULLET_LIST);
            }
            return bOK;
        };
        this.isEnabled = (state, _view) => {
            let bOK = false;
            bOK = hasImageNode(state);
            return !bOK;
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.execute = (state, dispatch, _view) => {
            const { selection, schema } = state;
            const nodeType = schema.nodes[this._ordered ? ORDERED_LIST : BULLET_LIST];
            let { tr } = state;
            tr = tr.setSelection(selection);
            if (!nodeType) {
                return tr;
            }
            tr = toggleList(tr, schema, nodeType, this._orderedListType);
            if (tr.docChanged) {
                dispatch && dispatch(tr);
                return true;
            }
            else {
                return false;
            }
        };
        this._ordered = ordered;
        this._orderedListType = type;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    _findList(state, type) {
        const { nodes } = state.schema;
        const list = nodes[type];
        const findList = list ? findParentNodeOfType(list) : noop;
        return findList(state.selection);
    }
}
// [FS] IRAD-1317 2021-05-06
// To disable the list menu in toolbar when select an image
export function hasImageNode(state) {
    const { selection, schema } = state;
    const imageNodeType = schema.nodes[IMAGE];
    return imageNodeType && isNodeSelectionForNodeType(selection, imageNodeType);
}
