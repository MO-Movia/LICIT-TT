import nullthrows from 'nullthrows';
import { ColorEditor, atAnchorRight, createPopUp, } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TableColorCommand extends UICommand {
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    constructor(attribute) {
        super();
        this._popUp = null;
        this.attribute = null;
        this.shouldRespondToUIEvent = (e) => {
            return e.type === UICommand.EventType.MOUSEENTER;
        };
        this.isEnabled = (_state) => {
            return true;
        };
        this.waitForUserInput = (_state, _dispatch, _view, event) => {
            // replaced any with PromiseConstructor seems to not cause any errors
            if (this._popUp) {
                return Promise.resolve(undefined);
            }
            const target = nullthrows(event).currentTarget;
            if (!(target instanceof HTMLElement)) {
                return Promise.resolve(undefined);
            }
            const anchor = event ? event.currentTarget : null;
            return new Promise((resolve) => {
                this._popUp = createPopUp(ColorEditor, null, {
                    anchor,
                    position: atAnchorRight,
                    onClose: (val) => {
                        if (this._popUp) {
                            this._popUp = null;
                            resolve(val);
                        }
                    },
                });
            });
        };
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.executeWithUserInput = (_state, _dispatch, _view, hex) => {
            if (hex !== undefined) {
                return this.getEditor().commands.setCellAttribute(this.attribute, hex);
            }
            return false;
        };
        this.attribute = attribute;
    }
    cancel() {
        this._popUp && this._popUp.close(undefined);
    }
}
export default TableColorCommand;
