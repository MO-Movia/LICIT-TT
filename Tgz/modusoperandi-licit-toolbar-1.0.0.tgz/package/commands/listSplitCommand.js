import splitListItem from '../SplitListItem';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class ListSplitCommand extends UICommand {
    constructor() {
        super();
        this.isEnabled = (_state) => {
            return true;
        };
        this.execute = (state, dispatch, _view) => {
            const { selection, schema } = state;
            const tr = splitListItem(state.tr.setSelection(selection), schema);
            if (tr.docChanged) {
                dispatch && dispatch(tr);
                return true;
            }
            else {
                return false;
            }
        };
    }
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default ListSplitCommand;
