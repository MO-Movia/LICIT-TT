import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import type { DocLayoutEditorValue } from '../ui/DocLayoutEditor';
import { Editor } from '@tiptap/react';
declare class DocLayoutCommand extends UICommand {
    _popUp: any;
    getEditor: () => Editor;
    isEnabled: (_state: EditorState) => boolean;
    isActive: (_state: EditorState) => boolean;
    waitForUserInput: (state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<PromiseConstructor>;
    executeWithUserInput: (state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, inputs?: DocLayoutEditorValue) => boolean;
    cancel(): void;
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
}
export default DocLayoutCommand;
