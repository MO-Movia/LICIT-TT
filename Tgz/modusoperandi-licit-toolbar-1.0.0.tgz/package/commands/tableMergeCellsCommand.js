import { CellSelection } from 'prosemirror-tables';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TableMergeCellsCommand extends UICommand {
    constructor() {
        super(...arguments);
        this.isEnabled = (_state) => {
            return true;
        };
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.execute = (state, _dispatch, _view) => {
            const { selection } = state;
            if (selection instanceof CellSelection) {
                return this.getEditor().commands.mergeCells();
                // this.getEditor().commands.
            }
            return false;
        };
    }
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default TableMergeCellsCommand;
