import { EditorState, Transaction } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { ContentNodeWithPos } from 'prosemirror-utils';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { Editor } from '@tiptap/react';
export declare class ListToggleCommand extends UICommand {
    _ordered: boolean;
    _orderedListType: string;
    constructor(ordered: boolean, type: string);
    isActive: (state: EditorState) => boolean;
    isEnabled: (state: EditorState, _view?: EditorView) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    getEditor: () => Editor;
    executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => Transaction | boolean;
    _findList(state: EditorState, type: string): ContentNodeWithPos | void;
}
export declare function hasImageNode(state: EditorState): boolean;
