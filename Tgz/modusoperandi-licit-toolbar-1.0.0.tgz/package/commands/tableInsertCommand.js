import nullthrows from 'nullthrows';
import { TextSelection } from 'prosemirror-state';
import { atAnchorRight, createPopUp } from '@modusoperandi/licit-ui-commands';
import TableGridSizeEditor from '../ui/TableGridSizeEditor';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TableInsertCommand extends UICommand {
    constructor() {
        super(...arguments);
        this._popUp = null;
        this.shouldRespondToUIEvent = (e) => {
            return e.type === UICommand.EventType.MOUSEENTER;
        };
        this.isEnabled = (state) => {
            const tr = state;
            let bOK = false;
            const { selection } = tr;
            if (selection instanceof TextSelection) {
                bOK = selection.from === selection.to;
                // [FS] IRAD-1065 2020-09-18
                // Disable create table menu if the selection is inside a table.
                if (bOK) {
                    const $head = selection.$head;
                    for (let d = $head.depth; d > 0; d--) {
                        if ($head.node(d).type.spec.tableRole == 'row') {
                            return false;
                        }
                    }
                }
                return bOK;
            }
            return bOK;
        };
        this.waitForUserInput = (_state, _dispatch, _view, event) => {
            // replaced any with PromiseConstructor seems to not cause any errors
            if (this._popUp) {
                return Promise.resolve(undefined);
            }
            const target = nullthrows(event).currentTarget;
            if (!(target instanceof HTMLElement)) {
                return Promise.resolve(undefined);
            }
            const anchor = event ? event.currentTarget : null;
            return new Promise((resolve) => {
                this._popUp = createPopUp(TableGridSizeEditor, null, {
                    anchor,
                    position: atAnchorRight,
                    onClose: (val) => {
                        if (this._popUp) {
                            this._popUp = null;
                            resolve(val);
                            const element = document.getElementById(anchor.offsetParent.id);
                            element.remove();
                        }
                    },
                });
            });
        };
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.executeWithUserInput = (_state, _dispatch, _view, inputs) => {
            if (inputs) {
                const { rows, cols } = inputs;
                return this.getEditor().commands.insertTable({ rows, cols });
            }
            return false;
        };
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default TableInsertCommand;
