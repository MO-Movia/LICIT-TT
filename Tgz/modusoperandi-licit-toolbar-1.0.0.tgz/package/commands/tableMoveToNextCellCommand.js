import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class TableMoveToNextCellCommand extends UICommand {
    constructor() {
        super(...arguments);
        this.getEditor = () => {
            return UICommand.prototype.editor;
        };
        this.isEnabled = (_state) => {
            return true;
        };
        this.execute = (_state, _dispatch, _view) => {
            return this.getEditor().commands.goToNextCell();
        };
    }
    waitForUserInput(state, dispatch, view, event) {
        return Promise.resolve(null);
    }
    executeWithUserInput(state, dispatch, view, inputs) {
        return false;
    }
    cancel() {
        return null;
    }
    executeCustom(state, tr, from, to) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export default TableMoveToNextCellCommand;
