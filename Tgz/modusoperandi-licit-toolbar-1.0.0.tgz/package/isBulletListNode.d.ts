import { Node } from 'prosemirror-model';
export declare function isBulletListNode(node: Node): boolean;
