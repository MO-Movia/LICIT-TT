import { Node, NodeType, Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import type { SelectionMemo } from './transformAndPreserveTextSelection';
export declare function toggleList(tr: Transform, schema: Schema, listNodeType: NodeType, listStyleType: string): Transform;
export declare function unwrapNodesFromList(tr: Transform, schema: Schema, listNodePos: number, unwrapParagraphNode?: (Node: any) => Node): Transform;
export declare function wrapNodesWithList(tr: Transform, schema: Schema, listNodeType: NodeType, listStyleType: string, newselection?: any): Transform;
export declare function wrapNodesWithListInternal(memo: SelectionMemo, listNodeType: NodeType, listStyleType: string, newselection?: any): Transform;
export declare function wrapItemsWithListInternal(tr: Transform, schema: Schema, listNodeType: NodeType, items: Array<{
    node: Node;
    pos: number;
}>, listStyleType: string): Transform;
export declare function unwrapNodesFromListInternal(memo: SelectionMemo, listNodePos: number, unwrapParagraphNode?: (Node: any) => Node): Transform;
