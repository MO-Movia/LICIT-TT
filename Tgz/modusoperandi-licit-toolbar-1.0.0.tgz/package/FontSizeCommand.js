import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { applyMark } from './applyMark';
import { isTextStyleMarkCommandEnabled } from './isTextStyleMarkCommandEnabled';
import { TextSelection } from 'prosemirror-state';
import { MARK_FONT_SIZE } from './MarkNames';
function setFontSize(tr, schema, pt, isCustomStyleApplied) {
    const markType = schema.marks[MARK_FONT_SIZE];
    if (!markType) {
        return tr;
    }
    const attrs = pt ? { pt } : null;
    tr = applyMark(tr, schema, markType, attrs, isCustomStyleApplied);
    return tr;
}
export class FontSizeCommand extends UICommand {
    constructor(pt) {
        super();
        this._popUp = null;
        this._pt = 0;
        this.isEnabled = (state) => {
            return isTextStyleMarkCommandEnabled(state, MARK_FONT_SIZE);
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this.execute = (state, dispatch
        // view?: EditorView
        ) => {
            const { schema } = state;
            // commnted selection because selection removes the storedMarks;
            // {selection}
            // const tr = setFontSize(state.tr.setSelection(selection), schema, this._pt);
            const tr = setFontSize(state.tr, schema, this._pt);
            if (tr.docChanged || tr.storedMarksSet) {
                // If selection is empty, the color is added to `storedMarks`, which
                // works like `toggleMark`
                // (see https://prosemirror.net/docs/ref/#commands.toggleMark).
                dispatch === null || dispatch === void 0 ? void 0 : dispatch(tr);
                return true;
            }
            return false;
        };
        // [FS] IRAD-1087 2020-10-01
        // Method to execute custom styling implementation of font size
        this.executeCustom = (state, tr, from, to) => {
            const { schema } = state;
            tr = setFontSize(tr.setSelection(TextSelection.create(tr.doc, from, to)), schema, this._pt, true);
            return tr;
        };
        this._pt = pt;
    }
    cancel() {
        return null;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    isActive() {
        return true;
    }
    renderLabel() {
        return null;
    }
}
