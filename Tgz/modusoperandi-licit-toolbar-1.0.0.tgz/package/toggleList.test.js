import { toggleList, unwrapNodesFromListInternal, wrapItemsWithListInternal, wrapNodesWithList, wrapNodesWithListInternal } from './toggleList';
import { Schema } from 'prosemirror-model';
// import { ContentNodeWithPos } from 'prosemirror-utils/dist/types';
describe('toggleList', () => {
    let schema;
    let trr;
    beforeEach(() => {
        schema = new Schema({
            nodes: {
                doc: { content: 'text*' },
                text: {},
            },
            marks: {
                bold: {},
            },
        });
        trr = document.createElement('tr');
        // Add some descendant nodes for testing
        trr.innerHTML = '<td>Cell 1</td><td>Cell 2</td><td>Cell 3</td>';
    });
    const mySchema = new Schema({
        nodes: {
            doc: {
                attrs: { lineSpacing: { default: 'test' } },
                content: 'block+',
            },
            paragraph: {
                attrs: { lineSpacing: { default: 'test' } },
                content: 'text*',
                group: 'block',
            },
            heading: {
                attrs: { lineSpacing: { default: 'test' } },
                content: 'text*',
                group: 'block',
                defining: true,
            },
            bullet_list: {
                content: 'list_item+',
                group: 'block',
            },
            list_item: {
                attrs: { lineSpacing: { default: 'test' } },
                content: 'paragraph',
                defining: true,
            },
            blockquote: {
                attrs: { lineSpacing: { default: 'test' } },
                content: 'block+',
                group: 'block',
            },
            text: {
                inline: true,
            },
        },
    });
    // Create a dummy document using the defined schema
    const dummyDoc = mySchema.node('doc', null, [
        mySchema.node('heading', { lineSpacing: 'test' }, [
            mySchema.text('Heading 1'),
        ]),
        mySchema.node('paragraph', { lineSpacing: 'test' }, [
            mySchema.text('This is a paragraph'),
        ]),
        mySchema.node('bullet_list', { lineSpacing: 'test' }, [
            mySchema.node('list_item', { lineSpacing: 'test' }, [
                mySchema.node('paragraph', { lineSpacing: 'test' }, [
                    mySchema.text('List item 1'),
                ]),
            ]),
            mySchema.node('list_item', { lineSpacing: 'test' }, [
                mySchema.node('paragraph', { lineSpacing: 'test' }, [
                    mySchema.text('List item 2'),
                ]),
            ]),
        ]),
        mySchema.node('blockquote', { lineSpacing: 'test' }, [
            mySchema.node('paragraph', { lineSpacing: 'test' }, [
                mySchema.text('This is a blockquote'),
            ]),
        ]),
    ]);
    it('should be selection is not there or doc is not there', () => {
        const tr = {
            selection: { from: 1, to: 2 },
        };
        const listNodeType = {};
        const test = toggleList(tr, schema, listNodeType, 'bold');
        expect(test).toBe(tr);
    });
    it('should handle toggleList', () => {
        const tr = {
            selection: { from: 1, to: 2 }, doc: dummyDoc
        };
        const listNodeType = {};
        const test = toggleList(tr, schema, listNodeType, 'bold');
        expect(test).toBe(tr);
    });
    describe('wrapItemsWithListInternal', () => {
        const items = [
            { node: { id: 1, name: 'Node 1', marks: 'fg' }, pos: 2 },
        ];
        it('should wrap items with a list', () => {
            const tr = {};
            const sc = { nodes: {} };
            const list_node = {};
            const test = wrapItemsWithListInternal(tr, sc, list_node, items, '');
            expect(test).toBeDefined();
        });
        it('should return the transform  when paragraph is there ', () => {
            const tr = {};
            const sc = { nodes: { paragraph: {} } };
            const list_node = {};
            const test = wrapItemsWithListInternal(tr, sc, list_node, items, '');
            expect(test).toBeDefined();
        });
        it('should return the transform  when both paragraph and listitem is there', () => {
            const tr = {
                setNodeMarkup: (_a) => {
                    return {
                        setNodeMarkup: (_a) => {
                            return {
                                doc: {
                                    nodeAt: (_b) => {
                                        return;
                                    },
                                },
                            };
                        },
                        doc: {
                            nodeAt: (_b) => {
                                return;
                            },
                        },
                    };
                },
                doc: {
                    nodeAt: (_b) => {
                        return;
                    },
                },
            };
            const sc = { nodes: { paragraph: {}, list_item: {} } };
            const list_node = {};
            const test = wrapItemsWithListInternal(tr, sc, list_node, items, '');
            expect(test).toBeDefined();
        });
        it('should return the transform if not equal to firstNode and lastNode', () => {
            const tr = {
                setNodeMarkup: (_a) => {
                    return {
                        setNodeMarkup: (_a) => {
                            return {
                                doc: {
                                    nodeAt: (_b) => {
                                        return;
                                    },
                                },
                            };
                        },
                        doc: {
                            nodeAt: (_b) => {
                                return { attrs: { id: null } };
                            },
                        },
                    };
                },
                doc: dummyDoc,
            };
            const sc = { nodes: { paragraph: {}, list_item: {} } };
            const list_node = {};
            const test = wrapItemsWithListInternal(tr, sc, list_node, items, '');
            expect(test).toBeDefined();
        });
        it('should return the transform if not equal to firstNode and lastNode', () => {
            const schema = new Schema({
                nodes: {
                    doc: { content: 'block+' },
                    paragraph: { content: 'inline*', group: 'block' },
                    heading: { content: 'inline*', marks: '_', group: 'block' },
                    text: { group: 'inline' },
                },
                marks: {},
            });
            // Sample document for testing
            const sampleDocument = schema.nodeFromJSON({
                type: 'doc',
                content: [
                    {
                        type: 'paragraph',
                        content: [
                            {
                                type: 'text',
                                text: 'This is a sample ProseMirror document with ',
                            },
                        ],
                    },
                    {
                        type: 'heading',
                        attrs: { id: {} },
                        content: [{ type: 'text', text: 'A Heading' }],
                    },
                ],
            });
            // Create a document using the schema.
            const doc1 = sampleDocument;
            jest
                .spyOn(doc1, 'nodeAt')
                .mockReturnValueOnce({ attrs: { id: {} } });
            const tr = {
                setNodeMarkup: (_a) => {
                    return {
                        setNodeMarkup: (_a) => {
                            return {
                                doc: {
                                    nodeAt: (_b) => {
                                        return;
                                    },
                                },
                            };
                        },
                        doc: doc1,
                    };
                },
                doc: dummyDoc,
            };
            const sc = { nodes: { paragraph: {}, list_item: {} } };
            const list_node = {};
            const test = wrapItemsWithListInternal(tr, sc, list_node, items, '');
            expect(test).toBeDefined();
        });
    });
});
describe('wrapNodesWithListInternal', () => {
    it('should handle wrapNodesWithListInternal', () => {
        const mySchema = new Schema({
            nodes: {
                doc: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'block+',
                },
                paragraph: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'text*',
                    group: 'block',
                },
                heading: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'text*',
                    group: 'block',
                    defining: true,
                },
                bullet_list: {
                    content: 'list_item+',
                    group: 'block',
                },
                list_item: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'paragraph',
                    defining: true,
                },
                blockquote: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'block+',
                    group: 'block',
                },
                text: {
                    inline: true,
                },
            },
        });
        // Create a dummy document using the defined schema
        const dummyDoc = mySchema.node('doc', null, [
            mySchema.node('heading', { lineSpacing: 'test' }, [
                mySchema.text('Heading 1'),
            ]),
            mySchema.node('paragraph', { lineSpacing: 'test' }, [
                mySchema.text('This is a paragraph'),
            ]),
            mySchema.node('bullet_list', { lineSpacing: 'test' }, [
                mySchema.node('list_item', { lineSpacing: 'test' }, [
                    mySchema.node('paragraph', { lineSpacing: 'test' }, [
                        mySchema.text('List item 1'),
                    ]),
                ]),
                mySchema.node('list_item', { lineSpacing: 'test' }, [
                    mySchema.node('paragraph', { lineSpacing: 'test' }, [
                        mySchema.text('List item 2'),
                    ]),
                ]),
            ]),
            mySchema.node('blockquote', { lineSpacing: 'test' }, [
                mySchema.node('paragraph', { lineSpacing: 'test' }, [
                    mySchema.text('This is a blockquote'),
                ]),
            ]),
        ]);
        dummyDoc.nodeAt = () => { return {}; };
        const tr = {
            selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => {
                return {
                    selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => { return {}; }
                };
            }
        };
        const memo = { tr: tr, schema: mySchema };
        expect(wrapNodesWithListInternal(memo, null, 'test')).toBeDefined();
    });
});
describe('unwrapNodesFromListInternal', () => {
    it('should handle unwrapNodesFromListInternal', () => {
        const mySchema = new Schema({
            nodes: {
                doc: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'block+',
                },
                paragraph: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'text*',
                    group: 'block',
                },
                heading: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'text*',
                    group: 'block',
                    defining: true,
                },
                bullet_list: {
                    content: 'list_item+',
                    group: 'block',
                },
                list_item: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'paragraph',
                    defining: true,
                },
                blockquote: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'block+',
                    group: 'block',
                },
                text: {
                    inline: true,
                },
            },
        });
        // Create a dummy document using the defined schema
        const dummyDoc = mySchema.node('doc', null, [
            mySchema.node('heading', { lineSpacing: 'test' }, [
                mySchema.text('Heading 1'),
            ]),
            mySchema.node('paragraph', { lineSpacing: 'test' }, [
                mySchema.text('This is a paragraph'),
            ]),
            mySchema.node('bullet_list', { lineSpacing: 'test' }, [
                mySchema.node('list_item', { lineSpacing: 'test' }, [
                    mySchema.node('paragraph', { lineSpacing: 'test' }, [
                        mySchema.text('List item 1'),
                    ]),
                ]),
                mySchema.node('list_item', { lineSpacing: 'test' }, [
                    mySchema.node('paragraph', { lineSpacing: 'test' }, [
                        mySchema.text('List item 2'),
                    ]),
                ]),
            ]),
            mySchema.node('blockquote', { lineSpacing: 'test' }, [
                mySchema.node('paragraph', { lineSpacing: 'test' }, [
                    mySchema.text('This is a blockquote'),
                ]),
            ]),
        ]);
        dummyDoc.nodeAt = () => { return {}; };
        const trA = {
            selection: { from: 1, to: 2 }, doc: null, setNodeMarkup: () => {
                return {
                    selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => { return {}; }
                };
            }
        };
        const trB = {
            selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => {
                return {
                    selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => { return {}; }
                };
            }
        };
        const memo = { tr: trA, schema: mySchema };
        expect(unwrapNodesFromListInternal(memo, 0)).toBeDefined();
        const memoA = { tr: trB, schema: { nodes: {} } };
        expect(unwrapNodesFromListInternal(memoA, 0)).toBeDefined();
    });
});
describe('wrapNodesWithList', () => {
    it('should handle wrapNodesWithList', () => {
        const mySchema = new Schema({
            nodes: {
                doc: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'block+',
                },
                paragraph: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'text*',
                    group: 'block',
                },
                heading: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'text*',
                    group: 'block',
                    defining: true,
                },
                bullet_list: {
                    content: 'list_item+',
                    group: 'block',
                },
                list_item: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'paragraph',
                    defining: true,
                },
                blockquote: {
                    attrs: { lineSpacing: { default: 'test' } },
                    content: 'block+',
                    group: 'block',
                },
                text: {
                    inline: true,
                },
            },
        });
        // Create a dummy document using the defined schema
        const dummyDoc = mySchema.node('doc', null, [
            mySchema.node('heading', { lineSpacing: 'test' }, [
                mySchema.text('Heading 1'),
            ]),
            mySchema.node('paragraph', { lineSpacing: 'test' }, [
                mySchema.text('This is a paragraph'),
            ]),
            mySchema.node('bullet_list', { lineSpacing: 'test' }, [
                mySchema.node('list_item', { lineSpacing: 'test' }, [
                    mySchema.node('paragraph', { lineSpacing: 'test' }, [
                        mySchema.text('List item 1'),
                    ]),
                ]),
                mySchema.node('list_item', { lineSpacing: 'test' }, [
                    mySchema.node('paragraph', { lineSpacing: 'test' }, [
                        mySchema.text('List item 2'),
                    ]),
                ]),
            ]),
            mySchema.node('blockquote', { lineSpacing: 'test' }, [
                mySchema.node('paragraph', { lineSpacing: 'test' }, [
                    mySchema.text('This is a blockquote'),
                ]),
            ]),
        ]);
        dummyDoc.nodeAt = () => { return {}; };
        const tr = {
            getMeta: () => { return {}; },
            selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => {
                return {
                    selection: { from: 1, to: 2 }, doc: dummyDoc, setNodeMarkup: () => { return {}; }
                };
            }
        };
        expect(wrapNodesWithList(tr, mySchema, null, 'test')).toBeDefined();
    });
});
