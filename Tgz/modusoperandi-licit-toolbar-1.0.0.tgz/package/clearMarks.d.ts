import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare function clearMarks(tr: Transform, schema: Schema): Transform;
export declare function clearHeading(tr: Transform, schema: Schema): Transform;
