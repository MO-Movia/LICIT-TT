import { TextSelection } from 'prosemirror-state';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { updateIndentLevel } from './updateIndentLevel';
export class IndentCommand extends UICommand {
    constructor(delta) {
        super();
        this.isActive = (_state) => {
            return true;
        };
        this.execute = (state, dispatch, _view) => {
            const { selection, schema } = state;
            let { tr } = state;
            tr = tr.setSelection(selection);
            const trx = updateIndentLevel(state, tr, schema, this._delta, _view);
            if (trx.docChanged) {
                dispatch === null || dispatch === void 0 ? void 0 : dispatch(trx.tr);
            }
            return true;
        };
        // [FS] IRAD-1087 2020-11-11
        // New method to execute new styling implementation for indent
        this.executeCustom = (state, tr, from, to) => {
            const { schema } = state;
            tr = tr.setSelection(TextSelection.create(tr.doc, from, to));
            const trx = updateIndentLevel(state, tr, schema, this._delta, null);
            return trx.tr;
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this._delta = delta;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    cancel() {
        return null;
    }
    renderLabel() {
        return null;
    }
}
