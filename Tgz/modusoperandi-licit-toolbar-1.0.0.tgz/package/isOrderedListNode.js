import { ORDERED_LIST } from './NodeNames';
export function isOrderedListNode(node) {
    return node.type.name === ORDERED_LIST;
}
