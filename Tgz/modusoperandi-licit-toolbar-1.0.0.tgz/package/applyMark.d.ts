import { MarkType, Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare function applyMark(tr: Transform, _schema: Schema, markType: MarkType, attrs?: Record<string, unknown>, isCustomStyleApplied?: boolean): Transform;
