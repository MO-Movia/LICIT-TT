import { Selection } from 'prosemirror-state';
import { NodeType } from 'prosemirror-model';
export declare function isNodeSelectionForNodeType(selection: Selection, nodeType: NodeType): boolean;
