import { Mark, MarkType, Node } from 'prosemirror-model';
type Result = {
    mark: Mark;
    from: {
        node: Node;
        pos: number;
    };
    to: {
        node: Node;
        pos: number;
    };
};
export declare function findNodesWithSameMark(doc: Node, from: number, to: number, markType: MarkType): Result | null;
export {};
