import cx from 'classnames';
import * as React from 'react';
import CommandMenu from './CommandMenu';
import { CustomButton, createPopUp, atAnchorRight, ThemeContext } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { uuid } from './uuid';
import { isExpandButton } from '../EditorTollbarConfig';
import '../styles/czi-custom-menu-button.css';
class CommandMenuButton extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._menu = null;
        this._id = uuid();
        this.state = {
            expanded: false,
        };
        this._onClick = () => {
            const expanded = !this.state.expanded;
            this.setState({
                expanded,
            });
            expanded ? this._showMenu() : this._hideMenu();
        };
        this._hideMenu = () => {
            const menu = this._menu;
            this._menu = null;
            menu && menu.close();
            // alert('hello seybi');
        };
        this._showMenu = () => {
            const menu = this._menu;
            const menuProps = Object.assign(Object.assign({}, this.props), { onCommand: this._onCommand, theme: UICommand.theme });
            if (menu) {
                menu.update(menuProps);
            }
            else {
                let hasPopupId = false;
                if (menuProps.commandGroups[0]['Insert Table...']) {
                    hasPopupId = true;
                }
                const popUpProps = {
                    anchor: document.getElementById(this._id),
                    onClose: this._onClose,
                    IsChildDialog: true,
                    autoDismiss: true,
                    popUpId: menuProps.commandGroups[0]['Single']
                        ? 'mo-menuList-1'
                        : 'mo-menuList',
                };
                if (hasPopupId) {
                    popUpProps.popUpId = null;
                }
                if (this.props.sub) {
                    popUpProps['position'] = atAnchorRight;
                }
                this._menu = createPopUp(CommandMenu, menuProps, popUpProps);
            }
        };
        this._onCommand = () => {
            this.setState({ expanded: false });
            this._hideMenu();
        };
        this._onClose = () => {
            if (this._menu) {
                this.setState({ expanded: false });
                this._menu = null;
            }
        };
    }
    render() {
        let hasChild = false;
        const { className, label, commandGroups, editorState, editorView, icon, disabled, title, sub, theme } = this.props;
        const enabled = !disabled &&
            commandGroups.some((group) => {
                return Object.keys(group).some((grpLabel) => {
                    hasChild = true;
                    const command = group[grpLabel];
                    let disabledVal = true;
                    try {
                        disabledVal =
                            !editorView ||
                                !command.isEnabled(editorState, editorView, grpLabel);
                    }
                    catch (ex) {
                        disabledVal = false;
                    }
                    return !disabledVal;
                });
            });
        const { expanded } = this.state;
        const isMaximizeButton = isExpandButton(title);
        // const theme_1 = this.context;
        const theme_1 = UICommand.theme;
        // const buttonClassName = sub
        //   ? cx(className, {
        //       'czi-custom-submenu-button': true,
        //       expanded,
        //     })
        //   : cx(className, {
        //       'czi-custom-menu-button': true,
        //       expanded,
        //     });
        // let className = 'czi-custom-menu-item ' + theme;
        const buttonClassName = cx(className, {
            'czi-custom-menu-button': true,
            'menu-expand-btn': isMaximizeButton,
            expanded,
        });
        return (React.createElement(CustomButton, { className: buttonClassName, disabled: !enabled, hasChild: (hasChild && !isMaximizeButton), icon: icon, id: this._id, label: label, onClick: this._onClick, theme: theme_1.toString(), title: title }));
    }
    componentWillUnmount() {
        this._hideMenu();
    }
}
CommandMenuButton.contextType = ThemeContext;
export default CommandMenuButton;
