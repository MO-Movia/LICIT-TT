import cx from 'classnames';
import * as React from 'react';
import ReactDOM from 'react-dom';
import CommandButton from './CommandButton';
import CommandMenuButton from './CommandMenuButton';
import { CustomButton, ThemeContext } from '@modusoperandi/licit-ui-commands';
import { COMMAND_GROUPS, parseLabel } from '../EditorTollbarConfig';
import Icon from './Icon';
import ResizeObserver from '../ResizeObserver';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import isReactClass from '../IsReactClass';
import '../styles/czi-editor-toolbar.css';
export class EditorToolbar extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._body = null;
        this.state = {
            expanded: false,
            wrapped: null,
        };
        this.groupMenuItems = (items) => {
            const groups = [];
            let prefix = 1;
            items.forEach((item) => {
                const groupName = item.group || 'Ungrouped'; // Use 'Ungrouped' for missing groups
                // if (!groups[prefix]) {
                //   groups[prefix] = [];
                // }
                if (groups.findIndex((item) => item.group === groupName) < 0) {
                    const x = items.filter((a) => { return a.group === groupName; });
                    groups.push({ [prefix]: Object.assign({}, x), group: groupName });
                }
                prefix++;
            });
            return groups;
        };
        this.sortGroupItems = (items) => items.sort((a, b) => a.order - b.order);
        this.orderedMenuData = (menuData) => Object.entries(menuData).reduce((acc, [groupName, items]) => {
            acc[groupName] = this.sortGroupItems(items);
            return acc;
        }, {});
        this._renderButtonsGroup = (group, index) => {
            const theme = this.context;
            console.log('se ' + theme);
            const buttons = Object.keys(group)
                .map((label) => {
                const obj = group[label];
                if (isReactClass(obj)) {
                    // JSX requies the component to be named with upper camel case.
                    const ThatComponent = obj;
                    const { editorState, editorView, dispatchTransaction } = this.props;
                    return (React.createElement(ThatComponent, { dispatch: dispatchTransaction, editorState: editorState, editorView: editorView, key: label }));
                }
                else if (obj instanceof UICommand) {
                    return this._renderButton(label, obj, theme.toString());
                }
                else if (Array.isArray(obj)) {
                    return this._renderMenuButton(label, obj);
                }
                else {
                    return null;
                }
            })
                .filter(Boolean);
            return (React.createElement("div", { className: `czi-custom-buttons ${theme}` }, buttons));
        };
        this._renderButtonsGroup_1 = (group, index) => {
            const keys = Object.keys(group);
            const theme = this.context;
            console.log('se ' + theme);
            const newgroup = group[keys[0]];
            const buttons = [];
            index = 0;
            Object.entries(newgroup).forEach(([key, value]) => {
                buttons.push(Object.keys(value)
                    .map((label) => {
                    if (label !== 'group') {
                        const obj = newgroup[index][label];
                        index++;
                        if (isReactClass(obj)) {
                            // JSX requies the component to be named with upper camel case.
                            const ThatComponent = obj;
                            const { editorState, editorView, dispatchTransaction } = this.props;
                            return (React.createElement(ThatComponent, { dispatch: dispatchTransaction, editorState: editorState, editorView: editorView, key: label }));
                        }
                        else if (obj instanceof UICommand) {
                            return this._renderButton(label, obj, theme.toString());
                        }
                        else if (Array.isArray(obj)) {
                            return this._renderMenuButton(label, obj);
                        }
                        else {
                            return null;
                        }
                    }
                })
                    .filter(Boolean));
            });
            return (React.createElement("div", { className: `czi-custom-buttons ${theme}` }, buttons));
        };
        // _renderButtonsGroup_Order = (
        //   group: ToolbarMenuConfig,
        //   index: number
        // ): React.ReactElement => {
        //   const theme = this.context;
        //   console.log('se ' + theme);
        //   const obj = group.menuCommand;
        //   const buttons = this.createmenuButtons(group, theme.toString());
        //   return (
        //     <div className="czi-custom-buttons" key={'g' + String(index)}>
        //       {buttons}
        //     </div>
        //   );
        // };
        // createmenuButtons = (
        //   group: ToolbarMenuConfig,
        //   theme: string
        // ): React.ReactElement => {
        //   if (isReactClass(group.menuCommand)) {
        //     // JSX requies the component to be named with upper camel case.
        //     const ThatComponent = group.menuCommand;
        //     const { editorState, editorView, dispatchTransaction } = this.props;
        //     return (
        //       <ThatComponent
        //         dispatch={dispatchTransaction}
        //         editorState={editorState}
        //         editorView={editorView}
        //         key={group.key}
        //       />
        //     );
        //   } else if (group.menuCommand instanceof UICommand) {
        //     return this._renderButton(group.key, group.menuCommand, theme.toString());
        //   } else if (Array.isArray(group.menuCommand)) {
        //     return this._renderMenuButton(group.key, group.menuCommand);
        //   } else {
        //     const keysArray = Object.keys(group.menuCommand);
        //     // Access the first key
        //     const firstKey = keysArray && keysArray.length > 0 ? keysArray[0] : undefined;
        //     if (firstKey && Array.isArray(group.menuCommand[firstKey])) {
        //       return this._renderMenuButton(group.key, group.menuCommand[firstKey]);
        //     }
        //     return null;
        //   }
        // }
        this._renderMenuButton = (label, commandGroups) => {
            const { editorState, editorView, disabled, dispatchTransaction } = this.props;
            const theme = this.context;
            console.log('separseLabel ' + theme);
            const { icon, title } = parseLabel(label, theme ? theme.toString() : 'dark');
            return (React.createElement(CommandMenuButton, { commandGroups: commandGroups, disabled: disabled, dispatch: dispatchTransaction, editorState: editorState, editorView: editorView, icon: icon, key: label, label: icon ? null : title, title: title }));
        };
        this._renderButton = (label, command, theme) => {
            const { disabled, editorState, editorView, dispatchTransaction } = this.props;
            const { icon, title } = parseLabel(label, theme);
            return (React.createElement(CommandButton, { command: command, disabled: disabled, dispatch: dispatchTransaction, editorState: editorState, editorView: editorView, icon: icon, key: label, label: icon ? null : title, title: title }));
        };
        this._onBodyRef = (ref) => {
            if (ref) {
                this._body = ref;
                // Mounting
                const el = ReactDOM.findDOMNode(ref);
                if (el instanceof HTMLElement) {
                    ResizeObserver.observe(el, this._checkIfContentIsWrapped);
                }
            }
            else {
                // Unmounting.
                const el = this._body && ReactDOM.findDOMNode(this._body);
                if (el instanceof HTMLElement) {
                    ResizeObserver.unobserve(el);
                }
                this._body = null;
            }
        };
        this._checkIfContentIsWrapped = () => {
            const ref = this._body;
            const el = ref && ReactDOM.findDOMNode(ref);
            const startAnchor = el && el.firstChild;
            const endAnchor = el && el.lastChild;
            if (startAnchor && endAnchor) {
                const wrapped = startAnchor.offsetTop <
                    endAnchor.offsetTop;
                this.setState({ wrapped });
            }
        };
        this._toggleExpansion = (expanded) => {
            this.setState({ expanded: !expanded });
        };
    }
    render() {
        const { wrapped, expanded } = this.state;
        const { toolbarConfig } = this.props;
        const theme = this.context;
        console.log(theme);
        let commandGroups;
        let className = cx('czi-editor-toolbar', { expanded, wrapped });
        const toolbarBodyClass = cx('czi-editor-toolbar-body-content', theme);
        if (expanded && !wrapped) {
            className = 'czi-editor-toolbar';
        }
        const expVal = expanded ? 1 : 0;
        const wrappedButton = wrapped ? (React.createElement(CustomButton, { active: expanded, className: "czi-editor-toolbar-expand-button", icon: Icon.get('more_horiz'), key: "expand", onClick: this._toggleExpansion, theme: theme.toString(), title: "More", value: expVal })) : null;
        if (toolbarConfig && toolbarConfig.length > 0) {
            toolbarConfig.sort((a, b) => a.menuPosition - b.menuPosition);
            const pluginObjects = toolbarConfig
                .filter((item) => item.isPlugin === true)
                .map((toolbarObj) => {
                const matchingPlugin = this.props.editorState.plugins.find((plugin) => plugin.key === toolbarObj.key);
                if (matchingPlugin) {
                    // Return a new object with properties from both toolbar and plugin
                    return Object.assign(Object.assign({}, toolbarObj), { menuCommand: matchingPlugin.initButtonCommands(theme) });
                }
                return null; // If no matching plugin is found
            })
                .filter(Boolean); // Remove null entries
            console.log(pluginObjects);
            if (pluginObjects && pluginObjects.length > 0) {
                toolbarConfig.map(obj2 => {
                    const correspondingObj = pluginObjects.find(obj1 => obj1.key === obj2.key);
                    if (correspondingObj) {
                        obj2.menuCommand = correspondingObj.menuCommand;
                        obj2.key = correspondingObj.key;
                    }
                    return obj2;
                });
                console.log(toolbarConfig);
            }
            const m = this.processMenuItems(toolbarConfig);
            const k = this.groupMenuItems(m);
            // let d = [this.orderedMenuData(k)];
            commandGroups = k.map(this._renderButtonsGroup_1).filter(Boolean);
        }
        else {
            // const theme = theme;
            // Start with static button controls and append any button groups
            // supplied by plugins
            commandGroups = COMMAND_GROUPS.concat(((this.props.editorState && this.props.editorState.plugins) || [])
                .map((p) => 'initButtonCommands' in p && p.initButtonCommands(theme))
                .filter(Boolean)).map(this._renderButtonsGroup).filter(Boolean);
        }
        return (React.createElement("div", { className: className },
            React.createElement("div", { className: "czi-editor-toolbar-flex" },
                React.createElement("div", { className: "czi-editor-toolbar-body" },
                    React.createElement("div", { className: toolbarBodyClass, ref: this._onBodyRef },
                        React.createElement("i", { className: "czi-editor-toolbar-wrapped-anchor" }),
                        commandGroups,
                        React.createElement("div", { className: "czi-editor-toolbar-background" },
                            React.createElement("div", { className: "czi-editor-toolbar-background-line" }),
                            React.createElement("div", { className: "czi-editor-toolbar-background-line" }),
                            React.createElement("div", { className: "czi-editor-toolbar-background-line" }),
                            React.createElement("div", { className: "czi-editor-toolbar-background-line" }),
                            React.createElement("div", { className: "czi-editor-toolbar-background-line" })),
                        React.createElement("i", { className: "czi-editor-toolbar-wrapped-anchor" })),
                    wrappedButton),
                React.createElement("div", { className: "czi-editor-toolbar-footer" }))));
    }
    // getUndoMenu(menuItems) {
    //   let retArr = [];
    //   return menuItems.reduce((acc, item) => {
    //     if (item.isPlugin) {
    //       const keysArray = Object.keys(item.menuCommand);
    //       // Access the first key
    //       const firstKey = keysArray && keysArray.length > 0 ? keysArray[0] : undefined;
    //       if (firstKey) {
    //         retArr.push(acc[firstKey] = item.menuCommand[firstKey]);
    //       }
    //     } else {
    //       retArr.push(acc[item.key] = item.menuCommand);
    //     }
    //     // }
    //     return retArr;
    //   }, {});
    // }
    // processMenuItems(menuItems) {
    //   return menuItems.reduce((acc, item) => {
    //     if (item.isPlugin) {
    //       const keysArray = Object.keys(item.menuCommand);
    //       const firstKey = keysArray && keysArray.length > 0 ? keysArray[0] : undefined;
    //       if (firstKey) {
    //         acc[firstKey] = item.menuCommand[firstKey];
    //       }
    //     } else {
    //       acc[item.key] = item.menuCommand;
    //     }
    //     return acc;
    //   }, {});
    // }
    //   processMenuItems(menuItems) {
    //     return menuItems.reduce((acc, item) => {
    //       const { group, key, menuCommand, menuPosition } = item; // Destructure properties
    //       if (!acc[group]) {
    //         acc[group] = []; // Create new group array if it doesn't exist
    //       }
    //       acc[group].push({ [key]: menuCommand, pos: menuPosition }); // Push key-value pair to group array
    //       return acc;
    //     }, {});
    //   }
    //   sortItemsByPosition(items: MenuItem[]): MenuItem[] {
    //   return items.sort((a, b) => {
    //     if (!a.menuPosition || !b.menuPosition) return 0; // Handle missing positions
    //     return a.menuPosition - b.menuPosition;
    //   });
    // }
    // like our structure need to check
    processMenuItems(menuItems) {
        return menuItems.reduce((acc, item) => {
            if (item.isPlugin) {
                const keysArray = Object.keys(item.menuCommand);
                const firstKey = keysArray && keysArray.length > 0 ? keysArray[0] : undefined;
                if (firstKey) {
                    const newItem = {
                        [firstKey]: item.menuCommand[firstKey], group: item.group // Use key as property name
                    };
                    acc.push(newItem);
                }
            }
            else {
                const newItem = {
                    [item.key]: item.menuCommand, group: item.group // Use key as property name
                };
                acc.push(newItem);
            }
            return acc;
        }, []);
    }
}
EditorToolbar.contextType = ThemeContext;
