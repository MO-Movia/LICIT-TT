import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider, ThemeContext } from '../index';
describe('ThemeProvider', () => {
    test('renders children with provided theme', () => {
        const TestComponent = () => {
            const theme = React.useContext(ThemeContext);
            return React.createElement("div", { "data-testid": "test-component" }, theme);
        };
        const theme = 'dark';
        render(React.createElement(ThemeProvider, { theme: theme },
            React.createElement(TestComponent, null)));
        const testComponent = screen.getByTestId('test-component');
        expect(testComponent.textContent).toBe(theme);
    });
});
