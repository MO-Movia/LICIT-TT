var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import '../styles/czi-custom-radio-button.css';
import { PointerSurface, preventEventDefault, } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
import cx from 'classnames';
import { uuid } from './uuid';
class CustomRadioButton extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._name = uuid();
    }
    render() {
        const _a = this.props, { title, className, checked, label, inline, name, onSelect, disabled } = _a, pointerProps = __rest(_a, ["title", "className", "checked", "label", "inline", "name", "onSelect", "disabled"]);
        const klass = cx(className, 'czi-custom-radio-button', {
            checked: checked,
            inline: inline,
        });
        return (React.createElement(PointerSurface, Object.assign({}, pointerProps, { className: klass, disabled: disabled, onClick: onSelect, title: title || label }),
            React.createElement("input", { checked: checked, className: "czi-custom-radio-button-input", disabled: disabled, name: name || this._name, onChange: preventEventDefault, tabIndex: disabled ? null : 0, type: "radio" }),
            React.createElement("span", { className: "czi-custom-radio-button-icon" }),
            React.createElement("span", { className: "czi-custom-radio-button-label" }, label)));
    }
}
export default CustomRadioButton;
