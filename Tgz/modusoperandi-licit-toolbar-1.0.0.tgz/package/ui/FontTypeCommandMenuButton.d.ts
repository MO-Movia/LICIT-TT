import CommandMenuButton from './CommandMenuButton';
import * as React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { editorType } from './FontSizeCommandMenuButton';
type PropsType = {
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView?: editorType;
};
declare class FontTypeCommandMenuButton extends React.PureComponent<PropsType> {
    props: PropsType;
    render(): React.ReactElement<CommandMenuButton>;
}
export default FontTypeCommandMenuButton;
