import * as React from 'react';
import CustomRadioButton from './CustomRadioButton';
import '../styles/czi-body-layout-editor.css';
import '../styles/czi-form.css';
export type DocLayoutEditorValue = {
    layout?: string;
    width?: number;
};
type DocLayoutEditorProps = {
    initialValue?: DocLayoutEditorValue;
    close: (val?: DocLayoutEditorValue) => void;
};
type DocLayoutEditorState = {
    selectedValue: string | number;
    layout?: string;
    width?: number;
};
declare class DocLayoutEditor extends React.PureComponent<DocLayoutEditorProps> {
    static contextType: React.Context<string>;
    _unmounted: boolean;
    static propsTypes: {
        close: (props: DocLayoutEditorProps, propName: string) => Error;
    };
    state: DocLayoutEditorState;
    constructor(props: DocLayoutEditorProps);
    render(): React.ReactElement<CustomRadioButton>;
    _onSelect: (selectedValue: string) => void;
    _cancel: () => void;
    _apply: () => void;
}
export default DocLayoutEditor;
