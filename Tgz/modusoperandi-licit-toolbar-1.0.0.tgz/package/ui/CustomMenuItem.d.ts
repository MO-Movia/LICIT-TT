import '../styles/czi-custom-menu-item.css';
import { CustomButton, PointerSurfaceProps } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
type CustomButtonProps = PointerSurfaceProps & {
    icon?: string | React.ReactElement | null;
    label?: string | React.ReactElement | null;
    theme?: string;
    value?: {
        alignment?: string;
    };
};
declare class CustomMenuItemSeparator extends React.PureComponent {
    render(): React.ReactElement;
}
declare class CustomMenuItem extends React.PureComponent {
    static Separator: typeof CustomMenuItemSeparator;
    static contextType: React.Context<string>;
    props: CustomButtonProps;
    render(): React.ReactElement<CustomButton>;
}
export default CustomMenuItem;
