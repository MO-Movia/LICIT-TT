import cx from 'classnames';
import * as React from 'react';
import { CustomButton, ThemeContext } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
class CommandButton extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._onUIEnter = (command, event) => {
            if (command.shouldRespondToUIEvent(event)) {
                this._execute(command, event);
            }
        };
        this._execute = (_value, event) => {
            const { command, editorState, dispatch, editorView } = this.props;
            command.execute(editorState, dispatch, editorView, event);
        };
    }
    render() {
        const { label, className, command, editorState, icon, title, editorView, sub, } = this.props;
        let disabled = this.props.disabled;
        const theme = this.context;
        if (!!disabled === false) {
            disabled = !editorView || !command.isEnabled(editorState, editorView);
        }
        UICommand.theme = theme.toString();
        const buttonClassName = sub
            ? cx(className, {
                'czi-custom-submenu-button': true,
            })
            : className;
        return (React.createElement(CustomButton, { active: command.isActive(editorState), className: buttonClassName, disabled: disabled, icon: icon, label: label, onClick: this._onUIEnter, onMouseEnter: this._onUIEnter, theme: theme ? theme.toString() : 'dark', title: title, value: command }));
    }
}
CommandButton.contextType = ThemeContext;
export default CommandButton;
