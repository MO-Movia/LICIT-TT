var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import React from 'react';
import canUseCSSFont from './CanUseCSSFont';
import { ThemeContext } from '@modusoperandi/licit-ui-commands';
// import { ReactComponent as UndoIcon } from '../../images/dark/undo.svg';
import '../styles/czi-icon.css';
import '../styles/icon-font.css';
const VALID_CHARS = /[a-z_]+/;
const cached = {};
const CSS_FONT = 'Material Icons';
(function () {
    return __awaiter(this, void 0, void 0, function* () {
        // Inject CSS Fonts reuqired for toolbar icons.
        yield canUseCSSFont(CSS_FONT);
    });
})();
const importImage = (filename) => import(`@assets/images/${filename}`);
class SuperscriptIcon extends React.PureComponent {
    render() {
        return (React.createElement("span", { className: "superscript-wrap" },
            React.createElement("span", { className: "superscript-base" }, "x"),
            React.createElement("span", { className: "superscript-top" }, "y")));
    }
}
/*function useDynamicSVGImport(name, options = {}) {
  const ImportedIconRef = useRef();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();

  const { onCompleted, onError } = options;
  useEffect(() => {
    setLoading(true);
    const importIcon = async () => {
      try {
        ImportedIconRef.current = (
          await import(`./${name}.svg`)
        ).ReactComponent;
        if (onCompleted) {
          onCompleted(name, ImportedIconRef.current);
        }
      } catch (err) {
        if (onError) {
          onError(err);
        }
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    importIcon();
  }, [name, onCompleted, onError]);

  return { error, loading, SvgIcon: ImportedIconRef.current };
}

function IconEx({name, onCompleted, onError, ...rest}) {
  const {error, loading, SvgIcon} = useDynamicSVGImport(name, {onCompleted, onError});
  if(error) {
    return error.message;
  }

  if(loading) {
    return "Loading...";
  }

  if(SvgIcon) {
    return <SvgIcon {...rest}/>
  }
}
*/
class SubscriptIcon extends React.PureComponent {
    render() {
        return (React.createElement("span", { className: "subscript-wrap" },
            React.createElement("span", { className: "subscript-base" }, "x"),
            React.createElement("span", { className: "subscript-bottom" }, "y")));
    }
}
class Icon extends React.PureComponent {
    constructor() {
        super(...arguments);
        this.state = {
            image1: null,
        };
    }
    // Get the static Icon.
    static get(type, title, theme) {
        const key = `${type || ''}-${title || ''}`;
        const icon = cached[key] || React.createElement(Icon, { theme: theme, title: title, type: type });
        cached[key] = icon;
        return icon;
    }
    render() {
        const { type, title } = this.props;
        const { image1 } = this.state;
        const className = '';
        const children = '';
        // const [image1, setImage] = useState(null);
        /*if (type == 'superscript') {
          className = cx('czi-icon', { [type]: true });
          children = <SuperscriptIcon />;
        } else if (type == 'subscript') {
          className = cx('czi-icon', { [type]: true });
          children = <SubscriptIcon />;
        } else if (!type || !VALID_CHARS.test(type)) {
          className = cx('czi-icon-unknown');
          children = title || type;
        } else {
          className = cx('czi-icon', { [type]: true });
          children = type;
        }*/
        let image = null;
        if (type.startsWith('http')) {
            image = type;
        }
        else {
            let fileName = 'Icon_Source';
            switch (type) {
                case 'format_align_right':
                case 'format_bold':
                case 'format_italic':
                case 'format_list_bulleted':
                case 'format_underline':
                case 'functions':
                case 'grid_on':
                case 'hr':
                case 'link':
                case 'redo':
                case 'undo':
                case 'arrow_drop_down':
                case 'format_align_left':
                case 'format_align_center':
                case 'format_align_justify':
                case 'superscript':
                case 'subscript':
                case 'format_indent_increase':
                case 'format_indent_decrease':
                case 'format_strikethrough':
                case 'format_color_text':
                case 'format_line_spacing':
                case 'format_clear':
                case 'border_color':
                case 'settings_overscan':
                case 'icon_edit':
                    fileName = type;
                    break;
                default:
                    break;
            }
            // const theme = this.context;
            const t = this.props.theme ? this.props.theme : 'dark';
            console.log('fromicon ' + t);
            // image = this.loadImage('dark',fileName+'.svg')
            // image = this.loadImage(t,fileName+'.svg');
            // const fetchImage = async () => {
            //   image = await this.loadImage(t,fileName+'.svg');
            // };
            // fetchImage();
            // const dynamicPath = './';
            // image = require('../../images/' + t + '/' + fileName + '.svg');
            // import image from `../../images/${t}/${fileName}.svg`;
        }
        //const { srcImg } = await import(`${path}`);`${path}`;//[`../../images/${'format_align_justify'}.svg`]//'../../images/format_align_justify.svg'
        return (React.createElement("img", { alt: title, src: image1, style: { width: '100%', height: '100%' } }));
        //return <span className={className}>{children}</span>;
    }
    componentDidMount() {
        return __awaiter(this, void 0, void 0, function* () {
            const { type, title } = this.props;
            // const { image1 } = this.state;
            const className = '';
            const children = '';
            // const [image1, setImage] = useState(null);
            /*if (type == 'superscript') {
              className = cx('czi-icon', { [type]: true });
              children = <SuperscriptIcon />;
            } else if (type == 'subscript') {
              className = cx('czi-icon', { [type]: true });
              children = <SubscriptIcon />;
            } else if (!type || !VALID_CHARS.test(type)) {
              className = cx('czi-icon-unknown');
              children = title || type;
            } else {
              className = cx('czi-icon', { [type]: true });
              children = type;
            }*/
            // let image = null;
            if (type.startsWith('http') || type.startsWith('data:image/svg+xml')) {
                // image1 = type;
                this.setState({ image1: type });
            }
            else {
                let fileName = 'Icon_Source';
                switch (type) {
                    case 'format_align_right':
                    case 'format_bold':
                    case 'format_italic':
                    case 'format_list_bulleted':
                    case 'format_underline':
                    case 'functions':
                    case 'grid_on':
                    case 'hr':
                    case 'link':
                    case 'redo':
                    case 'undo':
                    case 'arrow_drop_down':
                    case 'format_align_left':
                    case 'format_align_center':
                    case 'format_align_justify':
                    case 'superscript':
                    case 'subscript':
                    case 'format_indent_increase':
                    case 'format_indent_decrease':
                    case 'format_line_spacing':
                    case 'format_strikethrough':
                    case 'format_color_text':
                    case 'format_clear':
                    case 'border_color':
                    case 'settings_overscan':
                    case 'icon_edit':
                    case 'more_horiz':
                        fileName = type;
                        break;
                    default:
                        break;
                }
                // const theme = this.context;
                const t = this.props.theme ? this.props.theme : 'dark';
                console.log('fromicon ' + t);
                try {
                    // Dynamically load the image
                    const imageModule = yield import(`@assets/images/${t}/${fileName}.svg`);
                    const image1 = imageModule.default;
                    this.setState({ image1 });
                }
                catch (error) {
                    console.error(`Error loading image: ${error}`);
                }
            }
            // async  loadImage(t: string, fileName: string) {
            //   try {
            //     const imageModule = await import(`./images/${t}/${fileName}`);
            //     const image = imageModule.default;
            //     return image;
            //   } catch (error) {
            //     console.error(`Error loading image: ${error}`);
            //     return null;
            //   }
            // }
            // async loadImage(t: string, fileName: string) {
            //   const imagePath = `./images/${t}/${fileName}`;
            //   // const image = require(imagePath) as string;
            //   const image = await importImage(`${t}/${fileName}`);
            //   // return imagePath;
            //   return image;
            // }
            // const loadIcons = async () => {
            //   // const loaded = {};
            //   // for (const key of Object.keys(icons)) {
            //     const image = await importImage(icons[key]);
            //     // loaded[key] = image.default; // Assuming default export from image file
            //   }
            // };
        });
    }
}
Icon.contextType = ThemeContext;
export default Icon;
