import cx from 'classnames';
import * as React from 'react';
import { preventEventDefault } from './preventEventDefault';
export class PointerSurface extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._clicked = false;
        this._mul = false;
        this._pressedTarget = null;
        this._unmounted = false;
        this.state = { pressed: false };
        this._onMouseEnter = (e) => {
            this._pressedTarget = null;
            e.preventDefault();
            const { onMouseEnter, value } = this.props;
            onMouseEnter === null || onMouseEnter === void 0 ? void 0 : onMouseEnter(value, e);
        };
        this._onMouseLeave = (e) => {
            this._pressedTarget = null;
            const mouseUpEvent = e;
            this._onMouseUpCapture(mouseUpEvent);
        };
        this._onMouseDown = (e) => {
            e.preventDefault();
            this._pressedTarget = null;
            this._clicked = false;
            if (e['which'] === 3 || e.button == 2) {
                // right click.
                return;
            }
            this.setState({ pressed: true });
            this._pressedTarget = e.currentTarget;
            this._clicked = false;
            if (!this._mul) {
                document.addEventListener('mouseup', this._onMouseUpCapture, true);
                this._mul = true;
            }
        };
        this._onMouseUp = (e) => {
            e.preventDefault();
            if (this._clicked || e.type === 'keypress') {
                const { onClick, value, disabled } = this.props;
                !disabled && onClick && onClick(value, e);
            }
            this._pressedTarget = null;
            this._clicked = false;
        };
        this._onMouseUpCapture = (e) => {
            if (this._mul) {
                this._mul = false;
                document.removeEventListener('mouseup', this._onMouseUpCapture, true);
            }
            const target = e.target;
            this._clicked =
                this._pressedTarget instanceof HTMLElement &&
                    target instanceof HTMLElement &&
                    (target === this._pressedTarget ||
                        target.contains(this._pressedTarget) ||
                        this._pressedTarget.contains(target));
            this.setState({ pressed: false });
        };
    }
    render() {
        const { className, disabled, active, id, style, title, children } = this.props;
        const { pressed } = this.state;
        const buttonClassName = cx(className, {
            //  classs added fro active style. temp commeneted
            // active: active,
            disabled: disabled,
            pressed: pressed,
        });
        return (React.createElement("span", { "aria-disabled": disabled, "aria-pressed": pressed, className: buttonClassName, id: id, onKeyDown: disabled ? preventEventDefault : this._onMouseUp, onMouseDown: disabled ? preventEventDefault : this._onMouseDown, onMouseEnter: disabled ? preventEventDefault : this._onMouseEnter, onMouseLeave: disabled ? null : this._onMouseLeave, onMouseUp: disabled ? preventEventDefault : this._onMouseUp, role: "button", style: style, tabIndex: disabled ? null : 0, title: title }, children));
    }
    componentWillUnmount() {
        this._unmounted = true;
        if (this._mul) {
            this._mul = false;
            document.removeEventListener('mouseup', this._onMouseUpCapture, true);
        }
    }
}
