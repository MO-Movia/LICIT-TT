import React, { Component, ReactNode } from 'react';
declare const ThemeContext: React.Context<string>;
declare class ThemeProvider extends Component<{
    children: ReactNode;
    theme: string;
}> {
    render(): React.JSX.Element;
}
export { ThemeProvider, ThemeContext };
