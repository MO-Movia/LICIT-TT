import * as React from 'react';
import { LAYOUT } from '../Constants';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { CustomButton, preventEventDefault, ThemeContext } from '@modusoperandi/licit-ui-commands';
import CustomRadioButton from './CustomRadioButton';
import '../styles/czi-body-layout-editor.css';
import '../styles/czi-form.css';
class DocLayoutEditor extends React.PureComponent {
    constructor(props) {
        super(props);
        this._unmounted = false;
        this._onSelect = (selectedValue) => {
            this.setState({ selectedValue });
        };
        this._cancel = () => {
            this.props.close();
        };
        this._apply = () => {
            const { selectedValue } = this.state;
            if (typeof selectedValue === 'string') {
                this.props.close({ width: null, layout: selectedValue });
            }
            else {
                this.props.close({ width: selectedValue, layout: null });
            }
        };
        const theme = this.context;
        const { width, layout } = this.props.initialValue || {};
        this.state = {
            width,
            layout,
            selectedValue: width || layout || LAYOUT.US_LETTER_PORTRAIT, // or LAYOUT.A4_PORTRAIT to define default layout
        };
    }
    render() {
        const { width, selectedValue } = this.state;
        console.log('UICommand : ', UICommand.theme);
        const parentClassName = 'czi-body-layout-editor ' + UICommand.theme;
        const formClassName = 'czi-form ' + UICommand.theme;
        const contextType = ThemeContext;
        const theme = this.context;
        const customOption = width ? (React.createElement(CustomRadioButton, { checked: selectedValue === String(width), key: "c", label: `Custom width: ${width}pt`, onSelect: this._onSelect, value: width })) : null;
        return (React.createElement("div", { className: parentClassName },
            React.createElement("form", { className: formClassName, onSubmit: preventEventDefault },
                React.createElement("fieldset", null,
                    React.createElement("legend", null, "Page Layout"),
                    React.createElement(CustomRadioButton, { checked: selectedValue === LAYOUT.US_LETTER_PORTRAIT, label: "US Letter - Portrait", onSelect: this._onSelect, value: LAYOUT.US_LETTER_PORTRAIT }),
                    React.createElement(CustomRadioButton, { checked: selectedValue === LAYOUT.US_LETTER_LANDSCAPE, label: "US Letter - Landscape", onSelect: this._onSelect, value: LAYOUT.US_LETTER_LANDSCAPE }),
                    React.createElement(CustomRadioButton, { checked: selectedValue === LAYOUT.A4_PORTRAIT, label: "A4 - Portrait", onSelect: this._onSelect, value: LAYOUT.A4_PORTRAIT }),
                    React.createElement(CustomRadioButton, { checked: selectedValue === LAYOUT.A4_LANDSCAPE, label: "A4 - Landscape", onSelect: this._onSelect, value: LAYOUT.A4_LANDSCAPE }),
                    React.createElement(CustomRadioButton, { checked: selectedValue === LAYOUT.DESKTOP_SCREEN_4_3, label: "4:3 Desktop Screen", onSelect: this._onSelect, value: LAYOUT.DESKTOP_SCREEN_4_3 }),
                    React.createElement(CustomRadioButton, { checked: selectedValue === LAYOUT.DESKTOP_SCREEN_16_9, label: "16:9 Desktop Screen", onSelect: this._onSelect, value: LAYOUT.DESKTOP_SCREEN_16_9 }),
                    customOption),
                React.createElement("hr", null),
                React.createElement("div", { className: "czi-form-buttons" },
                    React.createElement(CustomButton, { label: "Cancel", onClick: this._cancel }),
                    React.createElement(CustomButton, { active: true, label: "Apply", onClick: this._apply })))));
    }
}
DocLayoutEditor.contextType = ThemeContext;
// [FS] IRAD-1005 2020-07-07
// Upgrade outdated packages.
// To take care of the property type declaration.
DocLayoutEditor.propsTypes = {
    close: function (props, propName) {
        const fn = props[propName];
        if (!fn.prototype ||
            (typeof fn.prototype.constructor !== 'function' &&
                fn.prototype.constructor.length !== 1)) {
            return new Error(propName +
                'must be a function with 1 arg of type DocLayoutEditorValue');
        }
        return null;
    },
};
export default DocLayoutEditor;
