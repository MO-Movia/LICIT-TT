import { preventEventDefault } from './preventEventDefault';
describe('preventEventDefault', () => {
    it('calls preventDefault on the event', () => {
        const preventDefaultMock = jest.fn();
        const eventMock = {
            preventDefault: preventDefaultMock,
        };
        preventEventDefault(eventMock);
        expect(preventDefaultMock).toHaveBeenCalledTimes(1);
    });
});
