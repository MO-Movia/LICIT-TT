import * as React from 'react';
import { EditorView } from 'prosemirror-view';
export type PointerSurfaceProps = {
    active?: boolean;
    children?: any;
    className?: string;
    disabled?: boolean;
    id?: string;
    onClick?: (val: any, e: React.SyntheticEvent) => void;
    onMouseEnter?: (val: any, e: React.SyntheticEvent) => void;
    style?: Record<string, unknown>;
    target?: string;
    title?: string;
    value?: string | number | Record<string, unknown> | EditorView | any;
    hasChild?: boolean;
};
export declare class PointerSurface extends React.PureComponent {
    props: PointerSurfaceProps;
    _clicked: boolean;
    _mul: boolean;
    _pressedTarget: any;
    _unmounted: boolean;
    state: {
        pressed: boolean;
    };
    render(): React.ReactElement;
    componentWillUnmount(): void;
    _onMouseEnter: (e: React.SyntheticEvent) => void;
    _onMouseLeave: (e: React.MouseEvent) => void;
    _onMouseDown: (e: React.MouseEvent) => void;
    _onMouseUp: (e: React.SyntheticEvent) => void;
    _onMouseUpCapture: (e: MouseEvent) => void;
}
