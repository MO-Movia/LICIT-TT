import * as React from 'react';
import { uuid } from './uuid';
import '../styles/listType.css';
// [FS] IRAD-1039 2020-09-24
// UI to show the list buttons
class ListTypeMenu extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._activeCommand = null;
        this._menu = null;
        this._id = uuid();
        this.state = {
            expanded: false,
        };
        this._onUIEnter = (command, event) => {
            this._activeCommand && this._activeCommand.cancel();
            this._activeCommand = command;
            this._execute(command, event);
        };
        this._execute = (command, e) => {
            const { dispatch, editorState, editorView, onCommand } = this.props;
            if (command.execute(editorState, dispatch, editorView, e)) {
                onCommand && onCommand();
            }
        };
    }
    render() {
        const { commandGroups } = this.props;
        const children = [];
        const theme = this.props.theme;
        const className = 'buttonsize ' + theme;
        const cont_classname = 'ol-container ' + theme;
        commandGroups.forEach((group, _ii) => {
            Object.keys(group).forEach((label) => {
                const command = group[label];
                children.push(React.createElement("button", { className: className, id: label, key: label, onClick: (e) => this._onUIEnter(command, e), value: command }, command.label));
            });
        });
        return React.createElement("div", { className: cont_classname }, children);
    }
}
export default ListTypeMenu;
