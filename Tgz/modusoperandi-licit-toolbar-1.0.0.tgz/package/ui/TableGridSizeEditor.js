import cx from 'classnames';
import * as React from 'react';
import ReactDOM from 'react-dom';
import htmlElementToRect from '../HtmlElementToRect';
import { fromHTMlElement, fromXY, isIntersected, clamp, } from '@modusoperandi/licit-ui-commands';
import '../styles/czi-table-grid-size-editor.css';
const GUTTER_SIZE = 5;
const CELL_SIZE = 16;
// [FS] IRAD-1012 2020-07-14
// Fix: Limited Table Grid size from 20 to 7
const MAX_SIZE = 7;
class GridCell extends React.PureComponent {
    render() {
        const { x, y, selected } = this.props;
        const style = {
            left: x + 'px',
            top: y + 'px',
            width: CELL_SIZE + 'px',
            height: CELL_SIZE + 'px',
        };
        const className = cx('czi-table-grid-size-editor-cell', {
            selected,
        });
        return React.createElement("div", { className: className, style: style });
    }
}
class TableGridSizeEditor extends React.PureComponent {
    constructor() {
        super(...arguments);
        this._ex = 0;
        this._ey = 0;
        this._mx = 0;
        this._my = 0;
        this._rafID = 0;
        this._ref = null;
        this._entered = false;
        this.state = {
            rows: 1,
            cols: 1,
        };
        this._onRef = (ref) => {
            this._ref = ref;
        };
        this._onMouseEnter = (e) => {
            const node = e.currentTarget;
            if (node instanceof HTMLElement) {
                const rect = fromHTMlElement(node);
                const mx = Math.round(e.clientX);
                const my = Math.round(e.clientY);
                this._ex = rect.x;
                this._ey = rect.y;
                this._mx = mx;
                this._my = my;
                if (!this._entered) {
                    this._entered = true;
                    document.addEventListener('mousemove', this._onMouseMove, true);
                }
            }
        };
        this._onMouseMove = (e) => {
            const el = this._ref && ReactDOM.findDOMNode(this._ref);
            const elRect = el ? htmlElementToRect(el) : null;
            const mouseRect = fromXY(e.screenX, e.screenY, 10);
            if (elRect && mouseRect && isIntersected(elRect, mouseRect, 50)) {
                // This prevents `PopUpManager` from collapsing the editor.
                e.preventDefault();
                e.stopImmediatePropagation();
            }
            const mx = Math.round(e.clientX);
            const my = Math.round(e.clientY);
            if (mx !== this._mx || my !== this._my) {
                this._mx = mx;
                this._my = my;
                this._rafID && cancelAnimationFrame(this._rafID);
                this._rafID = requestAnimationFrame(this._updateGridSize);
            }
        };
        this._updateGridSize = () => {
            this._rafID = 0;
            const mx = this._mx;
            const my = this._my;
            const x = mx - this._ex;
            const y = my - this._ey;
            const rr = clamp(1, Math.ceil(y / (CELL_SIZE + GUTTER_SIZE)), MAX_SIZE);
            const cc = clamp(1, Math.ceil(x / (CELL_SIZE + GUTTER_SIZE)), MAX_SIZE);
            const { rows, cols } = this.state;
            if (rows !== rr || cols !== cc) {
                this.setState({ rows: rr, cols: cc });
            }
        };
        this._onMouseDown = (e) => {
            e.preventDefault();
            this.props.close(this.state);
        };
    }
    componentWillUnmount() {
        if (this._entered) {
            document.removeEventListener('mousemove', this._onMouseMove, true);
        }
        this._rafID && cancelAnimationFrame(this._rafID);
    }
    render() {
        const { rows, cols } = this.state;
        let rr = Math.max(5, rows);
        let cc = Math.max(5, cols);
        if (rr === rows) {
            rr = Math.min(MAX_SIZE, rr + 1);
        }
        if (cc === cols) {
            cc = Math.min(MAX_SIZE, cc + 1);
        }
        const cells = [];
        let ii = 0;
        let y = 0;
        let w = 0;
        let h = 0;
        while (ii < rr) {
            y += GUTTER_SIZE;
            let jj = 0;
            let x = 0;
            while (jj < cc) {
                x += GUTTER_SIZE;
                const selected = ii < rows && jj < cols;
                cells.push(React.createElement(GridCell, { key: `${String(ii)}-${String(jj)}`, selected: selected, x: x, y: y }));
                x += CELL_SIZE;
                w = x + GUTTER_SIZE;
                jj++;
            }
            y += CELL_SIZE;
            h = y + GUTTER_SIZE;
            ii++;
        }
        const bodyStyle = { width: w + 'px', height: h + 'px' };
        return (React.createElement("div", { className: "czi-table-grid-size-editor", ref: this._onRef },
            React.createElement("div", { className: "czi-table-grid-size-editor-body", onMouseDown: this._onMouseDown, onMouseEnter: this._onMouseEnter, style: bodyStyle }, cells),
            React.createElement("div", { className: "czi-table-grid-size-editor-footer" },
                rows,
                " X ",
                cols)));
    }
}
export default TableGridSizeEditor;
