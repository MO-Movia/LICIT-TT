import '../styles/czi-custom-menu-item.css';
import { CustomButton, ThemeContext } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
class CustomMenuItemSeparator extends React.PureComponent {
    render() {
        return React.createElement("div", { className: "czi-custom-menu-item-separator" });
    }
}
class CustomMenuItem extends React.PureComponent {
    render() {
        var _a;
        // [FS] IRAD-1044 2020-09-22
        // Added a new class to adjust the width of the custom style menu dropdown.
        // const theme = this.context;
        // const className = 'czi-custom-menu-item';
        let className = 'czi-custom-menu-item ' + this.props.theme;
        if ((_a = this.props.value) === null || _a === void 0 ? void 0 : _a.alignment) {
            className = 'czi-custom-menu-item-button ' + this.props.theme;
        }
        return React.createElement(CustomButton, Object.assign({}, this.props, { className: className, theme: this.props.theme }));
    }
}
CustomMenuItem.Separator = CustomMenuItemSeparator;
CustomMenuItem.contextType = ThemeContext;
export default CustomMenuItem;
