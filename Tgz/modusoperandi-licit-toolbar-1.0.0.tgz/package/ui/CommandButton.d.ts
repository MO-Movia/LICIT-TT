import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { CustomButton } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorRuntime } from '../Types';
type CommandButtonProps = {
    className?: string;
    command: UICommand;
    disabled?: boolean;
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView: EditorView & EditorRuntime;
    icon?: string | React.ReactElement | null;
    label?: string | React.ReactElement | null;
    title?: string;
    sub?: boolean;
};
declare class CommandButton extends React.PureComponent<CommandButtonProps> {
    static contextType: React.Context<string>;
    props: CommandButtonProps;
    render(): React.ReactElement<CustomButton>;
    _onUIEnter: (command: UICommand, event: React.SyntheticEvent<HTMLButtonElement>) => void;
    _execute: (_value: UICommand, event: React.SyntheticEvent<HTMLButtonElement>) => void;
}
export default CommandButton;
