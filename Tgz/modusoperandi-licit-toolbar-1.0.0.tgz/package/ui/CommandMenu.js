import * as React from 'react';
import CustomMenu from './CustomMenu';
import CustomMenuItem from './CustomMenuItem';
import CommandButton from './CommandButton';
import { parseLabel, isExpandButton } from '../EditorTollbarConfig';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import CommandMenuButton from './CommandMenuButton';
class CommandMenu extends React.PureComponent {
    constructor() {
        super(...arguments);
        // static contextType = ThemeContext;
        this._activeCommand = null;
        this._renderCustomMenuItem = (label, command, editorState, icon, theme) => {
            return (React.createElement(CustomMenuItem, { active: command.isActive(editorState), disabled: !command.isEnabled(editorState), icon: icon, key: label, label: icon ? null : (command.renderLabel(editorState) || label), onClick: this._onUIEnter, onMouseEnter: this._onUIEnter, theme: theme, value: command }));
        };
        this._renderCommandButton = (label, command, disabled, dispatch, editorState, editorView) => {
            const { icon, title } = parseLabel(label, 'dark');
            const isDropdown = command instanceof UICommand;
            return (React.createElement(CommandButton, { command: command, disabled: disabled, dispatch: dispatch, editorState: editorState, editorView: editorView, icon: icon, key: label, label: icon ? null : title, sub: isDropdown ? false : true, title: title }));
        };
        this._renderMenuButton = (label, commandGroups, theme) => {
            const { editorState, editorView, dispatch } = this.props;
            const { icon, title } = parseLabel(label, theme);
            let isDropdown = false;
            if (commandGroups && commandGroups.length > 0) {
                isDropdown = commandGroups[0] instanceof UICommand;
            }
            return (React.createElement(CommandMenuButton, { commandGroups: commandGroups, disabled: false, dispatch: dispatch, editorState: editorState, editorView: editorView, icon: icon, key: label, label: icon ? null : title, sub: isDropdown ? false : true, title: title }));
        };
        this._onUIEnter = (command, event) => {
            if (command.shouldRespondToUIEvent(event)) {
                this._activeCommand && this._activeCommand.cancel();
                this._activeCommand = command;
                this._execute(command, event);
            }
        };
        this._execute = (command, e) => {
            const { dispatch, editorState, editorView, onCommand } = this.props;
            if (command.execute(editorState, dispatch, editorView, e)) {
                onCommand && onCommand();
            }
        };
    }
    render() {
        const { commandGroups, editorState, editorView, title, theme } = this.props;
        const children = [];
        const jj = commandGroups.length - 1;
        // const theme = this.context;
        commandGroups.forEach((group, ii) => {
            Object.keys(group).forEach((label) => {
                const command = group[label];
                if (command instanceof UICommand) {
                    let disabled = true;
                    const { icon } = parseLabel(label, theme.toString());
                    try {
                        // [FS] IRAD-1053 2020-10-22
                        // Disable the Clear style menu when no styles applied to a paragraph
                        disabled = !editorView || !command.isEnabled(editorState, editorView);
                    }
                    catch (ex) {
                        disabled = false;
                    }
                    // if (command) {
                    //   children.push(
                    //     this._renderCommandButton(
                    //       label,
                    //       command,
                    //       disabled,
                    //       dispatch,
                    //       editorState,
                    //       editorView
                    //     )
                    //   );
                    // } else {
                    children.push(this._renderCustomMenuItem(label, command, editorState, icon, theme));
                    // }
                }
                else if (Array.isArray(command)) {
                    children.push(this._renderMenuButton(label, command, theme));
                }
            });
            if (ii !== jj) {
                children.push(React.createElement(CustomMenuItem.Separator, { key: `${String(ii)}-hr` }));
            }
        });
        return React.createElement(CustomMenu, { isHorizontal: isExpandButton(title), theme: theme }, children);
    }
}
export default CommandMenu;
