import CommandMenuButton from './CommandMenuButton';
import { FontTypeCommand } from '@modusoperandi/licit-ui-commands';
import * as React from 'react';
import { FONT_TYPE_NAMES } from '../FontTypeMarkSpec';
import findActiveFontType, { FONT_TYPE_NAME_DEFAULT, } from '../FindActiveFontType';
const FONT_TYPE_COMMANDS = {
    [FONT_TYPE_NAME_DEFAULT]: new FontTypeCommand(''),
};
FONT_TYPE_NAMES.forEach((name) => {
    FONT_TYPE_COMMANDS[name] = new FontTypeCommand(name);
});
const COMMAND_GROUPS = [FONT_TYPE_COMMANDS];
class FontTypeCommandMenuButton extends React.PureComponent {
    render() {
        const { dispatch, editorState, editorView } = this.props;
        const fontType = findActiveFontType(editorState);
        return (
        // <CommandMenuButton  className="width-100"
        React.createElement(CommandMenuButton, { className: "width-100 czi-dropdown-border", 
            // [FS] IRAD-1008 2020-07-16
            // Disable font type menu on editor disable state
            commandGroups: COMMAND_GROUPS, disabled: editorView && editorView.disabled ? true : false, dispatch: dispatch, editorState: editorState, editorView: editorView, label: fontType }));
    }
}
export default FontTypeCommandMenuButton;
