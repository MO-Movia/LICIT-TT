import { TextSelection } from 'prosemirror-state';
import * as React from 'react';
import { MARK_FONT_TYPE } from './MarkNames';
import { applyMark } from './applyMark';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
function setFontType(tr, schema, name, isCustomStyleApplied) {
    const markType = schema.marks[MARK_FONT_TYPE];
    if (!markType) {
        return tr;
    }
    const attrs = name ? { name } : null;
    tr = applyMark(tr, schema, markType, attrs, isCustomStyleApplied);
    return tr;
}
export class FontTypeCommand extends UICommand {
    constructor(name) {
        super();
        this._label = null;
        this._name = '';
        this._popUp = null;
        this.renderLabel = (_state) => {
            return this._label;
        };
        this.isEnabled = (state) => {
            const { schema, selection, tr } = state;
            const markType = schema.marks[MARK_FONT_TYPE];
            if (!markType) {
                return false;
            }
            const { from, to } = selection;
            if (to === from + 1) {
                const node = tr.doc.nodeAt(from);
                if (node.isAtom && !node.isText && node.isLeaf) {
                    // An atomic node (e.g. Image) is selected.
                    return false;
                }
            }
            return true;
        };
        this.execute = (state, dispatch, _view) => {
            const { schema } = state;
            // commnted selection because selection removes the storedMarks;
            // {selection}
            const tr = setFontType(state.tr, schema, this._name);
            if (tr.docChanged || tr.storedMarksSet) {
                // If selection is empty, the color is added to `storedMarks`, which
                // works like `toggleMark`
                // (see https://prosemirror.net/docs/ref/#commands.toggleMark).
                dispatch === null || dispatch === void 0 ? void 0 : dispatch(tr);
                return true;
            }
            return false;
        };
        // [FS] IRAD-1087 2020-10-01
        // Method to execute custom styling implementation of font type
        this.executeCustom = (state, tr, from, to) => {
            const { schema } = state;
            tr = setFontType(tr.setSelection(TextSelection.create(tr.doc, from, to)), schema, this._name, true);
            return tr;
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this._name = name;
        this._label = name ? React.createElement("span", { style: { fontFamily: name } }, name) : null;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    cancel() {
        return null;
    }
    isActive() {
        return true;
    }
}
