import { NodeSelection } from 'prosemirror-state';
// Whether the selection is a node for the node type provided.
export function isNodeSelectionForNodeType(selection, nodeType) {
    if (selection instanceof NodeSelection) {
        return selection.node.type === nodeType;
    }
    return false;
}
