import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { BLOCKQUOTE, HEADING, LIST_ITEM, PARAGRAPH } from './NodeNames';
import { DOUBLE_LINE_SPACING, SINGLE_LINE_SPACING, LINE_SPACING_115, LINE_SPACING_150, } from './ui/toCSSLineSpacing';
export function setTextLineSpacing(tr, schema, lineSpacing) {
    const { selection, doc } = tr;
    if (!selection || !doc) {
        return tr;
    }
    const { from, to } = selection;
    const paragraph = schema.nodes[PARAGRAPH];
    const heading = schema.nodes[HEADING];
    const listItem = schema.nodes[LIST_ITEM];
    const blockquote = schema.nodes[BLOCKQUOTE];
    if (!paragraph && !heading && !listItem && !blockquote) {
        return tr;
    }
    const tasks = [];
    const lineSpacingValue = lineSpacing || null;
    doc.nodesBetween(from, to, (node, pos, _parentNode) => {
        const nodeType = node.type;
        if (nodeType === paragraph ||
            nodeType === heading ||
            nodeType === listItem ||
            nodeType === blockquote) {
            const lineSpacing = node.attrs.lineSpacing || null;
            if (lineSpacing !== lineSpacingValue) {
                tasks.push({
                    node,
                    pos,
                    nodeType,
                });
            }
            return nodeType === listItem;
        }
        return true;
    });
    if (!tasks.length) {
        return tr;
    }
    tasks.forEach((job) => {
        const { node, pos, nodeType } = job;
        let { attrs } = node;
        if (lineSpacingValue) {
            attrs = Object.assign(Object.assign({}, attrs), { lineSpacing: lineSpacingValue });
        }
        else {
            attrs = Object.assign(Object.assign({}, attrs), { lineSpacing: null });
        }
        tr = tr.setNodeMarkup(pos, nodeType, attrs, node.marks);
    });
    return tr;
}
function createGroup() {
    const group = {
        Single: new TextLineSpacingCommand(SINGLE_LINE_SPACING),
        '1.15': new TextLineSpacingCommand(LINE_SPACING_115),
        '1.5': new TextLineSpacingCommand(LINE_SPACING_150),
        Double: new TextLineSpacingCommand(DOUBLE_LINE_SPACING),
    };
    return [group];
}
export class TextLineSpacingCommand extends UICommand {
    constructor(lineSpacing) {
        super();
        this.isActive = (state) => {
            const { selection, doc, schema } = state;
            const { from, to } = selection;
            const paragraph = schema.nodes[PARAGRAPH];
            const heading = schema.nodes[HEADING];
            let keepLooking = true;
            let active = false;
            doc.nodesBetween(from, to, (node, _pos) => {
                const nodeType = node.type;
                if (keepLooking &&
                    (nodeType === paragraph || nodeType === heading) &&
                    node.attrs.lineSpacing === this._lineSpacing) {
                    keepLooking = false;
                    active = true;
                }
                return keepLooking;
            });
            return active;
        };
        this.isEnabled = (state) => {
            return this.isActive(state) || this.execute(state);
        };
        this.waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        this.executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        this.execute = (state, dispatch, _view) => {
            const { schema, selection } = state;
            const tr = setTextLineSpacing(state.tr.setSelection(selection), schema, this._lineSpacing);
            if (tr.docChanged) {
                dispatch === null || dispatch === void 0 ? void 0 : dispatch(tr);
                return true;
            }
            else {
                return false;
            }
        };
        this.executeCustom = (_state, tr) => {
            return tr;
        };
        this._lineSpacing = lineSpacing;
    }
    cancel() {
        return null;
    }
    renderLabel() {
        return null;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
TextLineSpacingCommand.createGroup = createGroup;
