import { Schema } from 'prosemirror-model';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export declare function setTextAlign(tr: Transform, schema: Schema, alignment?: string): Transform;
export declare class TextAlignCommand extends UICommand {
    _alignment: string;
    constructor(alignment: string);
    isActive: (state: EditorState) => boolean;
    isEnabled: (state: EditorState) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    executeCustom: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    renderLabel(): any;
}
