export declare const TABLE_CELL = "tableCell";
