export const TABLE_CELL = 'tableCell';
