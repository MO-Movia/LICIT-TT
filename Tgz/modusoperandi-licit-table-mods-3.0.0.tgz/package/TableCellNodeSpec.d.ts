import { DOMOutputSpec, Node, NodeSpec } from 'prosemirror-model';
export declare const TableCellNodeSpec: (nodespec: NodeSpec) => {
    attrs: {
        fullSize: {
            default: number;
        };
        vAlign: {
            default: string;
        };
    };
    parseDOM: {
        tag: string;
        getAttrs: (dom: HTMLElement) => {
            fullSize: number;
            vAlign: string;
        };
    }[];
    toDOM(node: Node): DOMOutputSpec;
    content?: string;
    marks?: string;
    group?: string;
    inline?: boolean;
    atom?: boolean;
    selectable?: boolean;
    draggable?: boolean;
    code?: boolean;
    whitespace?: "pre" | "normal";
    definingAsContext?: boolean;
    definingForContent?: boolean;
    defining?: boolean;
    isolating?: boolean;
    toDebugString?: (node: Node) => string;
    leafText?: (node: Node) => string;
    linebreakReplacement?: boolean;
    disableDropCursor?: boolean | ((view: import("prosemirror-view").EditorView, pos: {
        pos: number;
        inside: number;
    }, event: DragEvent) => boolean);
};
export default TableCellNodeSpec;
