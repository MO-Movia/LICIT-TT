import { Plugin } from 'prosemirror-state';
import { Schema } from 'prosemirror-model';
export declare class TableExtensionPlugin extends Plugin {
    constructor();
    getEffectiveSchema(schema: Schema): Schema;
}
