import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState } from 'prosemirror-state';
import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare function setParagraphSpacing(tr: Transform, schema: Schema, paragraphSpacing?: string, isAfter?: boolean): Transform;
export declare class ParagraphSpacingCommand extends UICommand {
    renderLabel(): any;
    isActive(): boolean;
    cancel(): void;
    waitForUserInput(): Promise<any>;
    executeWithUserInput(): boolean;
    executeCustom(state: EditorState, tr: Transform): Transform;
    executeCustomStyleForTable(state: EditorState, tr: Transform): Transform;
    _paragraphSpacing?: string;
    _isAfter?: boolean;
    constructor(paragraphSpacing?: string, isAfter?: boolean);
    execute: (state: EditorState, dispatch?: (tr: Transform) => void) => boolean;
}
