import React from 'react';
import { uuid } from './Uuid';
import { CustomStyleItem } from './CustomStyleItem';
import { CustomStyleSubMenu } from './CustomStyleSubMenu';
import { CustomStyleEditor } from './CustomStyleEditor';
import { applyLatestStyle, CustomStyleCommand, updateDocument, } from '../CustomStyleCommand';
import { setStyles, saveStyle, renameStyle, removeStyle, addStyleToList, } from '../customStyle';
import { setTextAlign, setTextLineSpacing, atViewportCenter, createPopUp, HeadingCommand, } from '@modusoperandi/licit-ui-commands';
import { setParagraphSpacing } from '../ParagraphSpacingCommand';
import { RESERVED_STYLE_NONE } from '../CustomStyleNodeSpec';
let HEADING_COMMANDS = {
    [RESERVED_STYLE_NONE]: new HeadingCommand(0),
};
// eslint-disable-next-line
export class CustomMenuUI extends React.PureComponent {
    _popUp = null;
    _stylePopup = null;
    _styleName = null;
    _menuItemHeight = 28;
    _id = uuid();
    _selectedIndex = 0;
    state = {
        expanded: false,
        style: {
            display: 'none',
            top: '',
            left: '',
        },
    };
    render() {
        const { dispatch, editorState, editorView, staticCommand, onCommand } = this.props;
        const children = [];
        const children1 = [];
        let counter = 0;
        let selecteClassName = '';
        const theme = this.props.theme;
        const selectedName = this.getTheSelectedCustomStyle(this.props.editorState);
        const commandGroups_nw = this.getCommandGroups();
        commandGroups_nw.forEach((group) => {
            Object.keys(group).forEach((label) => {
                const command = group[label];
                counter++;
                if (label === selectedName && '' === selecteClassName) {
                    selecteClassName = 'selectbackground';
                    this._selectedIndex = counter;
                }
                else {
                    selecteClassName = '';
                }
                children.push(React.createElement(CustomStyleItem, { command: command, disabled: !!editorView?.disabled, dispatch: dispatch, editorState: editorState, editorView: editorView, hasText: true, key: label, label: label, onClick: this._onUIEnter, onCommand: onCommand, onMouseEnter: this._onUIEnter, selectionClassName: selecteClassName, value: command }));
            });
        });
        staticCommand.forEach((group) => {
            Object.keys(group).forEach((label) => {
                const command = group[label];
                children1.push(React.createElement(CustomStyleItem, { command: command, disabled: !!editorView?.disabled, dispatch: dispatch, editorState: editorState, editorView: editorView, hasText: false, key: label, label: command._customStyleName, onClick: this._onUIEnter, onCommand: onCommand, onMouseEnter: this._onUIEnter, selectionClassName: '', value: command }));
            });
        });
        const className = 'molsp-dropbtn ' + theme;
        return (React.createElement("div", null,
            React.createElement("span", { "data-cy": "cyStyleDropdown" },
                React.createElement("div", { className: className, id: this._id },
                    React.createElement("div", { className: "molsp-stylenames" }, children),
                    React.createElement("hr", { className: "molsp-stylenames-hr" }),
                    React.createElement("div", { className: "molsp-stylenames" }, children1)))));
    }
    componentDidMount() {
        const styleDiv = document.getElementsByClassName('molsp-stylenames')[0];
        styleDiv.scrollTop =
            this._menuItemHeight * this._selectedIndex - this._menuItemHeight * 2 - 5;
    }
    isAllowedNode(node) {
        return (node.type.name === 'paragraph' ||
            node.type.name === 'ordered_list' ||
            node.type.name === 'enhanced_table_figure_notes');
    }
    _onUIEnter = (command, event) => {
        if (command.shouldRespondToUIEvent(event)) {
            // check the mouse clicked on down arror to show sub menu
            if (event.currentTarget.className === 'czi-custom-menu-item edit-icon') {
                this.showSubMenu(command, event);
            }
            else {
                this._execute(command, event);
            }
        }
    };
    _execute = (command, e) => {
        if (undefined !== command) {
            const { dispatch, editorState, editorView, onCommand } = this.props;
            command.execute(editorState, dispatch, editorView, e);
            onCommand?.();
        }
    };
    //shows the alignment and line spacing option
    showSubMenu(command, event) {
        const anchor = event ? event.currentTarget : null;
        // close the popup toggling effect
        if (this._stylePopup) {
            this._stylePopup.close();
            this._stylePopup = null;
            return;
        }
        this._popUp = createPopUp(CustomStyleSubMenu, {
            command: command,
            theme: this.props.theme,
        }, {
            anchor,
            autoDismiss: true,
            IsChildDialog: true,
            onClose: (val) => {
                if (this._popUp) {
                    this._popUp = null;
                    if (undefined !== val && val.command._customStyle) {
                        // do edit,remove,rename code here
                        if ('remove' === val.type) {
                            removeStyle(val.command._customStyleName).then(() => {
                                // [FS] IRAD-1099 2020-11-17
                                // Issue fix: Even the applied style is removed the style name is showing in the editor
                                this.removeCustomStyleName(this.props.editorState, val.command._customStyleName, this.props.editorView.dispatch);
                            });
                        }
                        else if ('rename' === val.type) {
                            this.showStyleWindow(command, event, 2);
                        }
                        else {
                            this.showStyleWindow(command, event, 1);
                        }
                    }
                }
            },
        });
    }
    // [FS] IRAD-1099 2020-11-17
    // Issue fix: Even the applied style is removed the style name is showing in the editor
    removeCustomStyleName(editorState, removedStyleName, dispatch) {
        const { selection, doc } = editorState;
        let { from, to } = selection;
        const { empty } = selection;
        if (empty) {
            from = selection.$from.before(1);
            to = selection.$to.after(1);
        }
        let tr = editorState.tr;
        const customStyleName = RESERVED_STYLE_NONE;
        const tasks = [];
        const textAlignNode = [];
        doc.nodesBetween(0, doc.nodeSize - 2, (node, pos) => {
            if (node.content?.content?.length) {
                if (node?.content?.content?.[0]?.marks?.length) {
                    node.content.content[0].marks.some((mark) => {
                        if (node.attrs.styleName === removedStyleName) {
                            tasks.push({ node, pos, mark });
                        }
                    });
                }
                else {
                    textAlignNode.push({ node, pos });
                }
            }
        });
        if (!tasks.length) {
            textAlignNode.forEach((eachnode) => {
                const { node, pos } = eachnode;
                const newattrs = { ...node.attrs, styleName: customStyleName };
                tr = tr?.setNodeMarkup(pos, undefined, newattrs);
            });
            // to remove both text align format and line spacing
            tr = this.removeTextAlignAndLineSpacing(tr, editorState.schema);
        }
        tasks.forEach((job) => {
            const { node, mark, pos } = job;
            tr = tr.removeMark(pos, pos + node.nodeSize, mark.type);
            // reset the custom style name to NONE after remove the styles
            const newattrs = { ...node.attrs, styleName: customStyleName };
            tr = tr.setNodeMarkup(pos, undefined, newattrs);
            const newNode = tr.doc.nodeAt(pos);
            // FIX: Rest to Normal not working for font size.
            tr = applyLatestStyle(newNode?.attrs?.styleName, editorState, tr, newNode, pos, pos + node.nodeSize - 1, null, 1);
        });
        // to remove both text align format and line spacing
        tr = this.removeTextAlignAndLineSpacing(tr, editorState.schema);
        tr.doc.nodesBetween(from, to, (node, startPos) => {
            if (node.type.name === 'paragraph') {
                tr = tr.setNodeMarkup(startPos, undefined, node.attrs);
            }
        });
        if (dispatch && tr.docChanged) {
            dispatch(tr);
            return true;
        }
        return false;
    }
    // to remove the text align, line spacing, paragraph spacing after and before format if applied.
    removeTextAlignAndLineSpacing(tr, schema) {
        tr = setTextAlign(tr, schema, null);
        tr = setTextLineSpacing(tr, schema, null);
        tr = setParagraphSpacing(tr, schema, '0', true);
        tr = setParagraphSpacing(tr, schema, '0', false);
        return tr;
    }
    //shows the alignment and line spacing option
    showStyleWindow(command, _event, mode) {
        // close the popup toggling effect
        if (this._stylePopup) {
            this._stylePopup.close();
            this._stylePopup = null;
        }
        this._styleName = command._customStyleName;
        this._stylePopup = createPopUp(CustomStyleEditor, {
            styleName: command._customStyleName,
            mode: mode, //edit
            description: command._customStyle.description,
            styles: command._customStyle.styles,
            editorView: this.props.editorView,
        }, {
            position: atViewportCenter,
            autoDismiss: false,
            IsChildDialog: false,
            onClose: (val) => {
                if (this._stylePopup) {
                    //handle save style object part here
                    if (undefined !== val) {
                        const { dispatch } = this.props.editorView;
                        // [FS] IRAD-1112 2020-12-14
                        // Issue fix: Duplicate style created while modified the style name.
                        delete val.runtime;
                        if (1 === mode) {
                            // update
                            delete val.editorView;
                            let tr;
                            saveStyle(val).then((result) => {
                                if (result) {
                                    //in bladelicitruntime, the response of the saveStyle() changed from list to a object
                                    //so need to add that style object to the current style list
                                    if (!Array.isArray(result)) {
                                        result = addStyleToList(result);
                                    }
                                    setStyles(result);
                                    result.forEach((obj) => {
                                        if (val.styleName === obj.styleName) {
                                            tr = updateDocument(this.props.editorState, this.props.editorState.tr, val.styleName, obj);
                                        }
                                    });
                                    if (tr) {
                                        dispatch(tr);
                                    }
                                }
                                this.props.editorView.focus();
                                this._stylePopup.close();
                                this._stylePopup = null;
                            });
                        }
                        else {
                            // rename
                            renameStyle(this._styleName, val.styleName).then((result) => {
                                // [FS] IRAD-1133 2021-01-06
                                // Issue fix: After modify a custom style, the modified style not applied to the paragraph.
                                if (null != result) {
                                    let tr;
                                    delete val.editorView;
                                    saveStyle(val).then((result) => {
                                        if (result) {
                                            //in bladelicitruntime, the response of the saveStyle() changed from list to a object
                                            //so need to add that style object to the current style list
                                            if (!Array.isArray(result)) {
                                                result = addStyleToList(result);
                                            }
                                            setStyles(result);
                                            result.forEach((obj) => {
                                                if (val.styleName === obj.styleName) {
                                                    tr = this.renameStyleInDocument(this.props.editorState, this.props.editorState.tr, this._styleName, val.styleName);
                                                }
                                            });
                                            if (tr) {
                                                dispatch(tr);
                                            }
                                        }
                                        this.props.editorView.focus();
                                        this._stylePopup.close();
                                        this._stylePopup = null;
                                    });
                                }
                            });
                        }
                    }
                }
                this.props.editorView.focus();
            },
        });
    }
    // [FS] IRAD-1237 2021-05-05
    // Issue fix: Rename style not working on the fly
    renameStyleInDocument(state, tr, oldStyleName, styleName) {
        const { doc } = state;
        doc.descendants(function (child, pos) {
            if (oldStyleName === child.attrs.styleName) {
                const newAttrs = { ...child.attrs, styleName };
                tr = tr.setNodeMarkup(pos, undefined, newAttrs);
            }
        });
        return tr;
    }
    // [FS] IRAD-1308 2020-04-21
    // To get the customstylename of the selected paragraph
    getTheSelectedCustomStyle(editorState) {
        const { selection, doc } = editorState;
        const { from, to } = selection;
        let customStyleName = RESERVED_STYLE_NONE;
        doc.nodesBetween(from, to, (node) => {
            if (this.isAllowedNode(node)) {
                if (node.attrs.styleName) {
                    customStyleName = node.attrs.styleName;
                }
            }
        });
        return customStyleName;
    }
    //[FS] IRAD-1085 2020-10-09
    //method to build commands for list buttons
    getCommandGroups() {
        HEADING_COMMANDS = {
            // [FS] IRAD-1074 2020-12-09
            // When apply 'None' from style menu, not clearing the applied custom style.
            [RESERVED_STYLE_NONE]: new CustomStyleCommand(RESERVED_STYLE_NONE, RESERVED_STYLE_NONE),
        };
        const result = addStyleToList(undefined);
        let HEADING_NAMES = null;
        if (result) {
            setStyles(result);
            HEADING_NAMES = result;
            if (null != HEADING_NAMES) {
                const foundNormal = result.find((obj) => obj.styleName === RESERVED_STYLE_NONE);
                if (foundNormal) {
                    HEADING_COMMANDS[RESERVED_STYLE_NONE] = new CustomStyleCommand(foundNormal, foundNormal.styleName);
                }
                HEADING_NAMES.forEach((obj) => {
                    if (RESERVED_STYLE_NONE != obj.styleName)
                        HEADING_COMMANDS[obj.styleName] = new CustomStyleCommand(obj, obj.styleName);
                });
            }
            return [HEADING_COMMANDS];
        }
        return [HEADING_COMMANDS];
    }
}
