import { HeadingCommand } from '@modusoperandi/licit-ui-commands';
import React from 'react';
import { EditorState } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { Transform } from 'prosemirror-transform';
import { Node } from 'prosemirror-model';
export declare class CustomstyleDropDownCommand extends React.PureComponent<{
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView?: EditorView;
}> {
    hasRuntime: boolean;
    getCommandGroups(): {
        Normal: HeadingCommand;
    }[];
    staticCommands(customStyleName: any): {}[];
    isAllowedNode(node: Node): boolean;
    render(): React.ReactElement;
}
