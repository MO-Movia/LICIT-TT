import React from 'react';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import type { PointerSurfaceProps } from '@modusoperandi/licit-ui-commands';
import { HTMLStyles } from '../StyleRuntime';
import { CustomStyleCommand } from '../CustomStyleCommand';
export declare class CustomStyleItem extends React.PureComponent<PointerSurfaceProps & {
    command: CustomStyleCommand;
    disabled?: boolean;
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView?: EditorView;
    label: string;
    onClick?: (value: unknown, e: React.SyntheticEvent) => void;
    onMouseEnter?: (value: unknown, e: React.SyntheticEvent) => void;
    hasText?: boolean;
    onCommand?: () => void;
    selectionClassName?: string;
}> {
    render(): React.ReactElement;
    sampleLevel(styles: HTMLStyles): string;
    hasBoldPartial(styles: HTMLStyles): boolean;
    hasBoldSentence(styles: HTMLStyles): boolean;
}
