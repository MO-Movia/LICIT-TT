import cx from 'classnames';
import React from 'react';
import { RESERVED_STYLE_NONE } from '../CustomStyleNodeSpec';
export class CustomStyleSubMenu extends React.PureComponent {
    render() {
        const { command, theme } = this.props;
        const showmenu = RESERVED_STYLE_NONE != command._customStyleName;
        const className = 'molsp-dropdown-content ' + theme;
        const divClassName = cx(className, {
            'div-height-large': showmenu,
            'div-height-small': !showmenu,
        });
        return (React.createElement("div", { className: divClassName, "data-cy": "cyStyleEditDropdown", id: "mo-submenu" },
            React.createElement("a", { onClick: () => this.onButtonClick({ type: 'modify', command }) }, "Modify Style.."),
            RESERVED_STYLE_NONE != command._customStyleName && (React.createElement(React.Fragment, null,
                React.createElement("a", { onClick: () => this.onButtonClick({ type: 'rename', command }) }, "Rename Style.."),
                React.createElement("a", { "data-cy": "cyStyleEditReset", onClick: () => this.onButtonClick({ type: 'remove', command }) }, "Reset Style to Normal..")))));
    }
    //handles the option button click, close the popup with selected values
    onButtonClick(val) {
        this.props.close(val);
    }
}
