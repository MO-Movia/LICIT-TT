import React from 'react';
export declare class AlertInfo extends React.PureComponent<{
    title: string;
    content: string | React.ReactElement;
    close: () => void;
}> {
    render(): React.ReactElement;
    _cancel: () => void;
}
