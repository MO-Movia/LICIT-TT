import React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export declare class CustomStyleSubMenu extends React.PureComponent<{
    command: UICommand;
    theme?: string;
    disabled?: boolean;
    close: (value: unknown) => void;
}, unknown> {
    render(): React.ReactElement<unknown>;
    onButtonClick(val: any): void;
}
