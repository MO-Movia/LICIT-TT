import React from 'react';
export default function TextEditorBox(props: any): React.JSX.Element;
