// [FS] IRAD-1039 2020-09-23
// Command button to handle different type of list types
// Need to add Icons instead of label
import cx from 'classnames';
import React from 'react';
import { CustomButton, createPopUp, ThemeContext } from '@modusoperandi/licit-ui-commands';
import { uuid } from './Uuid';
import { CustomMenuUI } from './CustomMenuUI';
export class CustomMenuButton extends React.PureComponent {
    state = {
        expanded: false,
    };
    static contextType = ThemeContext;
    _menu = null;
    _id = uuid();
    render() {
        const { className, label, icon, title } = this.props;
        const { expanded } = this.state;
        const theme_1 = this.context;
        const buttonClassName = cx(className, {
            'czi-custom-menu-button': true,
            expanded,
        });
        return (React.createElement(CustomButton, { className: buttonClassName, disabled: this.props.disabled, icon: icon, id: this._id, label: label, onClick: this._onClick, theme: theme_1?.toString(), title: title }));
    }
    componentWillUnmount() {
        this._hideMenu();
    }
    _onClick = () => {
        this.setState((lastState) => {
            const expanded = !lastState.expanded;
            if (expanded) {
                this._showMenu();
            }
            else {
                this._hideMenu();
            }
            return {
                expanded,
            };
        });
    };
    _hideMenu = () => {
        const menu = this._menu;
        this._menu = null;
        menu?.close();
    };
    _showMenu = () => {
        const menu = this._menu;
        const menuProps = {
            ...this.props,
            onCommand: this._onCommand,
            theme: this.context
            // popupId: this._popupId
        };
        if (menu) {
            menu.update(menuProps);
        }
        else {
            this._menu = createPopUp(CustomMenuUI, menuProps, {
                autoDismiss: true,
                // Id: this._popupId,
                anchor: document.getElementById(this._id),
                onClose: this._onClose,
            });
        }
    };
    _onCommand = () => {
        this.setState({ expanded: false });
        this._hideMenu();
    };
    _onClose = () => {
        if (this._menu) {
            this.setState({ expanded: false });
            this._menu = null;
        }
    };
}
