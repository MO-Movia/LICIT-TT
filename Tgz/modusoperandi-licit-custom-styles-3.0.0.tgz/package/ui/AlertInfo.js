import React from 'react';
export class AlertInfo extends React.PureComponent {
    render() {
        const title = this.props.title || 'Document Error!';
        const content = this.props.content ||
            'Unable to load the document. Have issues in Json format, please verify...';
        return (React.createElement("div", { className: "alert" },
            React.createElement("strong", null, title),
            React.createElement("span", null, content)));
    }
    _cancel = () => {
        this.props.close();
    };
}
