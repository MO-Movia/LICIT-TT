import React from 'react';
export declare class SuperscriptIcon extends React.PureComponent {
    render(): React.ReactElement;
}
export declare class SubscriptIcon extends React.PureComponent {
    render(): React.ReactElement;
}
export declare class Icon extends React.PureComponent<{
    type: string;
    title?: string;
}, unknown> {
    static get(type: string, title?: string): React.ReactElement;
    render(): React.ReactElement;
}
