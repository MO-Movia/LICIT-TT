import React from 'react';
import { getCustomStyleByName, getCustomStyle, getStyleRuntime } from '../customStyle';
import { getDetailsBullet } from '../CustomStyleNodeSpec';
import { PointerSurface } from '@modusoperandi/licit-ui-commands';
import { Icon } from './Icon';
import cx from 'classnames';
export class CustomStyleItem extends React.PureComponent {
    render() {
        const { label, hasText, ...pointerProps } = this.props;
        let text = '';
        let customStyle;
        // [FS] IRAD-1410 2021-06-28
        // The numbering in custom style drop menu not showing properly
        text = ' AaBbCcDd';
        const level = this.sampleLevel(pointerProps.command._customStyle.styles);
        const hasBoldPartial = this.hasBoldPartial(pointerProps.command._customStyle.styles);
        // [FS] IRAD-1505 2021-07-07
        // Style menu not showing properly for First Word Bold
        const hasBoldSentence = this.hasBoldSentence(pointerProps.command._customStyle.styles);
        // [FS] IRAD-1394 2021-05-25
        // Added two divs to display Numbering and bold first word/sentece.
        const BOLD_WORD = 'AaBb  ';
        const BOLD_SENTENCE = 'AaBbCc. ';
        const styleProps = getCustomStyleByName(label);
        const className = 'czi-custom-menu-item';
        if (styleProps?.styles) {
            customStyle = getCustomStyle(styleProps.styles);
        }
        const klass = cx(className);
        return (React.createElement("div", { className: this.props.selectionClassName, id: "container1", title: label },
            React.createElement("div", { style: { width: '140px', height: 'auto' } },
                React.createElement(PointerSurface, { ...pointerProps, className: klass, style: { display: 'inline-block', width: '140px' } }, label)),
            React.createElement("div", { style: {
                    display: level === '' ? 'none' : '',
                    // [FS] IRAD-1410 2021-06-02
                    // Issue: Number example in custom style menu box not showing properly
                    marginTop: '-4px',
                    fontWeight: pointerProps.command._customStyle.styles?.boldNumbering
                        ? 'bold'
                        : 'normal',
                } },
                React.createElement(PointerSurface, { ...pointerProps, className: klass, style: customStyle }, level)),
            React.createElement("div", { style: {
                    display: pointerProps.command._customStyle.styles?.hasBullet
                        ? ''
                        : 'none',
                    color: pointerProps.command._customStyle.styles?.bulletLevel
                        ? getDetailsBullet(pointerProps.command._customStyle.styles.bulletLevel).color
                        : '',
                    marginTop: '-4px',
                } },
                React.createElement(PointerSurface, { ...pointerProps, className: klass }, pointerProps.command._customStyle.styles?.bulletLevel
                    ? getDetailsBullet(pointerProps.command._customStyle.styles.bulletLevel).symbol
                    : '')),
            React.createElement("div", { style: {
                    display: hasBoldPartial ? '' : 'none',
                    // [FS] IRAD-1410 2021-06-03
                    // Issue: Number example along with Bold first word in custom style menu box not showing properly
                    marginTop: '-4px',
                    fontWeight: hasBoldPartial ? 'bold' : 'normal',
                } },
                React.createElement(PointerSurface, { ...pointerProps, className: klass, style: customStyle }, hasBoldPartial && hasBoldSentence ? BOLD_SENTENCE : BOLD_WORD)),
            hasText && (React.createElement("div", { className: "molsp-style-sampletext", style: customStyle },
                React.createElement(PointerSurface, { ...pointerProps, className: klass, style: customStyle }, text))),
            React.createElement("div", { className: "molsp-arrow-right", "data-cy": "cyStyleEdit", style: { width: '50px', display: (hasText && getStyleRuntime()?.canEditStyle) ? 'block' : 'none' } },
                React.createElement(PointerSurface, { ...pointerProps, className: klass + ' edit-icon' },
                    Icon.get('edit'),
                    ''))));
    }
    // [FS] IRAD-1394 2021-05-25
    // To show Numbering in dropdown menu sample text
    sampleLevel(styles) {
        let level = '';
        if (this.props.hasText &&
            styles &&
            (styles.hasNumbering || styles.isList)) {
            for (let i = 0; i < styles.styleLevel; i++) {
                if (i === 0 && styles.prefixValue) {
                    level = level + styles.prefixValue + '1.';
                }
                else {
                    level = level + '1.';
                }
            }
        }
        if (this.props.hasText && styles?.hasBullet) {
            level = '';
        }
        return level;
    }
    hasBoldPartial(styles) {
        return !!styles?.boldPartial;
    }
    hasBoldSentence(styles) {
        return !!styles?.boldSentence;
    }
}
