import React from 'react';
import { canUseCSSFont } from './canUseCSSFont';
const cached = {};
const CSS_CDN_URL = '//fonts.googleapis.com/icon?family=Material+Icons';
const CSS_FONT = 'Material Icons';
(async function () {
    // Inject CSS Fonts reuqired for toolbar icons.
    const fontSupported = await canUseCSSFont(CSS_FONT);
    if (!fontSupported) {
        console.info('Add CSS from ', CSS_CDN_URL);
        // [FS] IRAD-1061 2020-09-19
        // Now loaded locally, so that it work in closed network as well.
        //injectStyleSheet(CSS_CDN_URL);
    }
})();
export class SuperscriptIcon extends React.PureComponent {
    render() {
        return (React.createElement("span", { className: "superscript-wrap" },
            React.createElement("span", { className: "superscript-base" }, "x"),
            React.createElement("span", { className: "superscript-top" }, "y")));
    }
}
export class SubscriptIcon extends React.PureComponent {
    render() {
        return (React.createElement("span", { className: "subscript-wrap" },
            React.createElement("span", { className: "subscript-base" }, "x"),
            React.createElement("span", { className: "subscript-bottom" }, "y")));
    }
}
export class Icon extends React.PureComponent {
    static get(type, title) {
        const key = `${type || ''}-${title || ''}`;
        const icon = cached[key] || React.createElement(Icon, { title: title, type: type });
        cached[key] = icon;
        return icon;
    }
    render() {
        const { type, title } = this.props;
        let className = '';
        let children = '';
        if (type === 'superscript') {
            className = 'czi-icon superscript';
            children = React.createElement(SuperscriptIcon, null);
        }
        else if (type === 'subscript') {
            className = 'czi-icon subscript';
            children = React.createElement(SubscriptIcon, null);
        }
        else if (!type || !/^[A-Za-z0-9_-]+$/.test(type)) {
            className = 'czi-icon-unknown';
            children = title || type;
        }
        else {
            className = `czi-icon ${type}`;
            children = type;
        }
        return React.createElement("span", { className: className }, children);
    }
}
