import React, { SyntheticEvent } from 'react';
import { EditorState } from 'prosemirror-state';
import { Schema, Node } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { HeadingCommand } from '@modusoperandi/licit-ui-commands';
export declare class CustomMenuUI extends React.PureComponent<any, any> {
    _popUp: any;
    _stylePopup: any;
    _styleName: any;
    _menuItemHeight: number;
    _id: string;
    _selectedIndex: number;
    state: {
        expanded: boolean;
        style: {
            display: string;
            top: string;
            left: string;
        };
    };
    render(): React.JSX.Element;
    componentDidMount(): void;
    isAllowedNode(node: Node): boolean;
    _onUIEnter: (command: UICommand, event: SyntheticEvent<Element>) => void;
    _execute: (command: UICommand, e: SyntheticEvent<Element>) => void;
    showSubMenu(command: UICommand, event: SyntheticEvent<Element>): void;
    removeCustomStyleName(editorState: any, removedStyleName: any, dispatch: any): boolean;
    removeTextAlignAndLineSpacing(tr: Transform, schema: Schema): Transform;
    showStyleWindow(command: any, _event: SyntheticEvent<Element>, mode: any): void;
    renameStyleInDocument(state: EditorState, tr: Transform, oldStyleName: any, styleName: any): Transform;
    getTheSelectedCustomStyle(editorState: any): string;
    getCommandGroups(): {
        Normal: HeadingCommand;
    }[];
}
