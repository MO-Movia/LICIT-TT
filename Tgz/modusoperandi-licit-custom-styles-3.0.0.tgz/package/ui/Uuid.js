import { v1 as uuidv1 } from 'uuid';
export function uuid() {
    return uuidv1();
}
