export declare const cached: {
    [key: string]: Promise<boolean>;
};
export declare function canUseCSSFont(fontName: string): Promise<boolean>;
