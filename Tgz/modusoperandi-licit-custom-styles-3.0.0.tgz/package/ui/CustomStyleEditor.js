// [FS] IRAD-1048 2020-09-24
// UI for Custom Style edit
//Need to change the button binding implementation
import React from 'react';
import { atViewportCenter, ColorEditor, createPopUp, getLineSpacingValue, } from '@modusoperandi/licit-ui-commands';
import { isCustomStyleExists, setStyles, saveStyle, getStylesAsync, addStyleToList, } from '../customStyle';
import { RESERVED_STYLE_NONE, getDetailsBullet, BULLET_POINTS, } from '../CustomStyleNodeSpec';
import { AlertInfo } from './AlertInfo';
let customStyles = [];
const otherStyleSelected = false;
const editedStyles = [];
const FONT_PT_SIZES = [8, 9, 10, 11, 12, 14, 18, 24, 30, 36, 48, 60, 72, 90];
const FONT_TYPE_NAMES = [
    // SERIF
    'Aclonica',
    'Acme',
    'Alegreya',
    'Arial',
    //'Arial',//??? - Commented out fonts that are not available to download using https://fonts.googleapis.com/css?family=
    'Arial Black',
    'Georgia',
    'Tahoma',
    'Times New Roman',
    'Times',
    'Verdana',
    // MONOSPACE
    'Courier New',
    //'Lucida Console',//???
    //'Monaco',//???
    //'monospace',//???
];
// Values to show in Linespacing drop-down
const LINE_SPACE = ['Single', '1.15', '1.5', 'Double'];
// Values to show in numbering/indent drop-down
const LEVEL_VALUES = [
    'None',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
];
const SAMPLE_TEXT = `Sample Text Sample Text Sample Text Sample Text Sample Text Sample Text Sample Text Sample.
Sample Text Sample Text Sample Text Sample Text Sample Text`;
// eslint-disable-next-line
export class CustomStyleEditor extends React.PureComponent {
    _popUp = null;
    constructor(props) {
        super(props);
        editedStyles.splice(0, editedStyles.length);
        this.state = {
            ...props,
            selectedStyleMode: 'none',
            isHidden: false,
            otherStyleSelected,
            customStyles,
            selectedStyle: 'userDefined',
        };
        // set default values for text alignment and boldNumbering checkbox.
        if (!this.state.styles.align) {
            this.state.styles.align = 'left';
        }
        if (0 === this.state.mode) {
            this.state.styles.boldNumbering = true;
            this.state.styles.toc = false;
            this.state.styles.tof = false;
            this.state.styles.tot = false;
            this.state.styles.isHidden = false;
            this.state.styles.boldSentence = true;
            this.state.styles.nextLineStyleName = RESERVED_STYLE_NONE;
        }
        if (!this.state.styles.selectedStyleMode) {
            this.state.styles.selectedStyleMode = 'none';
        }
        if (!this.state.styles.fontName) {
            this.state.styles.fontName = 'Arial';
        }
        if (!this.state.styles.fontSize) {
            this.state.styles.fontSize = '11';
        }
        this.getCustomStyles();
    }
    // To set the selected style values
    onStyleClick(style, event) {
        let state = null;
        switch (style) {
            // simple toggles where style matches the key to change.
            case 'strong':
            case 'em':
            case 'strike':
            case 'super':
            case 'underline':
                // copy the current style values, and flip the matching value
                state = { styles: { ...this.state.styles } };
                if (state.styles[style] === true) {
                    state.styles[style] = undefined;
                }
                else {
                    state.styles[style] = !state.styles[style];
                }
                break;
            case 'name':
                if (event) {
                    const oldName = this.state.styleName;
                    const newName = event.target.value;
                    state = { styleName: newName, styles: null };
                    state.styles = { ...this.state.styles };
                    if (this.state.styles.nextLineStyleName === oldName) {
                        // Update next line style as well.
                        state.styles.nextLineStyleName = newName;
                    }
                }
                break;
            case 'description':
                if (event) {
                    state = { description: event.target.value };
                }
                break;
            // [FS] IRAD-1497 2021-06-30
            // Not able to set paragraph spacing before and after.
            case 'before':
                if (event) {
                    state = {
                        styles: {
                            ...this.state.styles,
                            paragraphSpacingBefore: event.target.value,
                        },
                    };
                }
                break;
            case 'after':
                if (event) {
                    state = {
                        styles: {
                            ...this.state.styles,
                            paragraphSpacingAfter: event.target.value,
                        },
                    };
                }
                break;
            default:
                break;
        }
        // save changes and update
        if (state) {
            this.setState(state, () => this.buildStyle());
        }
    }
    // Build styles to display the example piece
    buildStyle() {
        const style = {};
        if (this.state.styles.fontName) {
            style.fontFamily = this.state.styles.fontName;
        }
        if (this.state.styles.fontSize) {
            style.fontSize = `${this.state.styles.fontSize}px`;
        }
        if (this.state.styles.strong) {
            style.fontWeight = 'bold';
        }
        if (this.state.styles.color) {
            style.color = this.state.styles.color;
        }
        if (this.state.styles.underline) {
            style.textDecoration =
                undefined !== style.textDecoration
                    ? `${style.textDecoration}${' underline'}`
                    : 'underline';
        }
        if (this.state.styles.strike) {
            style.textDecoration =
                undefined !== style.textDecoration
                    ? `${style.textDecoration}${' line-through'}`
                    : 'line-through';
        }
        if (this.state.styles.em) {
            style.fontStyle = 'italic';
        }
        if (this.state.styles.textHighlight) {
            style.backgroundColor = this.state.styles.textHighlight;
        }
        if (this.state.styles.align) {
            style.textAlign = this.state.styles.align;
        }
        if (this.state.styles.lineHeight) {
            // [FS] IRAD-1104 2020-11-13
            // Issue fix : Linespacing Double and Single not applied in the sample text paragraph
            style.lineHeight = getLineSpacingValue(this.state.styles.lineHeight);
        }
        // [FS] IRAD-1111 2020-12-10
        // Issue fix : Paragraph space before is not applied in the sample text.
        if (this.state.styles.paragraphSpacingBefore) {
            style.marginTop = `${this.state.styles.paragraphSpacingBefore}px`;
        }
        // [FS] IRAD-1111 2020-12-10
        // Issue fix : Paragraph space after is not applied in the sample text.
        if (this.state.styles.paragraphSpacingAfter) {
            style.marginBottom = `${this.state.styles.paragraphSpacingAfter}px`;
        }
        // [FS] IRAD-1111 2020-12-10
        // Issue fix : Indent is not applied in the sample text.
        if (!this.state.styles.isLevelbased) {
            if (this.state.styles.indent) {
                style.marginLeft = `${parseInt(this.state.styles.indent) * 2}px`;
            }
        }
        else {
            const levelValue = document?.getElementById('levelValue');
            if (
            // this covers null & undefined
            levelValue instanceof window.HTMLSelectElement &&
                levelValue.value) {
                style.marginLeft = `${parseInt(levelValue.value) * 2}px`;
            }
        }
        const sampleDiv = document.getElementById('sampletextdiv');
        if (sampleDiv) {
            // [FS] IRAD-1394 2021-06-02
            // Issue: numbering sample not working when select Bold first sentence
            let textSample = SAMPLE_TEXT;
            if (this.state.styles.boldPartial) {
                const fragment = document.createDocumentFragment();
                if (this.state.styles.boldSentence) {
                    const [firstSentence, ...rest] = SAMPLE_TEXT.split('.');
                    const boldElement = document.createElement('strong');
                    boldElement.innerText = `${firstSentence}.`;
                    fragment.appendChild(boldElement);
                    fragment.appendChild(document.createTextNode(rest.join('.')));
                }
                else {
                    const [firstWord, ...rest] = SAMPLE_TEXT.split(' ');
                    const boldElement = document.createElement('strong');
                    boldElement.innerText = firstWord;
                    fragment.appendChild(boldElement);
                    fragment.appendChild(document.createTextNode(` ${rest.join(' ')}`));
                }
                // Clear previous content using a loop
                while (sampleDiv.firstChild) {
                    sampleDiv.removeChild(sampleDiv.firstChild);
                }
                const newContentContainer = document.createElement('div');
                // Populate the fragment dynamically
                fragment.childNodes.forEach((child) => {
                    newContentContainer.appendChild(child.cloneNode(true));
                });
                // Append the fragment or new content to the sampleDiv
                sampleDiv.appendChild(newContentContainer);
                textSample = sampleDiv.innerText;
                // [FS] IRAD-1473 2021-06-30
                // Style Example not showing properly when select Bold and Bold First Sentence
                style.fontWeight = 'normal';
            }
            else {
                sampleDiv.innerText = SAMPLE_TEXT;
            }
            if (this.state.styles.styleLevel &&
                (this.state.styles.hasNumbering || this.state.styles.isList)) {
                const numberingLevel = this.getNumberingLevel(this.state.styles.styleLevel, this.state.styles.prefixValue);
                const numberingNode = document.createTextNode(numberingLevel);
                if (this.state.styles.boldNumbering) {
                    const boldElement = document.createElement('strong');
                    boldElement.appendChild(numberingNode);
                    // [FS] IRAD-1252 2024-11-19
                    // Bold the first sentence/word not working when apply numbering
                    sampleDiv.prepend(boldElement);
                }
                else {
                    // [FS] IRAD-1252 2024-11-19
                    // Bold the first sentence/word not working when apply numbering
                    sampleDiv.prepend(numberingNode);
                }
            }
            if (this.state.styles.styleLevel && this.state.styles.hasBullet) {
                const bulletDetails = getDetailsBullet(this.state.styles.bulletLevel);
                const bulletSymbol = document.createElement('strong');
                bulletSymbol.style.color = bulletDetails.color;
                bulletSymbol.innerText = bulletDetails.symbol;
                sampleDiv.innerHTML = ''; // Clear previous content
                sampleDiv.appendChild(bulletSymbol);
                sampleDiv.appendChild(document.createTextNode(textSample));
            }
        }
        return style;
    }
    // [FS] IRAD-1111 2020-12-10
    // get the numbering corresponding to the level
    getNumberingLevel(level, prefixValue) {
        let levelStyle = '';
        for (let i = 0; i < parseInt(`${level}`); i++) {
            if (i === 0 && prefixValue) {
                levelStyle = levelStyle + prefixValue + '1.';
            }
            else {
                levelStyle = levelStyle + '1.';
            }
        }
        return levelStyle + ' ';
    }
    // handles font name change
    onFontNameChange(e) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, fontName: e.target.value },
        }));
    }
    // handles indent radio button event
    onIndentRadioChanged(e) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, isLevelbased: e.target.value === '0' },
        }));
    }
    onHangingIndentChange(e) {
        const checked = e.target.checked;
        this.setState(prevState => ({
            styles: {
                ...prevState.styles,
                isHangingIndent: checked,
                indentPosition: checked ? prevState.styles.indentPosition : ''
            }
        }));
    }
    // handles scentece bold event
    onScentenceRadioChanged(e) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, boldSentence: e.target.value === '0' },
        }));
    }
    // handles font size change
    onFontSizeChange(e) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, fontSize: e.target.value },
        }));
    }
    // handles line space  change
    onLineSpaceChange(e) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, lineHeight: e.target.value },
        }));
    }
    // handles Level drop down change
    onLevelChange(e) {
        let isCheckboxDisabled = false;
        let level = Number(e.target.value);
        if (e.target.value === 'None') {
            isCheckboxDisabled = true;
            level = 0;
        }
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                styleLevel: level,
                hasNumbering: isCheckboxDisabled
                    ? false
                    : prevState.styles?.hasNumbering,
                hasBullet: isCheckboxDisabled ? false : prevState.styles?.hasBullet,
            },
        }));
    }
    // handles Bullet Level drop down change
    onBulletLevelChange(e) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, bulletLevel: e.target.value },
        }));
    }
    // handles the bullet checkbox actions
    handleBulletPoints(val) {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                hasBullet: val.target.checked,
                bulletLevel: prevState.styles.bulletLevel
                    ? prevState.styles.bulletLevel
                    : '25CF',
                hasNumbering: val.target.checked
                    ? false
                    : prevState.styles.hasNumbering,
                nextLineStyleName: val.target.checked
                    ? prevState.styleName
                    : RESERVED_STYLE_NONE,
                boldNumbering: val.target.checked
                    ? false
                    : prevState.styles.boldNumbering,
                hideNumbering: val.target.checked
                    ? false
                    : prevState.styles.hideNumbering,
            },
        }));
    }
    // handles indent dropdown change
    onIndentChange(e) {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                indent: 'None' === e.target.value ? 0 : e.target.value,
            },
        }));
    }
    onIndentPositionChange(e) {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                indentPosition: e.target.value,
            },
        }));
    }
    // [FS] IRAD-1201 2021-02-18
    // set the nextLineStyle to JSON on style selection changed
    onOtherStyleSelectionChanged(e) {
        if (this.state.otherStyleSelected) {
            this.setState((prevState) => ({
                styles: { ...prevState.styles, nextLineStyleName: e.target.value },
            }));
        }
    }
    // [FS] IRAD-1201 2021-02-18
    // set the nextLineStyle to JSON according to the selected option
    onNextLineStyleSelected(selectedOption) {
        const hiddenDiv = document.getElementById('nextStyle');
        if (hiddenDiv) {
            hiddenDiv.style.display = 'none';
        }
        if (0 === selectedOption) {
            this.setState({
                otherStyleSelected: false,
            });
            this.setState((prevState) => ({
                styles: {
                    ...prevState.styles,
                    nextLineStyleName: RESERVED_STYLE_NONE,
                },
            }));
        }
        else if (1 === selectedOption) {
            this.setState({
                otherStyleSelected: false,
            });
            this.setState((prevState) => ({
                styles: {
                    ...prevState.styles,
                    nextLineStyleName: prevState.styleName,
                },
            }));
        }
        else {
            if (hiddenDiv) {
                hiddenDiv.style.display = 'block';
            }
            const selectedStyle = document.getElementById('nextStyleValue');
            if (selectedStyle instanceof window.HTMLSelectElement) {
                this.setState((prevState) => ({
                    otherStyleSelected: true,
                    styles: {
                        ...prevState.styles,
                        nextLineStyleName: selectedStyle.options[selectedStyle.selectedIndex].text,
                    },
                }));
            }
        }
    }
    // [FS] IRAD-1127 2020-12-31
    // to populate the selected custom styles.
    onSelectCustomStyle(e) {
        if (customStyles) {
            const value = customStyles.find((u) => u.styleName === e.target.value);
            // FIX: not able to modify and save the populated style
            if (value)
                value.mode = 3;
            this.setState((prevState) => ({ ...prevState, ...value }), () => {
                const isReservedStyleNone = this.state.styleName === RESERVED_STYLE_NONE;
                const mp2 = document.getElementsByClassName('molsp-panel2')[0];
                const acc2 = document.getElementsByClassName('molsp-licit-accordion')[2];
                if (isReservedStyleNone) {
                    acc2.classList.remove('molsp-accactive');
                    mp2.style.maxHeight = null;
                }
                else {
                    acc2.classList.add('molsp-accactive');
                    mp2.style.maxHeight = '374px';
                }
                document.getElementsByClassName('molsp-panel')[0].style.maxHeight = '100%';
                document.getElementsByClassName('molsp-panel1')[0].style.maxHeight = '100%';
                document.getElementsByClassName('molsp-panel3')[0].style.maxHeight = '100%';
                // Ensure the next line style is set
                this.setNextLineStyle(this.state.styles.nextLineStyleName);
            });
        }
    }
    // shows color dialog based on input text-color/text-heighlight
    showColorDialog(isTextColor, event) {
        const anchor = event ? event.currentTarget : null;
        const hex = null;
        this._popUp = createPopUp(ColorEditor, { hex }, {
            anchor,
            autoDismiss: true,
            IsChildDialog: true,
            onClose: (val) => {
                if (this._popUp) {
                    this._popUp = null;
                    if (undefined !== val) {
                        if (isTextColor) {
                            this.setState((prevState) => ({
                                styles: { ...prevState.styles, color: val },
                            }));
                        }
                        else {
                            this.setState((prevState) => ({
                                styles: { ...prevState.styles, textHighlight: val },
                            }));
                        }
                    }
                }
            },
        });
    }
    //handles the option button click, close the popup with selected values
    onAlignButtonClick(val) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, align: val },
        }));
    }
    handleNumbering(val) {
        // if user select numbering, then always set nextLineStyle as continues this style.
        // [FS] IRAD-1221 2021-03-01
        // Issue fix: The next line style not switch back to RESERVED_STYLE_NONE when disable the numbering.
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                hasNumbering: val.target.checked,
                hasBullet: val.target.checked ? false : prevState.styles?.hasBullet,
                nextLineStyleName: val.target.checked
                    ? prevState.styleName
                    : RESERVED_STYLE_NONE,
            },
        }));
    }
    // handles the boldNumbering checkbox actions
    handleBoldNumbering(val) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, boldNumbering: val.target.checked },
        }));
    }
    // handles the boldNumbering checkbox actions
    handleBoldPartial(val) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, boldPartial: val.target.checked },
        }));
    }
    handleNone() {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                selectedStyleMode: 'none',
                toc: false,
                tot: false,
                tof: false,
                prefixValue: '',
                hasNumbering: false,
                nextLineStyleName: RESERVED_STYLE_NONE,
                styleLevel: 0,
            },
        }));
    }
    handleTOC(val) {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                selectedStyleMode: 'toc',
                toc: val.target.checked,
                tot: false,
                tof: false,
                prefixValue: '',
                hasNumbering: false,
                styleLevel: 0,
                nextLineStyleName: RESERVED_STYLE_NONE,
            },
        }));
    }
    handleTOT(val) {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                selectedStyleMode: 'tot',
                toc: false,
                tot: val.target.checked,
                tof: false,
                prefixValue: val.target.checked ? 'TABLE ' : '',
                hasNumbering: val.target.checked,
                nextLineStyleName: val.target.checked
                    ? RESERVED_STYLE_NONE
                    : prevState.styles.nextLineStyleName,
                styleLevel: val.target.checked ? 2 : 0,
            },
        }));
    }
    handleTOF(val) {
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                selectedStyleMode: 'tof',
                toc: false,
                tot: false,
                tof: val.target.checked,
                prefixValue: val.target.checked ? 'FIGURE ' : '',
                hasNumbering: val.target.checked,
                nextLineStyleName: val.target.checked
                    ? RESERVED_STYLE_NONE
                    : prevState.styles.nextLineStyleName,
                styleLevel: val.target.checked ? 2 : 0,
            },
        }));
    }
    handleList(val) {
        const selectedStyle = val.target.value;
        const isList = selectedStyle === 'listStyle';
        const styleLevel = selectedStyle === 'none' ? 0 : 1;
        if (this.state.mode > 0 && this.isCustomStyleAlreadyApplied() && !isList) {
            this.showAlert();
        }
        else {
            this.setState((prevState) => ({
                ...prevState,
                selectedStyle,
                styles: {
                    ...prevState.styles,
                    styleLevel,
                    isList,
                },
                isRadioDisabled: styleLevel === 0,
            }));
        }
    }
    handlePrefix(val) {
        //edit mode
        this.setState((prevState) => ({
            styles: {
                ...prevState.styles,
                prefixValue: val.target.value,
            },
        }));
    }
    handleHideNumbering(val) {
        this.setState((prevState) => ({
            styles: { ...prevState.styles, hideNumbering: val.target.checked },
        }));
    }
    isCustomStyleAlreadyApplied() {
        let found = false;
        const { doc } = this.state.editorView.state;
        doc.nodesBetween(0, doc.nodeSize - 2, (node) => {
            if (node.content?.content?.length) {
                if (!found && node.attrs.styleName === this.state.styleName) {
                    found = true;
                }
            }
        });
        return found;
    }
    showAlert() {
        const anchor = null;
        this._popUp = createPopUp(AlertInfo, {
            content: 'This style already used in the document,uncheck list-style will breaks the hierarchy.',
            title: 'Modify Style Alert!!!',
        }, {
            anchor,
            position: atViewportCenter,
            onClose: () => {
                if (this._popUp) {
                    this._popUp = null;
                    this.setState((prevState) => ({
                        styles: {
                            ...prevState.styles,
                            styleLevel: 1,
                            isList: true,
                        },
                    }));
                }
            },
        });
    }
    // [FS] IRAD-1201 2021-02-17
    // to check if the "select style" option selected by user
    selectStyleCheckboxState() {
        let chceked = false;
        if (this.state.styles.nextLineStyleName) {
            chceked =
                this.state.styles.nextLineStyleName !== RESERVED_STYLE_NONE &&
                    this.state.styles.nextLineStyleName !== this.state.styleName;
        }
        return chceked;
    }
    componentDidMount() {
        const acc = document.getElementsByClassName('molsp-licit-accordion');
        let i;
        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener('click', function () {
                this.classList.toggle('molsp-accactive');
                const panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                }
                else {
                    panel.style.maxHeight = panel.scrollHeight + 'px';
                }
            });
        }
        if (this.state.styleName === RESERVED_STYLE_NONE) {
            acc[2]?.classList.toggle('molsp-accactive');
            const mp2 = document.getElementsByClassName('molsp-panel2')[0];
            mp2.style.maxHeight = null;
        }
        else {
            const mp2 = document.getElementsByClassName('molsp-panel2')[0];
            setTimeout(() => {
                mp2.style.maxHeight = '374px';
            }, 0);
        }
        const mp = document.getElementsByClassName('molsp-panel')[0];
        mp.style.maxHeight = mp.scrollHeight + 'px';
        const mp1 = document.getElementsByClassName('molsp-panel1')[0];
        mp1.style.maxHeight = mp1.scrollHeight + 'px';
        const mp3 = document.getElementsByClassName('molsp-panel3')[0];
        mp3.style.maxHeight = mp3.scrollHeight + 'px';
        this.setNextLineStyle(this.state.styles.nextLineStyleName);
        // [FS] IRAD-1153 2021-02-25
        // Numbering level not showing in Preview text when modify style
        if (1 === this.props.mode &&
            this.state.styles.styleLevel &&
            this.state.styles.hasNumbering) {
            this.buildStyle();
        }
    }
    render() {
        return (React.createElement("div", { className: "molsp-customedit-div" },
            React.createElement("div", { className: "molsp-customedit-head" },
                React.createElement("span", null, this.state.mode === 0 ? 'Create Style' : 'Edit Style')),
            React.createElement("div", { className: "molsp-customedit-body" },
                React.createElement("div", { className: "molsp-sectiondiv" },
                    React.createElement("div", { style: 3 > this.props.mode ? { display: 'none' } : { display: 'block' } },
                        React.createElement("p", { className: "molsp-formp" }, "Styles:"),
                        React.createElement("select", { className: "molsp-stylenameinput molsp-fontstyle", defaultValue: 'DEFAULT', onChange: this.onSelectCustomStyle.bind(this), style: { height: '24px' } },
                            React.createElement("option", { disabled: true, value: "DEFAULT" },
                                ' ',
                                "-- select a style --",
                                ' '),
                            this.state.customStyles.map((style) => (React.createElement("option", { key: style.styleName, value: style.styleName }, style.styleName))))),
                    React.createElement("p", { className: "molsp-formp" },
                        "Style Name:",
                        ' ',
                        React.createElement("span", { id: "errormsg", style: { display: 'none', color: 'red' } }, isCustomStyleExists(this.state.styleName)
                            ? 'Style name already exists'
                            : '')),
                    React.createElement("span", null,
                        React.createElement("input", { autoFocus: true, className: "molsp-stylenameinput molsp-fontstyle", "data-cy": "cyStyleName", disabled: this.state.mode === 1 || this.state.mode === 3, id: "txtName", key: "name", onChange: this.onStyleClick.bind(this, 'name'), type: "text", value: this.state.styleName || '' })),
                    React.createElement("p", { className: "molsp-formp" }, "Description:"),
                    React.createElement("span", null,
                        React.createElement("input", { className: "molsp-stylenameinput molsp-fontstyle", key: "description", onChange: this.onStyleClick.bind(this, 'description'), type: "text", value: this.state.description || '' })),
                    React.createElement("p", { className: "molsp-formp" }, "Preview:"),
                    React.createElement("div", { className: "molsp-textareadiv", style: 3 === this.props.mode
                            ? { height: '164px' }
                            : { height: '215px' } },
                        React.createElement("div", { className: "molsp-sampletext" }, "Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph"),
                        React.createElement("div", { className: this.state.styles.super
                                ? 'molsp-hide-sampletext'
                                : 'molsp-visible-sampletext', id: "sampletextdiv", style: this.buildStyle() }, SAMPLE_TEXT),
                        React.createElement("sup", { className: this.state.styles.super
                                ? 'molsp-visible-sampletext'
                                : 'molsp-hide-sampletext', id: "mo-sup", style: this.buildStyle() }, SAMPLE_TEXT),
                        React.createElement("div", { className: "molsp-sampletext" }, "Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph Paragraph"))),
                React.createElement("div", { className: "molsp-sectiondiv molsp-editorsection", style: this.disableRename() },
                    React.createElement("p", { className: "molsp-formp" }, "Style Attributes:"),
                    React.createElement("div", { style: {
                            height: '329px',
                            overflow: 'hidden auto',
                            overflowX: 'hidden',
                            border: '1px solid',
                        } },
                        React.createElement("button", { className: "molsp-licit-accordion molsp-accactive", id: "accordion1" },
                            React.createElement("div", { className: "molsp-indentdiv" },
                                React.createElement("span", { className: "molsp-iconspan czi-icon text_format", style: { marginTop: '1px' } }, "text_format"),
                                React.createElement("span", { style: {
                                        marginLeft: '-10px',
                                        marginTop: '2px',
                                        color: '#444',
                                    } }, "Font"))),
                        React.createElement("div", { className: "molsp-panel", style: { marginBottom: '5px' } },
                            React.createElement("div", { className: "molsp-sectiondiv" },
                                React.createElement("select", { className: "molsp-fonttype molsp-fontstyle", "data-cy": "cyStyleFont", onChange: this.onFontNameChange.bind(this), value: this.state.styles.fontName || 'Tahoma' }, FONT_TYPE_NAMES.map((value) => (React.createElement("option", { key: value, value: value }, value)))),
                                React.createElement("select", { className: "molsp-fontsize molsp-fontstyle", "data-cy": "cyStyleFontSize", onChange: this.onFontSizeChange.bind(this), value: this.state.styles.fontSize || 12 }, FONT_PT_SIZES.map((value) => (React.createElement("option", { key: value, value: value }, value))))),
                            React.createElement("div", { className: "molsp-font-buttons" },
                                React.createElement("span", { "aria-label": " Bold", className: "czi-tooltip-surface molsp-markbutton-container", "data-tooltip": " Bold", id: "86ba3aa0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip", style: { marginLeft: '5px', marginRight: '5px' } },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.strong
                                            ? 'czi-custom-button use-icon active molsp-markbuttons'
                                            : 'czi-custom-button use-icon molsp-markbuttons molsp-formatbuttons', onClick: this.onStyleClick.bind(this, 'strong') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_bold editor-markbuttons", "data-cy": "cyStyleBold" }, "format_bold"))),
                                React.createElement("span", { "aria-label": " Italic", className: "czi-tooltip-surface molsp-fontstyle molsp-markbutton-container", "data-tooltip": " Italic", id: "86ba61b0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.em
                                            ? 'czi-custom-button use-icon active molsp-markbuttons'
                                            : 'czi-custom-button use-icon molsp-markbuttons molsp-formatbuttons', onClick: this.onStyleClick.bind(this, 'em') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_italic editor-markbuttons" }, "format_italic"),
                                        React.createElement("span", null, " "))),
                                React.createElement("span", { "aria-label": " Underline", className: "czi-tooltip-surface molsp-fontstyle molsp-markbutton-container", "data-tooltip": " Underline", id: "86ba88c0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.underline
                                            ? 'czi-custom-button use-icon active molsp-markbuttons'
                                            : 'czi-custom-button use-icon molsp-markbuttons molsp-formatbuttons', onClick: this.onStyleClick.bind(this, 'underline') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon  format_underline editor-markbuttons" }, "format_underline"),
                                        React.createElement("span", null, " "))),
                                React.createElement("span", { "aria-label": " Text color", className: "czi-tooltip-surface molsp-fontstyle molsp-markbutton-container", "data-tooltip": " Text color", id: "86bad6e1-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: "czi-custom-button use-icon molsp-markbuttons", onClick: this.showColorDialog.bind(this, true) },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_color_text editor-markbuttons", style: {
                                                color: this.state.styles.color !== 'rgba(0,0,0,0)'
                                                    ? this.state.styles.color
                                                    : '#666',
                                            } }, "format_color_text"),
                                        React.createElement("span", null, " "))),
                                React.createElement("span", { "aria-label": " Highlight color", className: "czi-tooltip-surface molsp-fontstyle molsp-markbutton-container", "data-tooltip": " Highlight color", id: "86bafdf0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: "czi-custom-button use-icon molsp-markbuttons", onClick: this.showColorDialog.bind(this, false) },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon border_color editor-markbuttons", style: {
                                                color: this.state.styles.textHighlight !== 'rgba(0,0,0,0)'
                                                    ? this.state.styles.textHighlight
                                                    : '#666',
                                            } }, "border_color"),
                                        React.createElement("span", null, " ")))),
                            React.createElement("div", { className: "molsp-formp molsp-hierarchydiv" },
                                React.createElement("span", { style: { float: 'left' } },
                                    React.createElement("label", null,
                                        React.createElement("input", { checked: this.state.styles.boldPartial, onChange: this.handleBoldPartial.bind(this), type: "checkbox" }),
                                        React.createElement("span", { style: {
                                                marginLeft: '2px',
                                                position: 'relative',
                                                top: '-2px',
                                            } }, "Bold the"))),
                                React.createElement("span", null,
                                    React.createElement("input", { checked: this.state.styles.boldSentence, disabled: !this.state.styles.boldPartial, name: "boldscentence", onChange: this.onScentenceRadioChanged.bind(this), style: { marginLeft: '21px' }, type: "radio", value: "0" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                        } }, "First Sentence"),
                                    React.createElement("input", { checked: !this.state.styles.boldSentence, disabled: !this.state.styles.boldPartial, name: "boldscentence", onChange: this.onScentenceRadioChanged.bind(this), style: { marginLeft: '21px' }, type: "radio", value: "1" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                        } }, "First Word"))),
                            React.createElement("div", { style: {
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                    gap: '9px',
                                    padding: '8px 0',
                                } }, [
                                {
                                    label: 'None',
                                    value: 'none',
                                    handler: this.handleNone.bind(this),
                                    cy: 'cyStyleNone',
                                },
                                {
                                    label: 'TOC',
                                    value: 'toc',
                                    handler: this.handleTOC.bind(this),
                                    cy: 'cyStyleTOC',
                                },
                                {
                                    label: 'Table',
                                    value: 'tot',
                                    handler: this.handleTOT.bind(this),
                                    cy: 'cyStyleTOT',
                                },
                                {
                                    label: 'Figure',
                                    value: 'tof',
                                    handler: this.handleTOF.bind(this),
                                    cy: 'cyStyleTOF',
                                },
                            ].map((item) => (React.createElement("label", { key: item.value, style: {
                                    fontSize: '12px',
                                    color: '#464343',
                                    display: 'flex',
                                    alignItems: 'center',
                                    cursor: 'pointer',
                                } },
                                React.createElement("input", { checked: this.state.styles.selectedStyleMode === item.value, "data-cy": item.cy, name: "styleOption", onChange: item.handler, style: { marginRight: '4px' }, type: "radio" }),
                                React.createElement("span", { style: {
                                        position: 'relative',
                                        top: '-1px',
                                    } }, item.label)))))),
                        React.createElement("button", { className: "molsp-licit-accordion molsp-accactive" },
                            React.createElement("div", { className: "molsp-indentdiv" },
                                React.createElement("span", { className: "molsp-iconspan czi-icon format_textdirection_l_to_r", style: { marginTop: '1px' } }, "format_textdirection_l_to_r"),
                                React.createElement("span", { style: {
                                        marginLeft: '-10px',
                                        marginTop: '2px',
                                        color: '#444',
                                    } }, "Paragraph"))),
                        React.createElement("div", { className: "molsp-panel1" },
                            React.createElement("p", { className: "molsp-formp" }, "Alignment:"),
                            React.createElement("div", { className: "molsp-czi-custom-buttons" },
                                React.createElement("span", { "aria-label": " Align Left", className: "czi-tooltip-surface", "data-tooltip": " Align Left", id: "86ba3aa0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.align === 'left'
                                            ? 'czi-custom-button use-icon molsp-activealignbuttons'
                                            : 'czi-custom-button molsp-alignbuttons', onClick: this.onAlignButtonClick.bind(this, 'left') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_align_left" }, "format_align_left"))),
                                React.createElement("span", { "aria-label": " Align Center", className: "czi-tooltip-surface molsp-alignbuttons", "data-tooltip": " Align Center", id: "86ba61b0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.align === 'center'
                                            ? 'czi-custom-button use-icon molsp-activealignbuttons'
                                            : 'czi-custom-button  molsp-alignbuttons', onClick: this.onAlignButtonClick.bind(this, 'center') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_align_center" }, "format_align_center"))),
                                React.createElement("span", { "aria-label": " Align Right", className: "czi-tooltip-surface molsp-alignbuttons", "data-tooltip": " Align Right", id: "86ba88c0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.align === 'right'
                                            ? 'czi-custom-button use-icon molsp-activealignbuttons'
                                            : 'czi-custom-button  molsp-alignbuttons', onClick: this.onAlignButtonClick.bind(this, 'right') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_align_right" }, "format_align_right"))),
                                React.createElement("span", { "aria-label": " Justify", className: "czi-tooltip-surface molsp-alignbuttons", "data-tooltip": " Justify", id: "86baafd0-ff11-11ea-930a-95c69ca4f97f", role: "tooltip" },
                                    React.createElement("button", { "aria-disabled": "false", "aria-pressed": "false", className: this.state.styles.align === 'justify'
                                            ? 'czi-custom-button use-icon molsp-activealignbuttons'
                                            : 'czi-custom-button  molsp-alignbuttons', onClick: this.onAlignButtonClick.bind(this, 'justify') },
                                        React.createElement("span", { className: "molsp-iconspan czi-icon format_align_justify" }, "format_align_justify")))),
                            React.createElement("p", { className: "molsp-formp" }, "Line Spacing:"),
                            React.createElement("select", { className: "molsp-linespacing molsp-fontstyle", onChange: this.onLineSpaceChange.bind(this), value: this.state.styles.lineHeight || '' }, LINE_SPACE.map((value) => (React.createElement("option", { key: value, value: value }, value)))),
                            React.createElement("p", { className: "molsp-formp" }, "Paragraph Spacing:"),
                            React.createElement("div", { className: "molsp-spacingdiv" },
                                React.createElement("span", { style: { fontSize: '12px' } }, "Before: "),
                                React.createElement("span", null,
                                    React.createElement("input", { className: "molsp-spacinginput molsp-fontstyle", "data-cy": "cyStyleBeforeSpace", key: "before", onChange: this.onStyleClick.bind(this, 'before'), type: "text", value: this.state.styles.paragraphSpacingBefore || '' })),
                                React.createElement("span", { style: { fontSize: '12px', marginLeft: '3px' } },
                                    ' ',
                                    "pts"),
                                React.createElement("span", { style: { fontSize: '12px', marginLeft: '23px' } },
                                    "After:",
                                    ' '),
                                React.createElement("span", null,
                                    React.createElement("input", { className: "molsp-spacinginput molsp-fontstyle", "data-cy": "cyStyleAfterSpace", key: "after", onChange: this.onStyleClick.bind(this, 'after'), type: "text", value: this.state.styles.paragraphSpacingAfter || '' })),
                                React.createElement("span", { style: { fontSize: '12px', marginLeft: '3px' } }, "pts"))),
                        React.createElement("button", { className: "molsp-licit-accordion molsp-accactive", disabled: this.state.styleName === RESERVED_STYLE_NONE },
                            React.createElement("div", { className: "molsp-indentdiv" },
                                React.createElement("span", { className: "molsp-iconspan czi-icon account_tree", style: {
                                        color: this.state.styleName === RESERVED_STYLE_NONE
                                            ? 'rgb(167, 158, 158)'
                                            : 'black',
                                    } }, "account_tree"),
                                React.createElement("span", { style: {
                                        marginLeft: '-7px',
                                        marginTop: '2px',
                                        color: this.state.styleName === RESERVED_STYLE_NONE
                                            ? 'rgb(167, 158, 158)'
                                            : '#444',
                                    } }, "Hierarchy"))),
                        React.createElement("div", { className: "molsp-panel2 molsp-formp", style: { maxHeight: '100%' } },
                            this.state.styles.hasNumbering || this.state.styles.isList ? (React.createElement("div", { className: "molsp-hierarchydiv", style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    marginLeft: '-1px',
                                } },
                                React.createElement("div", { className: "molsp-hierarchydiv" },
                                    React.createElement("label", null,
                                        React.createElement("input", { checked: !this.state.styles.isList, disabled: this.state.styleName === RESERVED_STYLE_NONE, onChange: (e) => this.handleList(e), type: "radio", value: "userDefined" }),
                                        "User-defined Numbering/Bullets"),
                                    React.createElement("br", null),
                                    React.createElement("label", null,
                                        React.createElement("input", { checked: this.state.styles.isList, disabled: this.state.disableControl ||
                                                this.state.styleName === RESERVED_STYLE_NONE ||
                                                this.state.styles.tot ||
                                                this.state.styles.tof, onChange: this.handleList.bind(this), type: "radio", value: "listStyle" }),
                                        "List-style (Auto Numbering)")))) : (React.createElement("div", { className: "molsp-hierarchydiv", style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    marginLeft: '-1px',
                                } },
                                React.createElement("div", { className: "molsp-hierarchydiv" },
                                    React.createElement("label", null,
                                        React.createElement("input", { checked: this.state.selectedStyle === 'userDefined', disabled: this.state.styleName === RESERVED_STYLE_NONE, onChange: (e) => this.handleList(e), type: "radio", value: "userDefined" }),
                                        React.createElement("span", { style: {
                                                marginLeft: '2px',
                                                position: 'relative',
                                                top: '-2px',
                                            } }, "User-defined Numbering/Bullets")),
                                    React.createElement("br", null),
                                    React.createElement("label", null,
                                        React.createElement("input", { checked: this.state.selectedStyle === 'listStyle', disabled: this.state.styleName === RESERVED_STYLE_NONE, onChange: this.handleList.bind(this), type: "radio", value: "listStyle" }),
                                        React.createElement("span", { style: {
                                                marginLeft: '2px',
                                                position: 'relative',
                                                top: '-2px',
                                            } }, "List-style (Auto Numbering)"))))),
                            React.createElement("div", { className: "molsp-hierarchydiv", style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    paddingLeft: '22px',
                                } },
                                React.createElement("p", { className: "molsp-formp", style: { margin: '0' } }, "Level:"),
                                React.createElement("select", { className: "molsp-leveltype molsp-fontstyle", "data-cy": "cyStyleLevel", disabled: this.state.styles.isList === true ||
                                        this.state.styleName === RESERVED_STYLE_NONE ||
                                        this.state.styles.tot ||
                                        this.state.styles.tof, id: "levelValue", onChange: this.onLevelChange.bind(this), value: this.state.styles.styleLevel || '' }, LEVEL_VALUES.map((value) => (React.createElement("option", { key: value, value: value }, value))))),
                            React.createElement("div", { className: "molsp-hierarchydiv", style: { display: 'flex' } },
                                React.createElement("fieldset", { className: "formatting-fieldset" },
                                    React.createElement("legend", { className: "formatting-legend" }, "Formatting"),
                                    React.createElement("div", null,
                                        React.createElement("label", null,
                                            React.createElement("input", { checked: !this.state.styles.hasNumbering &&
                                                    !this.state.styles.hasBullet, className: "molsp-chknumbering", disabled: this.state.styles.isList === true ||
                                                    this.state.styleName === RESERVED_STYLE_NONE ||
                                                    this.state.styles.tot ||
                                                    this.state.styles.tof, name: "formatting", onChange: () => {
                                                    this.setState((prevState) => ({
                                                        styles: {
                                                            ...prevState.styles,
                                                            hasNumbering: false,
                                                            boldNumbering: false,
                                                            hasBullet: false,
                                                            hideNumbering: false,
                                                        },
                                                    }));
                                                }, type: "radio", value: "none" }),
                                            React.createElement("span", { style: {
                                                    marginLeft: '2px',
                                                    position: 'relative',
                                                    top: '-2px',
                                                } }, "None")),
                                        React.createElement("br", null),
                                        React.createElement("label", null,
                                            React.createElement("input", { checked: this.state.styles.hasNumbering, className: "molsp-chknumbering", disabled: this.state.styles.styleLevel === undefined ||
                                                    this.state.isRadioDisabled ||
                                                    this.state.styles.styleLevel === 0 ||
                                                    (this.state.styles.styleLevel === 1 &&
                                                        this.state.styles.isList === true) ||
                                                    this.state.styleName === RESERVED_STYLE_NONE, name: "formatting", onChange: this.handleNumbering.bind(this), type: "radio", value: "numbering" }),
                                            React.createElement("span", { style: {
                                                    marginLeft: '2px',
                                                    position: 'relative',
                                                    top: '-2px',
                                                } }, "Numbering (1.1)")),
                                        React.createElement("div", { style: { marginLeft: '20px', marginTop: '5px' } },
                                            React.createElement("div", { style: {
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    marginBottom: '5px',
                                                } },
                                                React.createElement("input", { checked: this.state.styles.hideNumbering, className: "molsp-chkboldnumbering", disabled: this.checkCondition(this.state.styles.hasNumbering) ||
                                                        this.state.styleName === RESERVED_STYLE_NONE ||
                                                        this.state.styles.tot ||
                                                        this.state.styles.tof, onChange: this.handleHideNumbering.bind(this), type: "checkbox", value: "HideNumbering" }),
                                                React.createElement("span", { style: { marginLeft: '5px' } }, "Hide Numbering")),
                                            React.createElement("div", { style: {
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    marginBottom: '5px',
                                                } },
                                                React.createElement("input", { checked: this.state.styles.boldNumbering, className: "molsp-chkboldnumbering", disabled: this.checkCondition(this.state.styles.hasNumbering) || this.state.styleName === RESERVED_STYLE_NONE, onChange: this.handleBoldNumbering.bind(this), type: "checkbox" }),
                                                React.createElement("span", { style: { marginLeft: '5px' } }, "Bold")),
                                            React.createElement("div", { style: {
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    marginTop: '5px',
                                                    marginLeft: '-6px',
                                                } },
                                                React.createElement("span", { style: { marginRight: '5px' } }, "Prefix:"),
                                                React.createElement("input", { disabled: this.checkCondition(this.state.styles.hasNumbering) || this.state.styleName === RESERVED_STYLE_NONE, onChange: (e) => this.handlePrefix(e), style: { width: '62px' }, type: "text", value: this.state.styles.prefixValue }))),
                                        React.createElement("label", null,
                                            React.createElement("input", { checked: this.state.styles?.hasBullet, className: "molsp-chknumbering", disabled: this.state.isRadioDisabled ||
                                                    this.state.styles.styleLevel === 0 ||
                                                    this.state.styles.styleLevel === undefined ||
                                                    (this.state.styles.styleLevel === 1 &&
                                                        this.state.styles.isList === true) ||
                                                    this.state.styleName === RESERVED_STYLE_NONE ||
                                                    this.state.styles.tot ||
                                                    this.state.styles.tof, name: "bullet", onChange: this.handleBulletPoints.bind(this), type: "radio" }),
                                            React.createElement("span", { style: {
                                                    marginLeft: '2px',
                                                    position: 'relative',
                                                    top: '-2px',
                                                } },
                                                "Bullet",
                                                ' '),
                                            React.createElement("span", null,
                                                React.createElement("select", { className: "molsp-fontstyle", disabled: this.checkCondition(this.state.styles?.hasBullet) || this.state.styleName === RESERVED_STYLE_NONE, id: "bulletValue", onChange: this.onBulletLevelChange.bind(this), style: { textAlign: 'center' }, value: this.state.styles.bulletLevel || '' }, BULLET_POINTS.map((value) => (React.createElement("option", { key: value.key, value: value.key }, value.symbol))))))))),
                            React.createElement("p", { className: "molsp-formp" }, "Indenting:"),
                            React.createElement("div", { className: "molsp-hierarchydiv" },
                                React.createElement("div", { className: "molsp-indentdiv" },
                                    React.createElement("input", { checked: this.state.styles.isLevelbased, disabled: this.state.styles.isList === true ||
                                            this.state.styleName === RESERVED_STYLE_NONE, name: "indenting", onChange: this.onIndentRadioChanged.bind(this), type: "radio", value: "0" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                        } }, "Based On Level")),
                                React.createElement("div", { className: "molsp-indentdiv" },
                                    React.createElement("input", { checked: !this.state.styles.isLevelbased, disabled: this.state.styles.isList === true ||
                                            this.state.styleName === RESERVED_STYLE_NONE, name: "indenting", onChange: this.onIndentRadioChanged.bind(this), type: "radio", value: "1" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                        } }, "Specified"),
                                    React.createElement("span", null,
                                        React.createElement("select", { className: "molsp-leveltype molsp-specifiedindent molsp-fontstyle", "data-cy": "cyStyleIndent", disabled: this.state.styles.isList === true ||
                                                this.state.styleName === RESERVED_STYLE_NONE, onChange: this.onIndentChange.bind(this), style: { width: '99px !important' }, value: this.state.styles.indent || '' }, LEVEL_VALUES.map((value) => (React.createElement("option", { key: value, value: value }, value)))))),
                                React.createElement("div", { style: { display: 'flex', alignItems: 'center' } },
                                    React.createElement("input", { checked: this.state.styles.isHangingIndent, id: 'hanging-indent-checkbox', onChange: this.onHangingIndentChange.bind(this), type: "checkbox" }),
                                    React.createElement("label", { htmlFor: 'hanging-indent-checkbox', style: { marginLeft: '4px' } }, "Hanging Indent")),
                                React.createElement("div", { style: { display: 'flex', alignItems: 'center', marginLeft: '34px' } },
                                    React.createElement("label", { htmlFor: 'indent-position-input', style: { marginRight: '8px' } }, "Indent position: "),
                                    React.createElement("input", { disabled: !this.state.styles.isHangingIndent, id: 'indent-position-input', onChange: this.onIndentPositionChange.bind(this), style: { width: '34px', marginRight: '6px' }, type: "text", value: this.state.styles.indentPosition ?? '' }),
                                    React.createElement("span", null, "inches")))),
                        React.createElement("button", { className: "molsp-licit-accordion molsp-accactive" },
                            React.createElement("div", { className: "molsp-indentdiv" },
                                React.createElement("span", { style: {
                                        marginLeft: '0',
                                        marginTop: '2px',
                                        color: '#444',
                                    } }, "Style Settings"))),
                        React.createElement("div", { className: "molsp-panel3 molsp-formp" },
                            React.createElement("p", { className: "molsp-formp" }, "Select style for next line:"),
                            React.createElement("div", { className: "molsp-hierarchydiv" },
                                React.createElement("div", { className: "molsp-settingsdiv" },
                                    React.createElement("input", { checked: !(this.state.styles.tot || this.state.styles.tof) &&
                                            this.state.styles.nextLineStyleName ===
                                                this.state.styleName &&
                                            !this.state.otherStyleSelected, name: "nextlinestyle", onChange: this.onNextLineStyleSelected.bind(this, 1), style: {
                                            marginLeft: '0.5px',
                                        }, type: "radio", value: "1" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                        } }, "Continue this style")),
                                React.createElement("div", { className: "molsp-settingsdiv", style: {
                                        marginLeft: '15px',
                                    } },
                                    React.createElement("input", { checked: this.state.styles.tot ||
                                            this.state.styles.tof ||
                                            this.state.styles.nextLineStyleName ===
                                                RESERVED_STYLE_NONE, name: "nextlinestyle", onChange: this.onNextLineStyleSelected.bind(this, 0), type: "radio", value: "2" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                        } }, "None")),
                                React.createElement("div", { className: "molsp-indentdiv" },
                                    React.createElement("input", { checked: this.state.otherStyleSelected, disabled: this.state.styles.tot || this.state.styles.tof, name: "nextlinestyle", onChange: this.onNextLineStyleSelected.bind(this, 2), type: "radio", value: "0" }),
                                    React.createElement("span", { style: {
                                            marginLeft: '4px',
                                            marginTop: '3px',
                                            marginBottom: '0',
                                            width: '62px',
                                        } }, "Select style"),
                                    React.createElement("span", { id: "nextStyle", style: { display: 'none' } },
                                        React.createElement("select", { className: "molsp-fontstyle molsp-stylenameinput", id: "nextStyleValue", onChange: this.onOtherStyleSelectionChanged.bind(this), style: {
                                                height: '20px',
                                                marginLeft: '7px',
                                                width: '97px',
                                            }, value: this.state.styles.nextLineStyleName }, customStyles.map((style) => (React.createElement("option", { key: style.styleName }, style.styleName))))))))))),
            React.createElement("div", { className: "molsp-btns" },
                React.createElement("button", { className: "molsp-buttonstyle", "data-cy": "cyStyleCancel", onClick: this._cancel }, this.state.mode === 3 ? 'Close' : 'Cancel'),
                React.createElement("button", { className: "molsp-btnsave molsp-buttonstyle", "data-cy": "cyStyleSave", onClick: this._save.bind(this), onKeyDown: this.handleKeyDown }, "Save"))));
    }
    _cancel = () => {
        // FIX: edited custom styles not applied to the document
        if (3 === this.state.mode) {
            // Update the state with the new state object
            this.setState((prev) => ({
                ...prev,
                customStyles: customStyles ?? [],
            }));
            this.props.close(editedStyles);
        }
        else {
            this.props.close();
        }
    };
    _save = () => {
        // eslint-disable-next-line
        const { otherStyleSelected, ...newState } = this.state;
        // Update the state with the new state object
        this.setState(newState);
        // FIX: able to save a custom style name with already exist style name
        if (0 === this.state.mode && isCustomStyleExists(this.state.styleName)) {
            const errMsg = document.getElementById('errormsg');
            if (errMsg?.style) {
                errMsg.style.display = '';
            }
            // save the custom styles from Edit all option.
        }
        else if (3 === this.state.mode) {
            this.modifyCustomStyle(this.state);
            editedStyles.push(this.state.styleName);
        }
        else if ('' !== this.state.styleName) {
            // eslint-disable-next-line
            const { customStyles, ...newState } = this.state;
            // Update the state with the new state object
            this.setState(newState);
            this.props.close(newState);
        }
    };
    handleKeyDown = () => {
        const txtName = document.getElementById('txtName');
        if (txtName) {
            txtName.focus();
        }
    };
    // [FS] IRAD-1176 2021-02-08
    // save the custom styles from Edit all option.
    modifyCustomStyle(val) {
        delete val.editorView;
        const styleObj = {
            styleName: val.styleName,
            mode: val.mode,
            description: val.description,
            styles: val.styles,
        };
        saveStyle(styleObj).then((result) => {
            if (!Array.isArray(result)) {
                result = addStyleToList(result);
            }
            customStyles = result;
            setStyles(result);
        });
    }
    // To fetch the custom styles from server and set to the state.
    getCustomStyles() {
        getStylesAsync().then((result) => {
            customStyles = result;
            // [FS] IRAD-1222 2021-03-01
            // Issue fix: In edit all, the style list not showing the first time.
            this.setState(() => ({
                customStyles: result,
            }));
        });
    }
    // [FS] IRAD-1231 2021-03-03
    // Issue fix: Selected style for next line not retaining when modify.
    setNextLineStyle(nextLineStyleName) {
        // [FS] IRAD-1241 2021-03-05
        // The selcted Style in the Next line setting not retaing in Edit All and modify
        let display = '';
        if (0 < this.props.mode &&
            nextLineStyleName &&
            RESERVED_STYLE_NONE !== nextLineStyleName &&
            nextLineStyleName !== this.state.styleName) {
            this.setState({
                otherStyleSelected: true,
            });
            display = 'block';
            const selectedStyle = document.getElementById('nextStyleValue');
            if (selectedStyle instanceof window.HTMLSelectElement) {
                selectedStyle.value = nextLineStyleName;
            }
        }
        else {
            this.setState({
                otherStyleSelected: false,
            });
            display = 'none';
        }
        const hiddenDiv = document.getElementById('nextStyle');
        if (hiddenDiv?.style) {
            hiddenDiv.style.display = display;
            hiddenDiv.style.marginBottom = '-7px';
        }
    }
    // Disable the style attribute div on Rename
    disableRename() {
        const style = {};
        if (2 === this.state.mode) {
            style.opacity = 0.4;
            style.pointerEvents = 'none';
        }
        return style;
    }
    checkCondition(mainCondition) {
        return (!mainCondition ||
            this.state.styles.styleLevel === 0 ||
            this.state.styles.styleLevel === undefined ||
            (this.state.styles.styleLevel === 1 && this.state.styles.isList === true));
    }
}
