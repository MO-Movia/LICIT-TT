import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export declare class CustomMenuButton extends React.PureComponent<{
    className?: string;
    commandGroups: Array<{
        [string: string]: UICommand;
    }>;
    staticCommand: Array<{
        [string: string]: UICommand;
    }>;
    disabled?: boolean;
    dispatch: (tr: Transform) => void;
    editorState: EditorState;
    editorView?: EditorView | null;
    icon?: string | React.ReactElement | null;
    label?: string | React.ReactElement | null;
    title?: string;
}, {
    expanded: boolean;
}> {
    state: {
        expanded: boolean;
    };
    static contextType: React.Context<string>;
    _menu: any;
    _id: string;
    render(): React.ReactElement;
    componentWillUnmount(): void;
    _onClick: () => void;
    _hideMenu: () => void;
    _showMenu: () => void;
    _onCommand: () => void;
    _onClose: () => void;
}
