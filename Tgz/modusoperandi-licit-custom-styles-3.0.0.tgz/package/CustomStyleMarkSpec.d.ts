import { Node } from 'prosemirror-model';
import type { KeyValuePair } from './Constants';
type getAttrsFn = (p: Node | string) => KeyValuePair;
declare function getAttrs(base: getAttrsFn | undefined, dom: HTMLElement): KeyValuePair;
declare function toDOM(base: any, node: Node): any;
export declare const toMarkDOM: typeof toDOM;
export declare const getMarkAttrs: typeof getAttrs;
export {};
