import { Schema } from 'prosemirror-model';
export declare function effectiveSchema(schema: Schema): Schema<any, any>;
export declare function createMarkAttributes(mark: any, existingAttr: any): void;
export declare const applyEffectiveSchema: typeof effectiveSchema;
