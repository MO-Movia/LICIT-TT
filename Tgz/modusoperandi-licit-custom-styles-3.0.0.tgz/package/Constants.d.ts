import { Node } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare const MARK_UNDERLINE = "underline";
export declare const MARK_TEXT_HIGHLIGHT = "mark-text-highlight";
export declare const MARKFROM = "markFrom";
export declare const PARAGRAPH = "paragraph";
export declare const STYLEKEY = "styleName";
export declare const ATTR_OVERRIDDEN = "overridden";
export type KeyValuePair = {
    [key: string]: any;
};
export declare const DEFAULT_NORMAL_STYLE: {
    styleName: string;
    mode: number;
    description: string;
    styles: {
        align: string;
        boldNumbering: boolean;
        boldSentence: boolean;
        fontName: string;
        fontSize: string;
        nextLineStyleName: string;
        paragraphSpacingAfter: string;
        toc: boolean;
        tot: boolean;
        tof: boolean;
        selectedStyleMode: string;
    };
};
export declare function getNode(from: number, to: number, tr: Transform): Node;
