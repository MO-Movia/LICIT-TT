export type HTMLStyles = {
    align?: string;
    boldNumbering?: boolean;
    boldPartial?: boolean;
    boldSentence?: boolean;
    fontName?: string;
    fontSize?: string;
    strong?: boolean;
    em?: boolean;
    underline?: boolean;
    color?: string;
    textHighlight?: string;
    hasNumbering?: boolean;
    hasBullet?: boolean;
    paragraphSpacingAfter?: string;
    paragraphSpacingBefore?: string;
    styleLevel?: number;
    bulletLevel?: string | boolean;
    lineHeight?: string;
    isLevelbased?: boolean;
    indent?: string;
    nextLineStyleName?: string;
    toc?: boolean;
    tot?: boolean;
    tof?: boolean;
    isHidden?: boolean;
    strike?: string;
    isList?: boolean;
    prefixValue?: string;
    selectedStyleMode?: string;
    hideNumbering?: boolean;
    resetValue?: boolean;
    indentPosition?: string;
    isHangingIndentapplied?: boolean;
};
export type Style = {
    /**
     * Name of the style. Case insensitive value must be unique.
     */
    styleName: string;
    mode?: number;
    description?: string;
    styles?: HTMLStyles;
    docType?: string;
};
/**
 * Styles to display in Preview text
 **/
export type CSSStyle = {
    float?: string;
    fontWeight?: string;
    fontStyle?: string;
    color?: string;
    backgroundColor?: string;
    fontSize?: string;
    fontName?: string;
    textDecorationLine?: string;
    verticalAlign?: string;
    textDecoration?: string;
    textAlign?: string;
    lineHeight?: string;
    isList?: boolean;
    prefixValue?: string;
    hideNumbering?: boolean;
    resetValue?: boolean;
};
export type StyleRuntime = {
    canEditStyle?: boolean;
    /**
     * Gets array of styles asynchronously from the service
     */
    getStylesAsync: () => Promise<Style[]>;
    saveStyle(style: Style): Promise<Style>;
    /**
     * Renames an existing style from the service.
     * @param oldStyleName
     * @param newStyleName
     */
    renameStyle: (oldStyleName: string, newStyleName: string) => Promise<Style[]>;
    /**
     * Remove an existing style from the service.
     * @param name
     */
    removeStyle: (name: string) => Promise<Style[]>;
};
