import { Schema, Node } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare function removeTextAlignAndLineSpacing(tr: Transform, schema: Schema): Transform;
export declare function clearCustomStyleAttribute(node: Node): void;
