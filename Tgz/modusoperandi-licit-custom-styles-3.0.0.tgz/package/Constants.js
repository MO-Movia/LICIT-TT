export const MARK_UNDERLINE = 'underline';
export const MARK_TEXT_HIGHLIGHT = 'mark-text-highlight';
export const MARKFROM = 'markFrom';
export const PARAGRAPH = 'paragraph';
export const STYLEKEY = 'styleName';
export const ATTR_OVERRIDDEN = 'overridden';
export const DEFAULT_NORMAL_STYLE = {
    styleName: 'Normal',
    mode: 0,
    description: 'Normal',
    styles: {
        align: 'left',
        boldNumbering: true,
        boldSentence: true,
        fontName: 'Tahoma',
        fontSize: '12',
        nextLineStyleName: 'Normal',
        paragraphSpacingAfter: '3',
        toc: false,
        tot: false,
        tof: false,
        selectedStyleMode: 'none',
    },
};
//to get the selected node
export function getNode(from, to, tr) {
    let selectedNode = null;
    tr.doc.nodesBetween(from, to, (node) => {
        if (node.type.name === 'paragraph' || node.type.name === 'enhanced_table_figure_notes') {
            if (null === selectedNode) {
                selectedNode = node;
            }
        }
    });
    return selectedNode;
}
