import { Plugin, EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { Schema } from 'prosemirror-model';
import { CustomstyleDropDownCommand } from './ui/CustomstyleDropDownCommand';
import type { StyleRuntime } from './StyleRuntime';
export declare class CustomstylePlugin extends Plugin {
    constructor(runtime: StyleRuntime, hideNumbering?: boolean);
    initButtonCommands(): {
        '[H1] Header 1': typeof CustomstyleDropDownCommand;
    };
    static setLevelCounter(styleCounter: any): void;
    getEffectiveSchema(schema: Schema): Schema<keyof import("orderedmap").default<import("prosemirror-model").NodeSpec>, keyof import("orderedmap").default<import("prosemirror-model").MarkSpec>>;
}
export declare function onInitAppendTransaction(ref: any, tr: any, nextState: any): any;
export declare function onUpdateAppendTransaction(ref: any, tr: any, nextState: any, prevState: any, csview: any, transactions: any, slice1: any): any;
export declare function applyStyleForPreviousEmptyParagraph(nextState: EditorState, tr: Transform): Transform;
export declare function remapCounterFlags(tr: any): void;
export declare function applyStyles(state: EditorState, tr?: Transform): Transform;
export declare function nodeAssignment(state: any): any[];
export declare function applyStyleForEmptyParagraph(nextState: any, tr: any): any;
export declare function applyStyleForNextParagraph(prevState: any, nextState: any, tr: any, view: any): any;
export declare function resetTheDefaultStyleNameToNone(styleName: any): any;
export declare function setNodeAttrs(nextLineStyleName: any, newattrs: any): any;
export declare function isDocChanged(transactions: any): any;
export declare function applyNormalIfNoStyle(nextState: any, tr: any, node: any, opt?: any): any;
export declare function applyHangingIndentTransform(tr: any, state: any, node: any, pos: any, isPaste: any): any;
