export declare const BLOCKQUOTE = "blockquote";
export declare const HEADING = "heading";
export declare const LIST_ITEM = "list_item";
export declare const PARAGRAPH = "paragraph";
