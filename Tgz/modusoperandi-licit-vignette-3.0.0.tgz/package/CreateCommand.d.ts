import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
type ExecuteCall = (state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView) => boolean;
export declare function createCommand(execute: ExecuteCall): UICommand;
export {};
