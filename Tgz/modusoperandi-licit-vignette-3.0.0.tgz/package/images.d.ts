declare const DarkThemeIcon = "assets/images/dark/Icon_Vignette.svg";
declare const LightThemeIcon = "assets/images/light/Icon_Vignette.svg";
export { DarkThemeIcon, LightThemeIcon };
