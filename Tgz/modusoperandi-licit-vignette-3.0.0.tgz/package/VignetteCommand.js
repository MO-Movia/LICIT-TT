import { Fragment } from 'prosemirror-model';
import { TextSelection } from 'prosemirror-state';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { DEF_BORDER_COLOR, PARAGRAPH, TABLE, TABLE_CELL } from './Constants';
export class VignetteCommand extends UICommand {
    executeCustomStyleForTable(_state, tr, _from, _to) {
        return tr;
    }
    isEnabled = (state, view) => {
        return this.__isEnabled(state, view);
    };
    execute = (state, dispatch, view) => {
        if (dispatch) {
            const { schema } = state;
            let { tr } = state;
            tr = this.insertTable(tr, schema, 1, 1);
            tr = this.insertParagraph(state, tr);
            dispatch(tr);
            view?.focus();
        }
        return true;
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    __isEnabled = (_state, _view) => {
        return true;
    };
    insertTable(tr, schema, rows, cols) {
        if (!tr.selection || !tr.doc) {
            return tr;
        }
        const { from, to } = tr.selection;
        if (from !== to) {
            return tr;
        }
        const { nodes } = schema;
        const cell = nodes[TABLE_CELL];
        const paragraph = nodes[PARAGRAPH];
        const row = nodes['tableRow'];
        const table = nodes[TABLE];
        if (!(cell && paragraph && row && table)) {
            return tr;
        }
        const rowNodes = [];
        for (let rr = 0; rr < rows; rr++) {
            const cellNodes = [];
            for (let cc = 0; cc < cols; cc++) {
                // [FS] IRAD-950 2020-05-25
                // Fix:Extra arrow key required for cell navigation using arrow right/Left
                const cellNode = cell.create({
                    borderColor: DEF_BORDER_COLOR,
                    backgroundColor: '#dce6f2',
                    vignette: true,
                }, Fragment.fromArray([paragraph.create()]));
                cellNodes.push(cellNode);
            }
            const rowNode = row.create({}, Fragment.from(cellNodes));
            rowNodes.push(rowNode);
        }
        const tableNode = table.create({ vignette: true }, Fragment.from(rowNodes));
        tr = tr.insert(from, Fragment.from(tableNode));
        const selection = TextSelection.create(tr.doc, from, from + 5);
        tr = tr.setSelection(selection);
        return tr;
    }
    // [FS] 2021-04-01
    // Add empty line after table drop
    // To make easier to enter a line after table
    insertParagraph(state, tr) {
        const paragraph = state.schema.nodes[PARAGRAPH];
        const textNode = state.schema.text(' ');
        const { from, to } = tr.selection;
        if (from !== to) {
            return tr;
        }
        const paragraphNode = paragraph.create({}, textNode, null);
        tr = tr.insert(from + tr.selection.$head.node(1).nodeSize - 2, Fragment.from(paragraphNode));
        return tr;
    }
    renderLabel() {
        return null;
    }
    isActive() {
        return true;
    }
    executeCustom(_state, tr) {
        return tr;
    }
}
