import { Plugin, PluginKey } from 'prosemirror-state';
import { TableBackgroundColorCommand } from './TableBackgroundColorCommand';
import { TableBorderColorCommand } from './TableBorderColorCommand';
import { createCommand } from './CreateCommand';
import { CellSelection, deleteTable } from 'prosemirror-tables';
import { TABLE } from './Constants';
const TABLE_BACKGROUND_COLOR = new TableBackgroundColorCommand();
const TABLE_BORDER_COLOR = new TableBorderColorCommand();
const TABLE_DELETE_TABLE = createCommand(deleteTable);
const VIGNETTE_COMMANDS_GROUP = [
    {
        'Fill Color...': TABLE_BACKGROUND_COLOR,
        'Border Color....': TABLE_BORDER_COLOR,
    },
    {
        'Delete Vignette': TABLE_DELETE_TABLE,
    },
];
export class VignetteView {
    constructor(editorView) {
        this.setCustomMenu(editorView);
        this.setCustomTableNodeViewUpdate(editorView);
    }
    setCustomMenu(editorView) {
        editorView['pluginViews'].forEach((pluginView) => {
            if (
            // 'TableCellTooltipView' has property _cellElement
            Object.hasOwn(pluginView, '_menu')) {
                pluginView['_menu'] = this.getMenu.bind(this);
            }
        });
    }
    setCustomTableNodeViewUpdate(editorView) {
        const tableNodeView = editorView['nodeViews']['table'];
        const tableNodeViewEx = this.tableNodeViewEx.bind(this, tableNodeView);
        editorView['nodeViews'][TABLE] = tableNodeViewEx;
        const index = editorView.state.plugins.findIndex((plugin) => {
            let found = false;
            if (plugin.spec.key) {
                found = plugin.spec.key['key'].includes('tableColumnResizing$');
            }
            return found;
        });
        if (-1 != index) {
            editorView.state.plugins[index].spec.props.nodeViews[TABLE] =
                tableNodeViewEx;
        }
    }
    tableNodeViewEx(tableNodeView, node, view) {
        const base = tableNodeView?.(node, view);
        if (base?.update && node.attrs.vignette) {
            base.update = this.updateEx.bind(base, base.update, this);
            this.updateBorder(base);
        }
        return base;
    }
    updateEx(update, self, node) {
        const result = update.call(this, node);
        if (result) {
            self.updateBorder(this);
        }
        return result;
    }
    updateBorder(tableView) {
        if (tableView.table) {
            tableView.table.style.border = 'none';
        }
    }
    static isVignette(state, actionNode) {
        let vignette = false;
        if (state.selection instanceof CellSelection) {
            if (state.selection?.$anchorCell?.node(-1)?.attrs.vignette) {
                vignette = true;
            }
        }
        if (actionNode?.attrs.vignette) {
            vignette = true;
        }
        if (state.selection.$anchor?.node(1)?.attrs.vignette) {
            vignette = true;
        }
        return vignette;
    }
    getMenu(state, actionNode, cmdGrps) {
        const vignette = VignetteView.isVignette(state, actionNode);
        cmdGrps.forEach((cmdGrp) => {
            Object.entries(cmdGrp).forEach((entry) => {
                entry[1].isEnabled = this.isEnabledEx.bind(entry[1], entry[1].isEnabled);
            });
        });
        return vignette ? VIGNETTE_COMMANDS_GROUP : cmdGrps;
    }
    isEnabledEx(isEnabled, state, view) {
        return VignetteView.isVignette(state, null)
            ? false
            : isEnabled.call(this, state, view);
    }
    destroy = () => {
        // do nothing.
    };
}
const SPEC = {
    key: new PluginKey('VignetteMenuPlugin'),
    view(editorView) {
        return new VignetteView(editorView);
    },
};
export class VignetteMenuPlugin extends Plugin {
    constructor() {
        super(SPEC);
    }
}
