import { Plugin } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { Schema } from 'prosemirror-model';
import { VignetteCommand } from './VignetteCommand';
export declare class VignettePlugin extends Plugin {
    _view: EditorView;
    constructor();
    getEffectiveSchema(schema: Schema): Schema;
    initButtonCommands(theme: string): {
        [x: string]: VignetteCommand;
    };
}
