import { NodeSpec } from 'prosemirror-model';
export declare const VignetteTableNodeSpec: (nodespec: NodeSpec) => NodeSpec;
export declare const VignetteTableCellNodeSpec: (nodespec: NodeSpec) => NodeSpec;
