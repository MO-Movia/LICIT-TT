import { VignettePlugin } from './VignettePlugin';
import { VignetteMenuPlugin } from './VignetteMenuPlugin';
export declare const VignettePlugins: (VignetteMenuPlugin | VignettePlugin)[];
