export declare const VIGNETTE = "vignette";
export declare const PARAGRAPH = "paragraph";
export declare const TABLE = "table";
export declare const TABLE_CELL = "tableCell";
export declare const DEF_BORDER_COLOR = "#36598d";
export declare const DEF_BORDER_RADIUS = "10px";
