import { TableColorCommand } from './ui/TableColorCommand';
export class TableBorderColorCommand extends TableColorCommand {
    getAttrName = () => {
        return 'borderColor';
    };
}
