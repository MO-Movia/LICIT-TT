import { TableColorCommand } from './ui/TableColorCommand';
export declare class TableBackgroundColorCommand extends TableColorCommand {
    getAttrName: () => string;
}
