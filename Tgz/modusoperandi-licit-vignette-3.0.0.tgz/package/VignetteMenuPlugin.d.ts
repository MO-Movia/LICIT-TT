import { EditorState, Plugin } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { Node } from 'prosemirror-model';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { TableView } from 'prosemirror-tables';
export declare class VignetteView {
    constructor(editorView: EditorView);
    setCustomMenu(editorView: EditorView): void;
    setCustomTableNodeViewUpdate(editorView: EditorView): void;
    tableNodeViewEx(tableNodeView: (node: Node, view: EditorView) => TableView, node: Node, view: EditorView): TableView;
    updateEx(update: (node: Node) => boolean, self: VignetteView, node: Node): boolean;
    updateBorder(tableView: TableView): void;
    static isVignette(state: EditorState, actionNode: Node): boolean;
    getMenu(state: EditorState, actionNode: Node, cmdGrps: Array<{
        [key: string]: UICommand;
    }>): Array<{
        [key: string]: UICommand;
    }>;
    isEnabledEx(isEnabled: (state: EditorState, view?: EditorView) => boolean, state: EditorState, view?: EditorView): boolean;
    destroy: () => void;
}
export declare class VignetteMenuPlugin extends Plugin {
    constructor();
}
