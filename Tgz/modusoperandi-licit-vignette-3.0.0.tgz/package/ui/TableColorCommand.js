// @flow
import { setCellAttr } from 'prosemirror-tables';
import { atAnchorRight, createPopUp, findNodesWithSameMark, MARK_TEXT_COLOR, RuntimeService, } from '@modusoperandi/licit-ui-commands';
import { ColorEditor } from '@modusoperandi/color-picker';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export class TableColorCommand extends UICommand {
    executeCustomStyleForTable(_state, tr, _from, _to) {
        return tr;
    }
    _popUp = null;
    getAttrName = () => {
        return '';
    };
    isEnabled = (_state) => {
        return true;
    };
    shouldRespondToUIEvent = (e) => {
        return e.type === UICommand.EventType.MOUSEENTER;
    };
    waitForUserInput = (_state, _dispatch, _view, event) => {
        if (this._popUp) {
            return Promise.resolve(undefined);
        }
        const target = event?.currentTarget;
        if (!(target instanceof HTMLElement)) {
            return Promise.resolve(undefined);
        }
        const { doc, selection, schema } = _state;
        const { from, to } = selection;
        const markType = schema.marks[MARK_TEXT_COLOR];
        const result = findNodesWithSameMark(doc, from, to, markType);
        const hex = result?.mark.attrs.color ?? null;
        const anchor = event?.currentTarget;
        const node = _state.tr.doc.nodeAt(from);
        const Textmark = node?.marks.find((mark) => mark?.attrs?.color);
        const Textcolor = Textmark?.attrs?.color;
        // [FS] KNITE-1489 2024-12-25
        // Fix:VIgnette Color and Border Palette GUIs should match GUIs of Font and Background tools in Doc Edit View
        return new Promise((resolve) => {
            this._popUp = createPopUp(ColorEditor, { hex, runtime: RuntimeService.Runtime, Textcolor }, {
                anchor,
                position: atAnchorRight,
                popUpId: 'mo-menuList-child',
                autoDismiss: true,
                onClose: (val) => {
                    if (this._popUp) {
                        this._popUp = null;
                        resolve(val);
                    }
                },
            });
        });
    };
    executeWithUserInput = (state, dispatch, view, color) => {
        if (dispatch && color?.color !== undefined) {
            const cmd = setCellAttr(this.getAttrName(), color.color);
            cmd(state, dispatch, view);
            return true;
        }
        return false;
    };
    cancel() {
        this._popUp?.close(undefined);
    }
    renderLabel() {
        return null;
    }
    isActive() {
        return true;
    }
    executeCustom(_state, tr) {
        return tr;
    }
}
