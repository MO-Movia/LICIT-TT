import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { PopUpHandle } from '@modusoperandi/licit-ui-commands';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export declare class TableColorCommand extends UICommand {
    executeCustomStyleForTable(_state: EditorState, tr: Transform, _from: number, _to: number): Transform;
    _popUp?: PopUpHandle;
    getAttrName: () => string;
    isEnabled: (_state: EditorState) => boolean;
    shouldRespondToUIEvent: (e: React.SyntheticEvent | MouseEvent) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, event?: React.SyntheticEvent) => Promise<unknown>;
    executeWithUserInput: (state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, color?: {
        color: any;
        selectedOption: any;
    }) => boolean;
    cancel(): void;
    renderLabel(): any;
    isActive(): boolean;
    executeCustom(_state: EditorState, tr: Transform): Transform;
}
