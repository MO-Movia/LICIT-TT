import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export function createCommand(execute) {
    class CustomCommand extends UICommand {
        isEnabled = (state) => {
            return this.execute(state);
        };
        execute = (state, dispatch, view) => {
            const tr = state.tr;
            let endTr = tr;
            execute(state, (nextTr) => {
                endTr = nextTr;
                dispatch?.(endTr);
            }, view);
            return endTr.docChanged || tr !== endTr;
        };
        waitForUserInput = (_state, _dispatch, _view, _event) => {
            return Promise.resolve(undefined);
        };
        executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
            return false;
        };
        executeCustomStyleForTable(_state, tr, _from, _to) {
            return tr;
        }
        cancel() {
            return null;
        }
        renderLabel() {
            return null;
        }
        isActive() {
            return true;
        }
        executeCustom(_state, tr) {
            return tr;
        }
    }
    return new CustomCommand();
}
