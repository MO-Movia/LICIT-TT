import { Schema } from 'prosemirror-model';
import { EditorState, Transaction } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import * as React from 'react';
import { Transform } from 'prosemirror-transform';
export declare class VignetteCommand extends UICommand {
    executeCustomStyleForTable(_state: EditorState, tr: Transform, _from: number, _to: number): Transform;
    isEnabled: (state: EditorState, view?: EditorView) => boolean;
    execute: (state: EditorState, dispatch?: (tr: Transaction) => void, view?: EditorView) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch: (tr: Transform) => void, _view: EditorView, _event: React.SyntheticEvent<Element, Event>) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch: (tr: Transform) => void, _view: EditorView, _inputs: string) => boolean;
    cancel(): void;
    __isEnabled: (_state: EditorState, _view?: EditorView) => boolean;
    insertTable(tr: Transaction, schema: Schema, rows: number, cols: number): Transaction;
    insertParagraph(state: EditorState, tr: Transaction): Transaction;
    renderLabel(): any;
    isActive(): boolean;
    executeCustom(_state: EditorState, tr: Transform): Transform;
}
