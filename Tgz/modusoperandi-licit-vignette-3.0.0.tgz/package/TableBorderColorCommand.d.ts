import { TableColorCommand } from './ui/TableColorCommand';
export declare class TableBorderColorCommand extends TableColorCommand {
    getAttrName: () => string;
}
