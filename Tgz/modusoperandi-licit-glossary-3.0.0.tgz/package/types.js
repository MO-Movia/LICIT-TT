import { PluginKey } from 'prosemirror-state';
export const GLOSSARY_PLUGIN_KEY = new PluginKey('GlossaryPlugin');
export const GLOSSARY = 'glossary';
export const ACRONYM = 'acronym';
export function getGlossaryRuntime(view) {
    return view.state.plugins
        .find((p) => p.spec.key === GLOSSARY_PLUGIN_KEY)
        ?.getState(view.state)?.runtime;
}
