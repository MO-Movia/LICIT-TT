import type { NodeSpec } from 'prosemirror-model';
export declare const GlossaryNodeSpec: NodeSpec;
