import { Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
import { makeKeyMapWithCommon, createKeyMapPlugin, } from '@modusoperandi/licit-doc-attrs-step';
import { GlossaryNodeSpec } from './glossaryNodeSpec';
import { GlossaryView, updateCache } from './glossaryView';
import { GLOSSARY_PLUGIN_KEY, GLOSSARY } from './types';
import { GlossaryCommand } from './glossaryCommand';
import { DarkThemeIcon, LightThemeIcon } from './images';
export const KEY_GLOSSARY = makeKeyMapWithCommon(GLOSSARY, 'Mod-Alt' + '-g');
export class GlossaryPlugin extends Plugin {
    runtime;
    constructor(runtime) {
        super({
            key: GLOSSARY_PLUGIN_KEY,
            props: {
                nodeViews: {
                    [GLOSSARY]: bindGlossaryView,
                },
            },
            state: {
                init(_config, _state) {
                    return { runtime };
                },
                apply(_tr, _prev, _, _newState) {
                    return _prev;
                },
            },
        });
        this.runtime = runtime;
        updateCache(runtime?.cache);
    }
    getEffectiveSchema(schema) {
        const nodes = schema.spec.nodes.addToEnd(GLOSSARY, GlossaryNodeSpec);
        const marks = schema.spec.marks;
        schema = new Schema({ nodes, marks });
        return schema;
    }
    initKeyCommands() {
        return createKeyMapPlugin({
            [KEY_GLOSSARY.common]: new GlossaryCommand(this.runtime)
                .waitForUserInput,
        }, 'GlossaryKeyMap');
    }
    initButtonCommands(theme) {
        let image = null;
        if ('light' == theme) {
            image = DarkThemeIcon;
        }
        else {
            image = LightThemeIcon;
        }
        return {
            [`[${image}] Insert Glossary/Acronym`]: new GlossaryCommand(this.runtime),
        };
    }
}
function bindGlossaryView(node, view) {
    return new GlossaryView(node, view);
}
