import { Node } from 'prosemirror-model';
import { EditorView, NodeView } from 'prosemirror-view';
import { CacheInput, IndexItem } from './types';
export declare const cache: Record<string, Promise<IndexItem | undefined | null> | undefined>;
export declare function updateCache(values?: CacheInput): void;
export declare class GlossaryView implements NodeView {
    private node;
    dom: globalThis.Node;
    contentDOM: HTMLElement;
    constructor(node: Node, outerView: EditorView);
    private updateTooltip;
    private setTooltip;
    update(node: Node): boolean;
    stopEvent(_event: Event): boolean;
    ignoreMutation(): boolean;
}
