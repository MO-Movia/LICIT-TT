import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { TextSelection } from 'prosemirror-state';
import { GLOSSARY, } from './types';
export class GlossaryCommand extends UICommand {
    runtime;
    executeCustomStyleForTable(_state, tr, _from, _to) {
        return tr;
    }
    constructor(runtime) {
        super();
        this.runtime = runtime;
    }
    isEnabled = (state, _view) => {
        return this.executeWithUserInput(state, undefined, _view, {
            id: 'test',
            term: 'test',
        });
    };
    getSelectedText(editorView) {
        let selectedText = '';
        editorView.state.tr.doc.nodesBetween(editorView.state.selection.from, editorView.state.selection.to, (node, _pos) => {
            if (node) {
                selectedText = node.text ?? '';
            }
            return true;
        });
        return selectedText;
    }
    waitForUserInput = (state, _dispatch, _view) => {
        return (this.runtime?.glossaryService.openManagementDialog(state.doc.cut(state.selection.from, state.selection.to).textContent) ?? Promise.resolve(undefined));
    };
    executeWithUserInput = (state, dispatch, _view, item) => {
        if (!item?.term) {
            return false;
        }
        try {
            const { selection } = state;
            const { from, to } = selection;
            // Validate positions
            if (from >= 0 &&
                to >= 0 &&
                from < state.doc.content.size &&
                to < state.doc.content.size) {
                let transaction = this.createGlossaryAcronymNode(state, item, !selection.empty);
                // Restore selection if needed
                if (!selection.empty) {
                    const newSelection = TextSelection.create(transaction?.doc, from, to);
                    transaction = transaction?.setSelection(newSelection);
                }
                dispatch?.(transaction);
                return true;
            }
        }
        catch {
            // can't do transaction. return false.
        }
        return false;
    };
    cancel() {
        return;
    }
    createGlossaryAcronymNode(state, item, replace) {
        const glossaryacronymNode = state.schema.nodes[GLOSSARY];
        const node = glossaryacronymNode.create({
            id: item.id,
            from: state.selection.from,
            to: state.selection.to,
            term: item.term,
            definition: item.definition,
            description: item.description,
        }, state.schema.text(item.term));
        if (replace) {
            return state.tr.replaceSelectionWith(node);
        }
        else {
            return state.tr.insert(state.selection.to, node);
        }
    }
    deleteGlossaryNode(state, term) {
        const node = state.schema.text(term);
        return state.tr.replaceSelectionWith(node);
    }
    renderLabel() {
        return null;
    }
    isActive() {
        return true;
    }
    executeCustom(_state, tr) {
        return tr;
    }
}
