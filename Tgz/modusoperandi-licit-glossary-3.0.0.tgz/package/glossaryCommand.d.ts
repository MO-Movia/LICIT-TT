import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState, Transaction } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { AcronymItem, GlossaryItem, GlossaryRuntime, IndexItem } from './types';
export declare class GlossaryCommand extends UICommand {
    private readonly runtime?;
    executeCustomStyleForTable(_state: EditorState, tr: Transform, _from: number, _to: number): Transform;
    constructor(runtime?: GlossaryRuntime | undefined);
    isEnabled: (state: EditorState, _view?: EditorView) => boolean;
    getSelectedText(editorView: EditorView): string;
    waitForUserInput: (state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView) => Promise<IndexItem | null | undefined>;
    executeWithUserInput: (state: EditorState, dispatch?: (tr: Transaction) => void | undefined, _view?: EditorView, item?: IndexItem) => boolean;
    cancel(): void;
    createGlossaryAcronymNode(state: EditorState, item: GlossaryItem | AcronymItem, replace: boolean): Transaction;
    deleteGlossaryNode(state: EditorState, term: string): Transaction;
    renderLabel(): unknown;
    isActive(): boolean;
    executeCustom(_state: EditorState, tr: Transform): Transform;
}
