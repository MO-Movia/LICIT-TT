import { Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
import { GlossaryRuntime } from './types';
export declare const KEY_GLOSSARY: {
    common: string;
};
export declare class GlossaryPlugin extends Plugin<{
    runtime?: GlossaryRuntime;
}> {
    private readonly runtime?;
    constructor(runtime?: GlossaryRuntime | undefined);
    getEffectiveSchema(schema: Schema): Schema;
    initKeyCommands(): unknown;
    initButtonCommands(theme: string): unknown;
}
