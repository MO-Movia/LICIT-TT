import { PluginKey } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
export declare const GLOSSARY_PLUGIN_KEY: PluginKey<any>;
export declare const GLOSSARY = "glossary";
export declare const ACRONYM = "acronym";
export interface GlossaryItem {
    id: string;
    term: string;
    definition: string;
    description?: never;
}
export interface AcronymItem {
    id: string;
    term: string;
    definition: string;
    description: string;
}
export type IndexItem = GlossaryItem | AcronymItem;
export interface GlossaryService {
    openManagementDialog(initialSearch: string): Promise<IndexItem | null | undefined>;
    fetchTerm?(id: string): Promise<IndexItem | null | undefined>;
}
export type CacheInput = IndexItem[] | Promise<IndexItem[]>;
export interface GlossaryRuntime {
    glossaryService: GlossaryService;
    cache?: CacheInput;
}
export interface GlossaryPluginState {
    runtime?: GlossaryRuntime;
}
export declare function getGlossaryRuntime(view: EditorView): GlossaryRuntime | undefined;
