import { DOMSerializer } from 'prosemirror-model';
import { getGlossaryRuntime, GLOSSARY } from './types';
import tippy from 'tippy.js';
export const cache = {};
export function updateCache(values) {
    if (Array.isArray(values)) {
        for (const item of values) {
            cache[item.id] = Promise.resolve(item);
        }
    }
    else {
        values?.then((v) => updateCache(v)).catch(console.warn);
    }
}
export class GlossaryView {
    node;
    dom;
    contentDOM;
    constructor(node, outerView) {
        this.node = node;
        if (!node?.type?.spec?.toDOM) {
            throw new Error('node "toDom" is not defined');
        }
        // We'll need these later
        const spec = DOMSerializer.renderSpec(outerView.dom.ownerDocument, node.type.spec.toDOM(this.node));
        this.dom = spec.dom;
        this.contentDOM = spec.contentDOM;
        this.contentDOM.contentEditable = 'false';
        this.contentDOM.className = GLOSSARY;
        this.updateTooltip(outerView);
    }
    updateTooltip(view) {
        const id = this.node.attrs.id;
        cache[id] ??= getGlossaryRuntime(view)?.glossaryService?.fetchTerm?.(id);
        this.setTooltip(this.node.attrs);
        cache[id]?.then((term) => this.setTooltip(term)).catch(console.warn);
    }
    setTooltip(term) {
        tippy(this.contentDOM, {
            content: term?.definition,
        });
    }
    update(node) {
        if (!node.sameMarkup(this.node)) {
            return false;
        }
        this.node = node;
        return true;
    }
    stopEvent(_event) {
        return false;
    }
    ignoreMutation() {
        return true;
    }
}
