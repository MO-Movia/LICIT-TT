declare const DarkThemeIcon = "assets/images/dark/Icon_glossary.svg";
declare const LightThemeIcon = "assets/images/light/Icon_glossary.svg";
export { DarkThemeIcon, LightThemeIcon };
