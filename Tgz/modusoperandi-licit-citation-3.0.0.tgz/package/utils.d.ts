export declare function toISOString(date: Date): string;
