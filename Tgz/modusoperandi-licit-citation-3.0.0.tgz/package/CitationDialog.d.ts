import React from 'react';
import { EditorView } from 'prosemirror-view';
import { PopUpHandle } from '@modusoperandi/licit-ui-commands';
import { CitableMaterial, Citation, citationBuilder, CitationProps } from './Types';
export type CitationDialogProps = CitationProps & {
    close?: (val?: CitationDialogProps) => void;
};
export type CitationDialogState = CitationProps & {
    buildSourceText?: citationBuilder;
    citableMaterial?: CitableMaterial[];
};
export declare class CitationDialog extends React.PureComponent<CitationDialogProps, CitationDialogState> {
    _popUp?: PopUpHandle;
    activeCitedMaterial?: string;
    constructor(props: CitationDialogProps);
    private renderField;
    render(): React.ReactNode;
    getCitableMaterialList(): React.ReactNode | undefined;
    setActiveCitedMaterial(id: string): void;
    getSourceText(): string;
    _showContextMenu(field: keyof Citation): void;
    execute(field: keyof Citation): void;
    componentWillUnmount(): void;
    onInputChanged<K extends keyof Omit<Citation, 'isCitationObject'>>(fieldName: K, e: React.ChangeEvent<HTMLInputElement>): void;
    _cancel: () => void;
    _save: () => void;
    createCitationObject(editorView: EditorView, mode: string): {
        mode: string;
        editorView: EditorView;
    };
    _onSearch(event: React.SyntheticEvent): void;
    disableCitationWIndow(isEditable: boolean): void;
}
