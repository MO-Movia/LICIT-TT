import { Attrs, NodeSpec } from 'prosemirror-model';
export declare const CitationNodeSpec: NodeSpec;
export declare function getAttrs(dom: HTMLElement | string): Attrs | false;
