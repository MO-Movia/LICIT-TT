import React from 'react';
import { Citation } from './Types';
export type SearchCitationProps = {
    close: (val?: SearchCitationState) => void;
};
export type SearchCitationState = {
    citations: Citation[];
    citationObject: Citation;
    selectedRowRefID?: string;
};
export declare class SearchCitation extends React.PureComponent<SearchCitationProps, SearchCitationState> {
    constructor(props: SearchCitationProps);
    fetchedCit(runtime: any): Promise<Citation[]>;
    getCitations(): void;
    componentDidMount(): void;
    render(): React.ReactNode;
    onRowClick(refId?: string): void;
    onSearchCitations(): void;
    _cancel: () => void;
    _save: () => void;
}
