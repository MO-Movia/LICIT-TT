import type { Citation } from './Types';
export declare class CitationRuntime {
    private readonly citationServerURI?;
    /**
     * Cached styles fetched from the service to avoid saturating
     * service with HTTP requests.
     * @private
     */
    citations: Citation[];
    citationByRefId?: Citation;
    constructor(citationServerURI?: string);
    buildRouteForCitation(...path: string[]): string;
    /**
     * Save or update a citation on the service.
     *
     * @param citation Citation to update.
     * @return Updated array of citations.
     */
    saveCitation(citation: Citation): Promise<Citation[]>;
    /**
     * Fetch list of citations.
     *
     * @returns Array of citations or empty array
     */
    fetchCitations(): Promise<Citation[]>;
    fetchCitationsByRefId(referenceId: string): Promise<Citation>;
    /**
     * Fetch list of citations.
     *
     * @returns Array of citations or empty array
     */
    getCitationsAsync(): Promise<Citation[]>;
    isArrEmpty(): boolean;
    /**
     * Remove an existing citation from the service.
     * @param referenceId unique id of citation to delete
     */
    removeCitation(referenceId: string): Promise<Citation[]>;
}
