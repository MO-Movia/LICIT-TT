import { Citation } from './Types';
export declare function defaultCitationText(citation: Citation, delimiter?: string): string;
