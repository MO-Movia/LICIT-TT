import React from 'react';
import { EditorView } from 'prosemirror-view';
export declare class CitationSubMenu extends React.PureComponent {
    props: {
        editorView: EditorView;
        href: string;
        onCancel: (view: EditorView) => void;
        onEdit: (view: EditorView) => void;
        onRemove: (view: EditorView) => void;
        onMouseOut: () => void;
    };
    state: {
        hidden: boolean;
    };
    render(): React.JSX.Element;
    _openLink: (href: string) => void;
}
