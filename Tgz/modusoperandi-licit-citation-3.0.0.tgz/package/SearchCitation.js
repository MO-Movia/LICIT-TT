// [FS] IRAD-1251 2021-03-10
// UI for Citation dialog
import React from 'react';
import { CitationRuntime } from './CitationRuntime';
let citationObject = {};
let selectedRowRefID = '';
let citations = [];
export class SearchCitation extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            ...props,
            citationObject,
            citations,
        };
    }
    fetchedCit(runtime) {
        return runtime.fetchCitations();
    }
    // To fetch the citation from server and set to the state.
    getCitations() {
        const runtime = new CitationRuntime();
        if (typeof runtime.getCitationsAsync === 'function') {
            const storedCitations = this.fetchedCit(runtime);
            storedCitations
                ?.then((result) => {
                if (result) {
                    citations = [];
                    result.forEach((obj) => {
                        citations.push({
                            ...obj,
                            publishedDateTitle: obj.publishedDateTitle ?? 'Published',
                        });
                    });
                    this.setState({
                        citations: citations,
                    });
                }
            })
                .catch(console.error);
        }
    }
    componentDidMount() {
        this.getCitations();
    }
    render() {
        return (React.createElement("div", { style: {
                width: '780px',
                border: '1px solid lightgray',
                boxShadow: '1px 1px',
            } },
            React.createElement("form", { className: "czi-form", style: { height: '272px' } },
                React.createElement("div", null,
                    React.createElement("div", { className: "molcit-div-display" },
                        React.createElement("label", { className: "molcit-citation-label", htmlFor: "docTitletxt", key: "lbldocTitle", style: { display: 'block', marginLeft: '2px' } }, "Document Title"),
                        React.createElement("input", { autoComplete: "off", className: "molcit-textborder search-key", id: "docTitletxt", key: "txtdocTitle", onChange: this.onSearchCitations.bind(this), style: { height: '20px', width: '170px' }, type: "text" })),
                    React.createElement("div", { className: "molcit-div-display" },
                        React.createElement("label", { className: "molcit-citation-label", htmlFor: "refIdtxt", key: "lblRefId", style: { display: 'block', marginLeft: '10px' } }, "Reference ID"),
                        React.createElement("input", { autoComplete: "off", className: "molcit-textborder search-key", id: "refIdtxt", key: "txtRefId", onChange: this.onSearchCitations.bind(this), style: {
                                height: '20px',
                                width: '170px',
                                marginLeft: '10px',
                            }, type: "text" })),
                    React.createElement("div", { className: "molcit-div-display" },
                        React.createElement("label", { className: "molcit-citation-label", htmlFor: "authortxt", key: "lblAuthor", style: {
                                display: 'block',
                                marginLeft: '10px',
                            } }, "Author"),
                        React.createElement("input", { autoComplete: "off", className: "molcit-textborder search-key", id: "authortxt", key: "txtAuthor", onChange: this.onSearchCitations.bind(this), style: {
                                height: '20px',
                                width: '170px',
                                marginLeft: '10px',
                            }, type: "text" })),
                    React.createElement("div", { className: "molcit-div-display", style: { display: 'none' } },
                        React.createElement("div", { className: "molcit-div-display" },
                            React.createElement("div", null,
                                React.createElement("label", { className: "molcit-citation-label search-key", htmlFor: "publishedDateInput", key: "lblPublishedDate", style: { border: 'none', marginLeft: '10px' } }, "Published Date")),
                            React.createElement("input", { id: "publishedDateInput", key: "txtPulishedDate", onChange: this.onSearchCitations.bind(this), style: {
                                    height: '21px',
                                    marginLeft: '10px',
                                    width: '175px',
                                }, type: "date" }))),
                    React.createElement("div", null),
                    React.createElement("div", { className: "molcit-searchdiv" },
                        React.createElement("table", { className: "molcit-tablecitations", id: "myTable" },
                            React.createElement("thead", { style: { backgroundColor: 'lightgray' } },
                                React.createElement("tr", { className: "molcit-citationrow" },
                                    React.createElement("th", { className: "molcit-citationsheader" }, "Document Title"),
                                    React.createElement("th", { className: "molcit-citationsheader" }, "Reference ID"),
                                    React.createElement("th", { className: "molcit-citationsheader" }, "Author"),
                                    React.createElement("th", { className: "molcit-citationsheader" }, "Published Date"))),
                            React.createElement("tbody", { className: "molcit-citationbody" }, this.state.citations.map((item) => (React.createElement("tr", { className: this.state.selectedRowRefID === item.referenceId
                                    ? 'molcit-rowselected'
                                    : '', key: item.referenceId, onClick: this.onRowClick.bind(this, item.referenceId) },
                                React.createElement("td", null, item.documentTitle),
                                React.createElement("td", null, item.referenceId),
                                React.createElement("td", null, item.author),
                                React.createElement("td", null, item.publishedDate))))))),
                    React.createElement("div", { style: {
                            float: 'right',
                            marginRight: '-8px',
                            marginTop: '5px',
                        } },
                        React.createElement("button", { key: "btnOk", onClick: this._save.bind(this), style: { display: 'none', height: '27px', width: '60px' } }, "OK"))),
                React.createElement("div", { style: { marginTop: '6px' } },
                    React.createElement("button", { key: "btnCancel", onClick: this._cancel, style: {
                            height: '27px',
                            float: 'right',
                            marginTop: '1px',
                            width: '60px',
                        } }, "Cancel"),
                    React.createElement("button", { className: "btnsave", key: "btnOk1", onClick: this._save.bind(this), style: { height: '27px', float: 'right', width: '60px' } }, "OK")))));
    }
    onRowClick(refId) {
        selectedRowRefID = refId;
        if (selectedRowRefID !== undefined) {
            citationObject = citations.find((u) => u.referenceId === selectedRowRefID);
            this.setState({ selectedRowRefID, citationObject });
        }
    }
    onSearchCitations() {
        let filteredCitations = citations;
        const authorEle = document.getElementById('authortxt');
        const docTitleEle = document.getElementById('docTitletxt');
        const refIdEle = document.getElementById('refIdtxt');
        const filter = {
            author: authorEle instanceof HTMLInputElement ? authorEle.value : '',
            documentTitle: docTitleEle instanceof HTMLInputElement ? docTitleEle.value : '',
            referenceId: refIdEle instanceof HTMLInputElement ? refIdEle.value : '',
        };
        filteredCitations = filteredCitations.filter((item) => {
            for (const key in filter) {
                if ('' !== filter[key] &&
                    (item[key] === undefined ||
                        item[key].toUpperCase().indexOf(filter[key].toUpperCase()) === -1)) {
                    return false;
                }
            }
            return true;
        });
        this.setState({
            citations: filteredCitations,
        });
    }
    _cancel = () => {
        this.props.close();
    };
    _save = () => {
        this.props.close(this.state);
    };
}
