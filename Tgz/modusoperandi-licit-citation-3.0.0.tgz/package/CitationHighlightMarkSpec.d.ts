import { Node, DOMOutputSpec } from 'prosemirror-model';
export type toDOMFn = (node: Node) => DOMOutputSpec;
export type getAttrsFromNodeFn = (p: Node | string) => {
    [k: string]: string;
};
export type Attrs = {
    highlightColor: string;
    hasCitation: boolean;
    markFrom: string;
    appliedHighlight: string;
};
export type getAttrsFromDomFn = (base: getAttrsFromNodeFn, dom: HTMLElement) => Attrs;
export declare function getAttrs(base: getAttrsFromNodeFn, dom: HTMLElement): Attrs;
declare function toDOM(base: toDOMFn, node: Node): DOMOutputSpec;
export declare const toMarkDOM: typeof toDOM;
export declare const getMarkAttrs: typeof getAttrs;
export {};
