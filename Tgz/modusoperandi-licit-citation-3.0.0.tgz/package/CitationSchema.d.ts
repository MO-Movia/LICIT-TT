import { Schema } from 'prosemirror-model';
export declare function effectiveSchema(schema: Schema): Schema;
export declare const applyEffectiveSchema: typeof effectiveSchema;
