export declare function req(conf: {
    url: string;
    method: string;
    body?: string;
    headers?: {
        [k: string]: string;
    };
}): Promise<string>;
export declare function GET(url: string): Promise<string>;
export declare function POST(url: string, body: string, type: string): Promise<string>;
export declare function DELETE(url: string, type: string): Promise<string>;
export declare function PATCH(url: string, body: string, type: string): Promise<string>;
