declare const DarkThemeIcon = "assets/images/dark/Icon_Source.svg";
declare const LightThemeIcon = "assets/images/light/Icon_Source.svg";
export { DarkThemeIcon, LightThemeIcon };
