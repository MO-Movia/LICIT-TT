import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { Fragment } from 'prosemirror-model';
import { CitationDialog } from './CitationDialog';
import { createPopUp, atViewportCenter, } from '@modusoperandi/licit-ui-commands';
import { AlertInfo } from './ui/AlertInfo';
import { MARK_TEXT_HIGHLIGHT, CITATION_NOTE, getNode, MODE, } from './Constants';
import { defaultCitationText } from './CitationBuilder';
import { toISOString } from './utils';
export class AddCitationCommand extends UICommand {
    citationPositions = [];
    citationText = '';
    from = '0';
    _popUp = null;
    _alertPopup = null;
    _color;
    citation;
    capcoService;
    citationBuilder;
    citableMaterial;
    constructor(opt) {
        super();
        this._color = opt?.color;
        this.capcoService = opt?.capcoService;
        this.citationBuilder = opt?.citationBuilder ?? defaultCitationText;
        this.citableMaterial = opt?.citableMaterial;
    }
    isEnabled = (state) => {
        return this._isEnabled(state);
    };
    waitForUserInput = (_state, _dispatch, view, _event) => {
        if (this._popUp) {
            return Promise.resolve(undefined);
        }
        return new Promise((resolve) => {
            this._popUp = createPopUp(CitationDialog, this.createCitationObject(MODE.new, view), {
                modal: true,
                IsChildDialog: false,
                autoDismiss: false,
                onClose: (val) => {
                    if (this._popUp) {
                        this._popUp = null;
                        resolve(val);
                    }
                },
            });
        });
    };
    executeWithUserInput = (state, dispatch, view, citation) => {
        if (dispatch) {
            this.citation = citation; // Store the citation object
            const { selection } = state;
            let { tr } = state;
            tr = tr.setSelection(selection);
            if (citation && !this.hasCitationApplied(tr)) {
                // save the citation use object to node
                this.showAlert('Please Wait!!!', 'Please wait, updating server...');
                tr = this.saveCitationUseObject(state, tr, citation);
                if (view) {
                    tr = this.createFootNoteForCitation(view, state, tr, citation);
                    dispatch(tr);
                }
            }
            view?.focus();
        }
        return false;
    };
    // [FS] IRAD-1379 2021-05-25
    // FIX: Validation to avoid citation more than on time for a text.
    hasCitationApplied(tr) {
        const { selection } = tr;
        const { from, to } = selection;
        for (let index = from; index < to; index++) {
            const node = tr.doc.nodeAt(index);
            if (node?.marks?.some((m) => m?.type?.name === 'mark-text-highlight' && m.attrs?.hasCitation)) {
                return true;
            }
        }
        return false;
    }
    // To show custom alert
    showAlert(title, content) {
        const anchor = null;
        this._alertPopup = createPopUp(AlertInfo, {
            content: content,
            title: title,
        }, {
            anchor,
            position: atViewportCenter,
            onClose: (_val) => {
                if (this._alertPopup) {
                    this._alertPopup = null;
                }
            },
        });
    }
    // [FS] IRAD-1340 2021-05-11
    // FIX: Disable Citation menu for Image
    _isEnabled = (state) => {
        const tr = state.tr;
        const { selection } = tr;
        return !(selection &&
            selection.node &&
            'image' === selection.node.type.name);
    };
    createCitationObject(mode, editorView) {
        return {
            overallDocumentCapco: 'TBD',
            author: '',
            authorTitle: 'Author',
            referenceId: 'REF-1001',
            referenceType: '',
            publishedDate: '',
            publishedDateTitle: 'Published',
            icod: '',
            declassifyDateType: '',
            declassifyDate: '',
            declassifyPeriod: '25',
            documentTitleCapco: 'TBD',
            documentTitle: '',
            dateAccessed: toISOString(new Date()),
            hyperLink: '',
            overallCitationCAPCO: 'TBD',
            pageTitle: '',
            extractedInfoCAPCO: 'TBD',
            descriptionCAPCO: 'N/A',
            description: '',
            citableMaterial: this.citableMaterial,
            citationObjectRefId: '',
            pages: '',
            mode,
            editorView,
            isCitationObject: editorView ? editorView.state.selection.empty : 'true', // if text not selected, then citationObject else citationUseObject,
            capcoService: this.capcoService,
        };
    }
    getParentNodeSize(state) {
        return state.selection.$head.parent.nodeSize - 2;
    }
    getParentStartPos(head) {
        return head.pos - head.parentOffset;
    }
    createFootNoteForCitation(view, state, tr, citation) {
        if (view.state.selection.empty) {
            return tr;
        }
        const citationNote = state.schema.nodes[CITATION_NOTE];
        const newattrs = {
            ...Object.keys(citationNote['attrs']).reduce((acc, key) => {
                acc[key] = key in citation ? citation[key] : null;
                return acc;
            }, {}),
            ...citation,
            from: state.tr.selection.from,
            to: state.tr.selection.to,
        };
        const citationNoteNode = citationNote.create(null);
        this.showCitations(citation);
        const $head = state.selection.$head;
        const { sentenceEnd, listNodeAttr, listPos } = this.calculateEndOfSentenceAndListAttributes(state, $head);
        tr = tr.insert(sentenceEnd, Fragment.from(citationNoteNode));
        tr = tr.setNodeMarkup(sentenceEnd, undefined, newattrs);
        if (listNodeAttr) {
            tr = tr.setNodeMarkup(listPos, undefined, listNodeAttr);
        }
        return tr;
    }
    calculateEndOfSentenceAndListAttributes(state, $head) {
        const listAttributes = this.getListAttributes($head);
        const sentenceEnd = this.findEndOfSentence(state, $head);
        return { sentenceEnd, ...listAttributes };
    }
    getListAttributes($head) {
        let listNodeAttr = null;
        let listPos = 0;
        for (let d = $head.depth; d > 0; d--) {
            if (this.isList($head, d)) {
                listNodeAttr = { ...$head.node(d).attrs };
                listPos = $head['path'][d + 4];
                break;
            }
        }
        return { listNodeAttr, listPos };
    }
    findEndOfSentence(state, $head) {
        const sentenceDelimiter = ['.', '!', '?'];
        let hasDelimiter = false;
        const selectionEnd = state.selection.to;
        const selectionStart = state.selection.from;
        let parentStart = 0;
        const selectionText = state.doc
            .textBetween(selectionStart, selectionEnd)
            .trimEnd();
        for (const char of selectionText) {
            if (sentenceDelimiter.includes(char)) {
                parentStart = selectionEnd - 1;
                hasDelimiter = true;
            }
            else {
                parentStart = selectionEnd;
            }
        }
        const parentText = state.doc.textBetween(parentStart, state.selection.$to.end());
        for (let i = 0; i < parentText.length; i++) {
            const char = parentText[i];
            if (sentenceDelimiter.includes(char)) {
                if (hasDelimiter) {
                    return selectionEnd + i;
                }
                else {
                    return selectionEnd + i + 1;
                }
            }
        }
        const parentStartPos = this.getParentStartPos($head);
        const parentNodeSize = this.getParentNodeSize(state);
        return parentStartPos + parentNodeSize;
    }
    showCitations(citation) {
        this.citationText = this.citationBuilder(citation);
        this.from = citation.from;
    }
    isList($head, d) {
        return !!($head.node(d).type.name === 'ordered_list' ||
            $head.node(d).type.name === 'bullet_list');
    }
    // to save the citation use object in the node attribute
    saveCitationUseObject(state, tr, citation) {
        if (!citation.isCitationObject) {
            const from = state.selection.$from.before();
            const to = state.selection.$to.end();
            const node = getNode(from, to, tr);
            if (node) {
                const newAttrs = {
                    ...node.attrs,
                    ...citation,
                    id: '',
                    indent: 0,
                };
                tr = tr.setNodeMarkup(from, undefined, newAttrs);
            }
        }
        return tr;
    }
    renderLabel() {
        return;
    }
    isActive() {
        return true;
    }
    cancel() {
        return;
    }
    executeCustom(_state, tr) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
}
export function addTexthighlightMark(tr, state, from, to) {
    const highLightMarkType = state.schema.marks['mark-text-highlight'];
    const attrs = {
        highlightColor: '#aed0e6',
        hasCitation: true,
        markFrom: from,
    };
    tr = tr.addMark(from, to, highLightMarkType.create(attrs));
    return tr;
}
export function removeTexthighlightMark(tr, state, from, to) {
    const highLightMarkType = state.schema.marks[MARK_TEXT_HIGHLIGHT];
    tr = tr.removeMark(from, to, highLightMarkType);
    return tr;
}
export function ShowTexteHighLightMark(tr, state, nodePos, hasCitation, appliedHighlightColor, citationNodeTo) {
    const attrs = {
        highlightColor: hasCitation ? appliedHighlightColor : '#aed0e6',
        hasCitation: hasCitation,
        markFrom: nodePos,
        appliedHighlight: appliedHighlightColor,
    };
    const highLightMarkType = state.schema.marks[MARK_TEXT_HIGHLIGHT];
    tr = tr.addMark(nodePos, Number(citationNodeTo), highLightMarkType.create(attrs));
    return tr;
}
