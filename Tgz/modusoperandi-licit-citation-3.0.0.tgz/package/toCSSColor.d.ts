export declare function isTransparent(source: string): boolean;
export declare function toCSSColor(source: string): string;
