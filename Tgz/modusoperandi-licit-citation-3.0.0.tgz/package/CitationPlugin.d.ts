import { Plugin, Transaction, EditorState } from 'prosemirror-state';
import { EditorView, DecorationSet } from 'prosemirror-view';
import { Mark, Node, Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import { AddCitationCommand } from './AddCitationCommand';
import { CitationPluginOptions, CitationPluginState } from './Types';
export declare const KEY_CITATION: {
    description: string;
    windows: string;
    mac: string;
    common?: string;
};
export declare class CitationPlugin extends Plugin<CitationPluginState> {
    private readonly opt?;
    addCitationCmd: AddCitationCommand;
    _view?: EditorView;
    constructor(opt?: CitationPluginOptions);
    handleAppendTransactions(transactions: [Transaction], prevState: EditorState, nextState: EditorState): Transaction;
    getRow(node: any, prevState: any, startPos: any, parentNode: any, parentPos: any, nextState: any, tr: any): Transform;
    findMarkObject(parentNode: any, themarkPos: any, from: any): {
        pos: number;
        marks: readonly Mark[];
        diff: number;
    };
    getEffectiveSchema(schema: Schema): Schema;
    initKeyCommands(): unknown;
    createCitationNotObject(Nodeattrs: NamedNodeMap): HTMLElement;
    initButtonCommands(theme: string): unknown;
    static createCitation(state: EditorState, dispatch: (tr: Transaction) => void, view: EditorView): boolean | Transform;
}
export declare function isHighlightViaCollab(tr: Transaction): boolean;
export declare function commentDeco(doc: Node, state: EditorState, tr: Transaction): DecorationSet;
