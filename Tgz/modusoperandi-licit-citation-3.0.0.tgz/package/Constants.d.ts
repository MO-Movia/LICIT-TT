import { Node } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare const CITATION_NOTE = "citationnote";
export declare const MARK_UNDERLINE = "underline";
export declare const MARK_TEXT_HIGHLIGHT = "mark-text-highlight";
export declare const HASCITATION = "hasCitation";
export declare const MARKFROM = "markFrom";
export declare const PARAGRAPH = "paragraph";
export declare const HEADING = "heading";
export declare const HIGHLIGHTDECO = "citationHighLightDecoration";
export declare enum MODE {
    new = 1,
    modify = 2,
    delete = 3
}
export interface Marking {
    portionMarking?: string;
}
export interface CapcoService<T extends Marking> {
    openManagementDialog(selectedCapco?: T): Promise<Marking | null>;
}
export type CitationRuntime<T extends Marking> = {
    capcoService: CapcoService<T>;
};
export declare function getNode(from: number, to: number, tr: Transform): Node | undefined;
