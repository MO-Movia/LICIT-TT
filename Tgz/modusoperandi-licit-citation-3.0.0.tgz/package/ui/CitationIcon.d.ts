import React from 'react';
export declare class CitationIcon extends React.PureComponent {
    static get(type: string, title?: string): React.ReactNode;
    props: {
        type?: string;
        title?: string;
    };
    render(): React.JSX.Element;
}
