import React from 'react';
import cx from 'classnames';
import { PointerSurface, TooltipSurface } from '@modusoperandi/licit-ui-commands';
export class CitationToolButton extends React.PureComponent {
    render() {
        const { icon, label, className, title, ...pointerProps } = this.props;
        const klass = cx(className, 'czi-custom-button', {
            'use-icon': !!icon,
        });
        return (React.createElement(TooltipSurface, { tooltip: title },
            React.createElement(PointerSurface, { ...pointerProps, className: klass },
                icon,
                label)));
    }
}
