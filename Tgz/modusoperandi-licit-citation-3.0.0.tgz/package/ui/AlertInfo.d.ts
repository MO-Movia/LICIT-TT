import React from 'react';
type AlertProps = {
    title: string | undefined;
    content: string | undefined;
};
type AlertState = {
    initialValue: Record<string, never>;
    close: () => void;
};
export declare class AlertInfo extends React.PureComponent<AlertProps, AlertState> {
    render(): React.ReactNode;
}
export {};
