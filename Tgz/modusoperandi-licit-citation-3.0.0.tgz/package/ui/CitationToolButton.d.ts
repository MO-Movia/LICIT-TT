import React from 'react';
import type { PointerSurfaceProps } from '@modusoperandi/licit-ui-commands';
export declare class CitationToolButton extends React.PureComponent {
    props: PointerSurfaceProps & {
        icon?: string | React.ReactNode | null;
        label?: string | React.ReactNode | null;
    };
    render(): React.JSX.Element;
}
