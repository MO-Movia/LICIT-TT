import { EditorView } from 'prosemirror-view';
import { AddCitationCommand } from './AddCitationCommand';
import { Citation } from './Types';
export declare class CitationFooterView {
    addCitationCommand: AddCitationCommand;
    dom?: globalThis.Node;
    view?: EditorView;
    lastAddedCitation?: string;
    constructor(view: any, addCitationCommand: AddCitationCommand);
    selectNode(e: MouseEvent): void;
    findElementByObjectId(root: Element, id: string): Element;
    scrollToNode(view: any, pos: any): void;
    scrollToSpecificNode(view: any, node: any): void;
    update(view: any, prevState: any): void;
    getPluginState(state: any): Record<string, unknown>;
    buildCitationObject(node: any): Citation;
    populateCitationsOnLoad(doc: any): void;
    destroy(): void;
}
