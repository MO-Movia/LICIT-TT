import { citationFields } from './Types';
const defaultAttrs = {};
citationFields.forEach(field => defaultAttrs[field] = { default: null });
export const CitationNodeSpec = {
    group: 'inline',
    content: 'text*',
    inline: true,
    selectable: false,
    attrs: defaultAttrs,
    toDOM,
    parseDOM: [
        {
            tag: 'citationnote',
            getAttrs,
        },
    ],
};
export function getAttrs(dom) {
    if (typeof dom === 'string') {
        return false;
    }
    const attrs = {};
    citationFields.forEach(field => attrs[field] = dom.getAttribute(field) ?? null);
    return attrs;
}
function toDOM(node) {
    const attrs = {
        ...node.attrs
    };
    return ['citationnote', attrs, 0];
}
