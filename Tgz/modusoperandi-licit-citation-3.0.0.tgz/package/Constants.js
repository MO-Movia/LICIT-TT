export const CITATION_NOTE = 'citationnote';
export const MARK_UNDERLINE = 'underline';
export const MARK_TEXT_HIGHLIGHT = 'mark-text-highlight';
export const HASCITATION = 'hasCitation';
export const MARKFROM = 'markFrom';
export const PARAGRAPH = 'paragraph';
export const HEADING = 'heading';
export const HIGHLIGHTDECO = 'citationHighLightDecoration';
export var MODE;
(function (MODE) {
    MODE[MODE["new"] = 1] = "new";
    MODE[MODE["modify"] = 2] = "modify";
    MODE[MODE["delete"] = 3] = "delete";
})(MODE || (MODE = {}));
//to get the selected node
export function getNode(from, to, tr) {
    let selectedNode;
    tr.doc.nodesBetween(from, to, (node, _startPos) => {
        if (node.type.name === 'paragraph') {
            selectedNode ??= node;
        }
    });
    return selectedNode;
}
