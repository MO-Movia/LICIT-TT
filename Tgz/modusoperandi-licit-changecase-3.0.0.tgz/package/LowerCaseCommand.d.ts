import { EditorState } from "prosemirror-state";
import { Transform } from "prosemirror-transform";
import { EditorView } from "prosemirror-view";
import { UICommand } from "@modusoperandi/licit-doc-attrs-step";
export declare class LowerCaseCommand extends UICommand {
    executeCustomStyleForTable(_state: EditorState, tr: Transform, _from: number, _to: number): Transform;
    isEnabled: (state: EditorState) => boolean;
    _isEnabled: (state: EditorState) => boolean;
    execute: (state: EditorState, dispatch: (tr: Transform) => void | undefined, _view: EditorView | undefined) => boolean;
    renderLabel(): any;
    isActive(): boolean;
    waitForUserInput(): Promise<null>;
    executeWithUserInput(): boolean;
    cancel(): void;
    executeCustom(_state: EditorState, tr: Transform): Transform;
}
