"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LightThemeIcon = exports.DarkThemeIcon = void 0;
const DarkThemeIcon = 'assets/images/dark/icon_change_case.svg';
exports.DarkThemeIcon = DarkThemeIcon;
const LightThemeIcon = 'assets/images/light/icon_change_case.svg';
exports.LightThemeIcon = LightThemeIcon;
