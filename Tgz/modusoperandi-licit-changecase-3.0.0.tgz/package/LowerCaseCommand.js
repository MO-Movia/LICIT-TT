"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LowerCaseCommand = void 0;
const licit_doc_attrs_step_1 = require("@modusoperandi/licit-doc-attrs-step");
// Code to convert the selected text into LowerCase
// NOSONAR
class LowerCaseCommand extends licit_doc_attrs_step_1.UICommand {
    constructor() {
        super(...arguments);
        // To check if any text is selected
        this.isEnabled = (state) => {
            return this._isEnabled(state);
        };
        this._isEnabled = (state) => {
            const tr = state.tr;
            if (!tr.selection.empty) {
                return true;
            }
            return false;
        };
        // Logic to convert text to lowercase and assign them marks
        this.execute = (state, dispatch, _view) => {
            const { from, to } = state.selection;
            const tr = state.tr;
            state.doc.nodesBetween(from, to, (node, pos) => {
                if (node.isText && pos <= to && pos + node.nodeSize >= from) {
                    const start = Math.max(pos, from);
                    const end = Math.min(pos + node.nodeSize, to);
                    const text = node.textBetween(start - pos, end - pos);
                    if (text !== text.toLowerCase()) {
                        const transformedText = text.toLowerCase();
                        tr.replaceWith(start, end, state.schema.text(transformedText, node.marks));
                    }
                }
            });
            dispatch(tr.scrollIntoView());
            return true;
        };
    }
    executeCustomStyleForTable(_state, tr, _from, _to) {
        return tr;
    }
    renderLabel() {
        return null;
    }
    isActive() {
        return true;
    }
    waitForUserInput() {
        return Promise.resolve(null);
    }
    executeWithUserInput() {
        return true;
    }
    cancel() {
        return null;
    }
    executeCustom(_state, tr) {
        return tr;
    }
}
exports.LowerCaseCommand = LowerCaseCommand;
