declare const DarkThemeIcon = "assets/images/dark/icon_change_case.svg";
declare const LightThemeIcon = "assets/images/light/icon_change_case.svg";
export { DarkThemeIcon, LightThemeIcon };
