import { EditorView } from 'prosemirror-view';
import { Plugin } from 'prosemirror-state';
export declare class ChangeCasePlugin extends Plugin {
    _view: EditorView;
    constructor();
    initButtonCommands(theme: string): unknown;
}
