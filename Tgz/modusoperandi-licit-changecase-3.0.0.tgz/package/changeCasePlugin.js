"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChangeCasePlugin = void 0;
const prosemirror_state_1 = require("prosemirror-state");
const UpperCaseCommand_1 = require("./UpperCaseCommand");
const LowerCaseCommand_1 = require("./LowerCaseCommand");
const SentenceCaseCommand_1 = require("./SentenceCaseCommand");
const images_1 = require("./images");
class ChangeCasePlugin extends prosemirror_state_1.Plugin {
    constructor() {
        super({
            key: new prosemirror_state_1.PluginKey('ChangeCasePlugin'),
        });
        this._view = null;
    }
    initButtonCommands(theme) {
        let image = null;
        if ('light' == theme) {
            image = images_1.LightThemeIcon;
        }
        else {
            image = images_1.DarkThemeIcon;
        }
        return {
            [`[${image}] Change Case`]: [
                {
                    'UpperCase': new UpperCaseCommand_1.UpperCaseCommand(),
                    'LowerCase': new LowerCaseCommand_1.LowerCaseCommand(),
                    'SentenceCase': new SentenceCaseCommand_1.SentanceCaseCommand(),
                },
            ],
        };
    }
}
exports.ChangeCasePlugin = ChangeCasePlugin;
