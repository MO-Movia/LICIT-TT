import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { ExportPDF } from './exportPdf';
import React from 'react';
export declare class ExportPDFCommand extends UICommand {
    private static isPreviewFormOpen;
    exportPdf: ExportPDF;
    constructor();
    isEnabled: () => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    execute: (_state: EditorState, _dispatch: (tr: Transform) => void, view: EditorView, doc: unknown) => boolean;
    renderLabel(): any;
    isActive(): boolean;
    executeCustom(_state: EditorState, tr: Transform): Transform;
    executeCustomStyleForTable(_state: EditorState, tr: Transform): Transform;
    static closePreviewForm(): void;
}
