import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { ExportPDF } from './exportPdf';
export class ExportPDFCommand extends UICommand {
    static isPreviewFormOpen = false;
    exportPdf;
    constructor() {
        super();
        this.exportPdf = new ExportPDF();
    }
    isEnabled = () => {
        return true;
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    execute = (_state, _dispatch, view, doc) => {
        if (ExportPDFCommand.isPreviewFormOpen) {
            return false;
        }
        ExportPDFCommand.isPreviewFormOpen = true;
        return this.exportPdf.exportPdf(view, doc);
    };
    renderLabel() {
        return null;
    }
    isActive() {
        return true;
    }
    executeCustom(_state, tr) {
        return tr;
    }
    executeCustomStyleForTable(_state, tr) {
        return tr;
    }
    static closePreviewForm() {
        ExportPDFCommand.isPreviewFormOpen = false;
    }
}
