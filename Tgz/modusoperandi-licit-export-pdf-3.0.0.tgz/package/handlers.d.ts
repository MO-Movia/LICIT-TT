import { Handler } from 'pagedjs';
export declare class PDFHandler extends Handler {
    static readonly state: {
        currentPage: number;
        isOnLoad: boolean;
    };
    done: boolean;
    countTOC: number;
    pageFooters: Array<HTMLElement>;
    prepagesCount: number;
    caller: any;
    private counters;
    constructor(chunker: any, polisher: any, caller: any);
    beforeParsed(content: any): void;
    afterPageLayout(pageFragment: any, page: any): void;
    afterRendered(pages: any): void;
    private resetCounters;
    private handleSpecialCounters;
    private buildLabel;
    stripHTML(html: string): string;
    beforePageLayout(): void;
    doIT(): Promise<void>;
    finalizePage(): void;
}
