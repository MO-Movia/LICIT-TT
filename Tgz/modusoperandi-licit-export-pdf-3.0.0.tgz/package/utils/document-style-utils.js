export function getStyleLevel(styleName, styles) {
    const style = styles.find(style => style.name === styleName);
    if (!style?.level)
        return null;
    const level = Number(style.level);
    return isNaN(level) ? 1 : level;
}
