import { Node } from 'prosemirror-model';
import { StoredStyle } from './table-of-contents-utils';
export type SectionNodeStructure = {
    id: string;
    title: string;
    style: string;
    level: number | null;
    isChecked: boolean;
    children: SectionNodeStructure[];
};
export type FlatSectionNodeStructure = {
    id: string;
    title: string;
    style: string;
    level: number | null;
    isChecked: boolean;
    childrenIds: string[];
};
export declare function buildSectionStructure(nodeList: Node[], styles: StoredStyle[]): SectionNodeStructure[];
export declare function flattenStructure(structure: SectionNodeStructure[]): FlatSectionNodeStructure[];
export declare function toggleAllSectionChildElements(flatStructure: FlatSectionNodeStructure[], sectionId: string, isDisabled: boolean): void;
export declare function filterDocumentSections(renderedDoc: HTMLElement, nodes: Node[], excludedNodes: string[], storedStyles: StoredStyle[]): HTMLElement;
export declare function buildListOfIdsToAdd(sectionId: string, currentListOfExcludedIds: string[], flatStructure: FlatSectionNodeStructure[]): string[];
export declare function buildListOfIdsToRemove(sectionId: string, currentListOfExcludedIds: string[], flatStructure: FlatSectionNodeStructure[]): string[];
