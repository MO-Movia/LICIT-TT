import { StoredStyle } from './table-of-contents-utils';
export declare function getStyleLevel(styleName: string, styles: StoredStyle[]): number | null;
