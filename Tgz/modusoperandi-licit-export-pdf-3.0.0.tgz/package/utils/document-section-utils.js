import { getStyleLevel } from './document-style-utils';
export function buildSectionStructure(nodeList, styles) {
    const structure = nodeList.reduce((nodes, { ...node }) => {
        const style = node.attrs.styleName;
        const level = getStyleLevel(style, styles) ?? 1;
        const nodeContent = node.content;
        const content = nodeContent.content ?? [];
        const value = {
            id: node.attrs.objectId,
            title: content.length ? content[0].text ?? '' : '',
            style,
            level,
            isChecked: true,
            children: []
        };
        nodes[level] = value.children;
        nodes[level - 1].push(value);
        return nodes;
    }, [[]]).shift();
    return structure;
}
export function flattenStructure(structure) {
    const flattenedStructure = [];
    const mutatedStrucutre = structuredClone(structure);
    for (const section of mutatedStrucutre) {
        const baseSection = { ...section };
        delete baseSection.children;
        const flattenedSection = {
            ...baseSection,
            childrenIds: [],
        };
        if (section.children.length) {
            for (const child of section.children) {
                flattenedSection.childrenIds.push(child.id);
            }
            flattenedStructure.push(flattenedSection);
            flattenedStructure.push(...flattenStructure(section.children));
        }
        else {
            delete section.children;
            flattenedStructure.push(flattenedSection);
        }
    }
    return flattenedStructure;
}
function addSelectedSection(flatStructure, sectionId, isChildId = false) {
    const section = flatStructure.find(section => section.id === sectionId);
    const sectionIdsToAdd = [sectionId];
    if (isChildId) {
        toggleDisableInput(sectionId, false);
    }
    if (section.childrenIds.length) {
        toggleAllSectionChildElements(flatStructure, sectionId, false);
        sectionIdsToAdd.push(...getCheckedChildSection(section, flatStructure));
    }
    for (const section of flatStructure) {
        if (section.childrenIds.includes(sectionId)) {
            section.isChecked = true;
            sectionIdsToAdd.push(...addSelectedSection(flatStructure, section.id, true));
        }
    }
    return sectionIdsToAdd;
}
function getCheckedChildSection(section, flatStructure) {
    const checkedChildSection = [];
    for (const id of section.childrenIds) {
        const childSection = flatStructure.find(section => section.id === id);
        if (childSection?.isChecked) {
            checkedChildSection.push(childSection.id);
            checkedChildSection.push(...getCheckedChildSection(childSection, flatStructure));
        }
    }
    return checkedChildSection;
}
export function toggleAllSectionChildElements(flatStructure, sectionId, isDisabled) {
    const section = flatStructure.find(section => section.id === sectionId);
    if (section?.childrenIds?.length && section?.isChecked) {
        for (const id of section.childrenIds) {
            toggleDisableInput(id, isDisabled);
            toggleAllSectionChildElements(flatStructure, id, isDisabled);
        }
    }
}
export function filterDocumentSections(renderedDoc, nodes, excludedNodes, storedStyles) {
    const proseMirrorContainer = renderedDoc.getElementsByClassName('ProseMirror')[0] ?? null;
    if (proseMirrorContainer) {
        const tempTocNodeList = JSON.parse(JSON.stringify(nodes));
        for (const id of excludedNodes) {
            const node = nodes.find(node => node.attrs.objectId === id);
            if (node?.attrs?.styleName) {
                const nodeStyle = node.attrs.styleName;
                const workingIndexes = tempTocNodeList.filter(node => node.attrs.styleName === nodeStyle);
                const workingSection = workingIndexes.findIndex(node => node.attrs.objectId === id);
                const sectionElements = proseMirrorContainer.children;
                const collectionArray = Array.from(sectionElements);
                const nodeIndexs = getIndexBySectionName(collectionArray, nodeStyle);
                const startingIndex = nodeIndexs[workingSection];
                const sectionLevel = getStyleLevel(nodeStyle, storedStyles);
                if (!sectionLevel || !sectionElements[startingIndex])
                    break;
                sectionElements[startingIndex].remove();
                if (!sectionElements[startingIndex])
                    break;
                deleteDocumentChildElements(startingIndex, sectionElements, storedStyles);
            }
            const removedSection = tempTocNodeList.findIndex(node => node.attrs.objectId === id);
            tempTocNodeList.splice(removedSection, 1);
        }
    }
    return renderedDoc;
}
export function buildListOfIdsToAdd(sectionId, currentListOfExcludedIds, flatStructure) {
    const section = flatStructure.find(section => section.id === sectionId);
    section.isChecked = true;
    const ids = addSelectedSection(flatStructure, sectionId);
    let newNodeList = structuredClone(currentListOfExcludedIds);
    newNodeList = newNodeList.filter((nodeId) => !ids.includes(nodeId));
    return sortExcludeListByFlattenedSection(newNodeList, flatStructure);
}
export function buildListOfIdsToRemove(sectionId, currentListOfExcludedIds, flatStructure) {
    let newNodeList = structuredClone(currentListOfExcludedIds);
    const section = flatStructure.find(section => section.id === sectionId);
    section.isChecked = false;
    const allNewIds = getAllSectionIds(section, flatStructure);
    newNodeList = [...newNodeList, ...allNewIds];
    newNodeList = [...new Set(newNodeList)];
    return sortExcludeListByFlattenedSection(newNodeList, flatStructure);
}
function sortExcludeListByFlattenedSection(nodeList, flatStructure) {
    nodeList.sort((a, b) => {
        return flatStructure.findIndex(section => section.id === a) - flatStructure.findIndex(section => section.id === b);
    });
    return nodeList;
}
function getAllSectionIds(section, flatStructure) {
    let allChildIds = [];
    if (section.childrenIds?.length) {
        for (const id of section.childrenIds) {
            const childSection = flatStructure.find(section => section.id === id);
            const nestedIds = getAllSectionIds(childSection, flatStructure);
            allChildIds = [...allChildIds, ...nestedIds];
        }
    }
    return [section.id, ...allChildIds];
}
function toggleDisableInput(id, isChecked) {
    const uniqueSectionId = `licit-pdf-export-${id}`;
    const input = document.getElementById(uniqueSectionId);
    if (input) {
        input.disabled = isChecked;
    }
}
function deleteDocumentChildElements(startingIndex, sectionElements, storedStyles) {
    let nextSectionStyleName = sectionElements[startingIndex].attributes.getNamedItem('stylename')?.value ?? '';
    let nextElementLevel = getStyleLevel(nextSectionStyleName, storedStyles);
    while (!nextElementLevel && startingIndex < sectionElements.length) {
        sectionElements[startingIndex].remove();
        if (!sectionElements[startingIndex])
            break;
        nextSectionStyleName = sectionElements[startingIndex].attributes.getNamedItem('stylename')?.value ?? '';
        nextElementLevel = getStyleLevel(nextSectionStyleName, storedStyles);
    }
}
function getIndexBySectionName(collectionArray, styleName) {
    const nodeIndexs = [];
    for (const [index, element] of collectionArray.entries()) {
        if (element.attributes.getNamedItem('stylename')?.value === styleName) {
            nodeIndexs.push(index);
        }
    }
    return nodeIndexs;
}
