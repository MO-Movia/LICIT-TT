export function getTableStyles(documentStyles, styleKey) {
    return documentStyles
        .filter((style) => style?.styles?.[styleKey] === true)
        .map((style) => ({
        name: style.styleName,
        level: style.styles.styleLevel,
    }));
}
