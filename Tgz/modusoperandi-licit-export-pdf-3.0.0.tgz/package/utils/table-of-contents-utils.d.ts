export type StoredStyle = {
    name: string;
    level: number | string;
};
export type DocumentStyle = {
    description: string;
    docType?: string;
    isHidden: boolean;
    mode: number;
    otherStyleSelected: boolean;
    styleName: string;
    styles?: {
        align: string;
        boldNumbering: boolean;
        boldPartial: boolean;
        boldSentence: boolean;
        fontName: string;
        fontSize: string;
        isHidden: boolean;
        nextLineStyleName: boolean;
        styleLevel: string;
        toc: boolean;
        tof: boolean;
        tot: boolean;
    };
    toc: boolean;
};
export declare function getTableStyles(documentStyles: DocumentStyle[], styleKey: 'toc' | 'tof' | 'tot'): StoredStyle[];
