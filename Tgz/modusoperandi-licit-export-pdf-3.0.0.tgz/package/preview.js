import React from 'react';
import { Previewer, registerHandlers, registeredHandlers } from 'pagedjs';
import { PDFHandler } from './handlers';
import { createPopUp, atViewportCenter } from '@modusoperandi/licit-ui-commands';
import { Loader } from './loader';
import { buildSectionStructure, flattenStructure, toggleAllSectionChildElements, filterDocumentSections, buildListOfIdsToRemove, buildListOfIdsToAdd, } from './utils/document-section-utils';
import { getTableStyles, } from './utils/table-of-contents-utils';
import { ExportPDFCommand } from './exportPdfCommand';
export class PreviewForm extends React.PureComponent {
    static general = false;
    static formattedDate;
    static isToc = true;
    static isTof = true;
    static isTot = true;
    static isCitation = false;
    static isTitle = true;
    static lastUpdated = false;
    static tocHeader = [];
    static tofHeader = [];
    static totHeader = [];
    static tocNodeList = [];
    static tofNodeList = [];
    static totNodeList = [];
    sectionListElements = [];
    _popUp = null;
    static isGeneral() {
        return PreviewForm.general;
    }
    static showToc() {
        return PreviewForm.isToc;
    }
    static showTof() {
        return PreviewForm.isTof;
    }
    static showTot() {
        return PreviewForm.isTot;
    }
    static showTitle() {
        return PreviewForm.isTitle;
    }
    static showCitation() {
        return PreviewForm.isCitation;
    }
    static getHeadersTOC() {
        return [...this.tocHeader];
    }
    static getHeadersTOF() {
        return [...this.tofHeader];
    }
    static getHeadersTOT() {
        return [...this.totHeader];
    }
    constructor(props) {
        super(props);
        this.state = {
            sections: [],
            sectionNodeStructure: [],
            flattenedSectionNodeStructure: [],
            sectionNodesToExclude: [],
            storedStyles: [],
        };
    }
    componentDidMount() {
        const paged = new Previewer();
        this.showAlert();
        const { editorView } = this.props;
        this.getToc(editorView);
        PreviewForm.general = true;
        PreviewForm.isToc = true;
        PreviewForm.isTof = true;
        PreviewForm.isTot = true;
        PreviewForm.isTitle = true;
        if (!registeredHandlers.includes(PDFHandler)) {
            registerHandlers(PDFHandler);
        }
        const divContainer = document.getElementById('holder');
        const data = editorView.dom?.parentElement?.parentElement;
        if (!data || !divContainer)
            return;
        const data1 = data.cloneNode(true);
        this.replaceInfoIcons(data1);
        this.updateImageWidths(data1);
        this.prepareEditorContent(data1);
        this.updateTableWidths(data1);
        editorView.dispatch(editorView.state?.tr.setMeta('suppressOnChange', true));
        PDFHandler.state.isOnLoad = true;
        paged.preview(data1, [], divContainer).then(() => {
            PDFHandler.state.isOnLoad = false;
            this.calcLogic();
        });
    }
    showAlert() {
        const anchor = null;
        PDFHandler.state.currentPage = 0;
        this._popUp = createPopUp(Loader, null, {
            anchor,
            modal: true,
            autoDismiss: false,
            position: atViewportCenter,
            onClose: () => {
                if (this._popUp) {
                    this._popUp = null;
                }
            },
        });
    }
    replaceImageWidth = (imageElement, container) => {
        // Get the original width of the image.
        const originalWidth = Number.parseInt(imageElement.getAttribute('width'), 10);
        if (originalWidth <= 600)
            return;
        imageElement.style.maxWidth = '600px';
        const enhancedFigures = container.querySelectorAll('.enhanced-table-figure[data-type="enhanced-table-figure"]');
        for (const figure of enhancedFigures) {
            const contentDiv = figure.querySelector('.enhanced-table-figure-content');
            if (!contentDiv)
                continue;
            const hasEnhancedContent = contentDiv.classList.contains('enhanced-table-figure-content') ||
                contentDiv.querySelector('.enhanced-table-figure-content');
            if (hasEnhancedContent && originalWidth > 624) {
                // Rotate image if within enhanced figure
                imageElement.style.transform = 'rotate(-90deg)';
                imageElement.style.maxWidth = '575px';
                // Hide overflow in parent wrapper
                let parent = imageElement.parentElement;
                while (parent) {
                    if (parent.classList.contains('enhanced-table-figure')) {
                        parent.style.overflow = 'hidden';
                        break;
                    }
                    parent = parent.parentElement;
                }
                ;
            }
            ;
        }
        ;
    };
    replaceTableWidth = (tableElement) => {
        // Calculate total width from data-colwidth of first row
        const firstRow = tableElement.querySelector('tr');
        if (!firstRow)
            return;
        let totalWidth = 0;
        const cells = firstRow.querySelectorAll('td, th');
        for (const cell of cells) {
            const colWidthAttr = cell.dataset.colwidth;
            if (colWidthAttr) {
                totalWidth += Number(colWidthAttr);
            }
        }
        if (totalWidth > 600) {
            tableElement.style.maxWidth = '600px';
            // Rotate table 
            if (totalWidth > 624) {
                tableElement.style.transform = 'rotate(-90deg)';
                // Hide overflow in parent wrapper
                const targetClasses = ['enhanced-table-figure', 'enhanced-table-figure-content', 'tableWrapper', 'tablewrapper'];
                let parent = tableElement.parentElement;
                while (parent) {
                    if (targetClasses.some((cls) => parent.classList.contains(cls))) {
                        parent.style.overflow = 'hidden';
                        parent.style.overflowX = 'hidden';
                        parent.style.overflowY = 'hidden';
                    }
                    ;
                    parent = parent.parentElement;
                }
                ;
                // Set table height
                const tableHeight = tableElement.offsetHeight || totalWidth;
                tableElement.style.height = `${tableHeight}px`;
            }
            ;
        }
        ;
    };
    getToc = async (view) => {
        // Reset static lists
        PreviewForm.tocNodeList.length = 0;
        PreviewForm.tocHeader.length = 0;
        PreviewForm.tofNodeList.length = 0;
        PreviewForm.tofHeader.length = 0;
        PreviewForm.totNodeList.length = 0;
        PreviewForm.totHeader.length = 0;
        const styles = (await view.runtime.getStylesAsync());
        const storeTOCvalue = getTableStyles(styles, 'toc');
        const storeTOFvalue = getTableStyles(styles, 'tof');
        const storeTOTvalue = getTableStyles(styles, 'tot');
        view?.state?.tr?.doc.descendants((node) => {
            if (!node.attrs.styleName) {
                return;
            }
            for (const tofValue of storeTOFvalue) {
                if (tofValue.name === node.attrs.styleName) {
                    PreviewForm.tofNodeList.push(node);
                    PreviewForm.tofHeader.push(node.attrs.styleName);
                }
            }
            for (const totValue of storeTOTvalue) {
                if (totValue.name === node.attrs.styleName) {
                    PreviewForm.totNodeList.push(node);
                    PreviewForm.totHeader.push(node.attrs.styleName);
                }
            }
            for (const tocValue of storeTOCvalue) {
                if (tocValue.name === node.attrs.styleName) {
                    PreviewForm.tocNodeList.push(node);
                    PreviewForm.tocHeader.push(node.attrs.styleName);
                }
            }
        });
        const sectionNodeStructure = buildSectionStructure(PreviewForm.tocNodeList, storeTOCvalue);
        const flattenedSectionNodeStructure = flattenStructure(sectionNodeStructure);
        this.setState((prevState) => {
            return {
                ...prevState,
                storedStyles: storeTOCvalue,
                flattenedSectionNodeStructure,
                sectionNodeStructure,
            };
        });
        this.renderTocList(this.state.sectionNodeStructure);
    };
    updateDocumentSectionList(sectionId) {
        const flattenedSectionNodeStructure = this.state.flattenedSectionNodeStructure;
        let newNodeList = [];
        if (this.state.sectionNodesToExclude.includes(sectionId)) {
            newNodeList = buildListOfIdsToAdd(sectionId, this.state.sectionNodesToExclude, flattenedSectionNodeStructure);
        }
        else {
            toggleAllSectionChildElements(flattenedSectionNodeStructure, sectionId, true);
            newNodeList = buildListOfIdsToRemove(sectionId, this.state.sectionNodesToExclude, flattenedSectionNodeStructure);
        }
        this.setState((prevState) => {
            return {
                ...prevState,
                sectionNodesToExclude: newNodeList,
            };
        }, () => { });
    }
    render() {
        const getButtonStyle = (color) => ({
            backgroundColor: color,
            color: '#fff',
            border: 'none',
            borderRadius: '6px',
            padding: '8px 16px',
            fontSize: '14px',
            fontWeight: 500,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
        });
        const handleHover = (e, bg, shadow) => {
            e.currentTarget.style.backgroundColor = bg;
            e.currentTarget.style.boxShadow = shadow;
        };
        return (React.createElement("div", { style: {
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
            } },
            React.createElement("div", { style: { border: 'solid', visibility: 'hidden' }, className: "exportpdf-preview-container" },
                React.createElement("div", { style: { display: 'flex', flexDirection: 'row' } },
                    React.createElement("div", { id: "holder", className: "preview-container", style: {
                            height: '90vh',
                            width: 'auto',
                            overflowY: 'auto',
                        } }),
                    React.createElement("div", { style: {
                            height: '90vh',
                            background: 'rgb(226 226 226)',
                            position: 'relative',
                        } },
                        React.createElement("div", { style: { padding: '20px', color: '#000000' } },
                            React.createElement("h6", null, "Options:"),
                            React.createElement("div", { style: {
                                    marginTop: '10px',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                } },
                                React.createElement("div", null,
                                    React.createElement("input", { type: "checkbox", name: "TOC", id: "licit-pdf-export-toc-option", onChange: this.handleTOCChange, defaultChecked: true }),
                                    ' '),
                                React.createElement("label", { htmlFor: "licit-pdf-export-toc-option", style: { marginLeft: '5px' } }, "Include TOC")),
                            React.createElement("div", { style: {
                                    marginTop: '10px',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                } },
                                React.createElement("div", null,
                                    React.createElement("input", { type: "checkbox", name: "TOF", id: "licit-pdf-export-tof-option", onChange: this.handleTOFChange, defaultChecked: true }),
                                    ' '),
                                React.createElement("label", { htmlFor: "licit-pdf-export-tof-option", style: { marginLeft: '5px' } }, "Include TOF")),
                            React.createElement("div", { style: {
                                    marginTop: '10px',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                } },
                                React.createElement("div", null,
                                    React.createElement("input", { type: "checkbox", name: "TOT", id: "licit-pdf-export-tot-option", onChange: this.handleTOTChange, defaultChecked: true }),
                                    ' '),
                                React.createElement("label", { htmlFor: "licit-pdf-export-tot-option", style: { marginLeft: '5px' } }, "Include TOT")),
                            React.createElement("div", { style: {
                                    marginTop: '8px',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                } },
                                React.createElement("div", null,
                                    React.createElement("input", { type: "checkbox", name: "infoicon", id: "licit-pdf-export-title-option", onChange: this.handelDocumentTitle, defaultChecked: true }),
                                    ' '),
                                React.createElement("label", { htmlFor: "licit-pdf-export-title-option", style: { marginLeft: '5px' } }, "Document title")),
                            React.createElement("div", { style: {
                                    marginTop: '8px',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                } },
                                React.createElement("div", null,
                                    React.createElement("input", { type: "checkbox", name: "infoicon", id: "licit-pdf-export-citation-option", onChange: this.handelCitation }),
                                    ' '),
                                React.createElement("label", { htmlFor: "licit-pdf-export-citation-option", style: { marginLeft: '5px' } }, "Citation")),
                            React.createElement("div", { style: {
                                    marginTop: '8px',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                } },
                                React.createElement("div", null,
                                    React.createElement("input", { type: "checkbox", name: "infoicon", id: "licit-pdf-export-last-updated-option", onClick: this.handleLastUpdated }),
                                    ' '),
                                React.createElement("label", { htmlFor: "licit-pdf-export-citation-option", style: { marginLeft: '5px' } }, "Last updated")),
                            React.createElement("h6", { style: { marginRight: 'auto', marginTop: '30px' } }, "Document Sections:"),
                            React.createElement("div", { key: "{this.props.sections}", id: "licit-pdf-export-sections-list", style: {
                                    borderRadius: '5px',
                                    marginTop: '10px',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'flex-start',
                                    background: '#fff',
                                    width: '300px',
                                    maxHeight: '200px',
                                    overflowY: 'auto',
                                    overflowX: 'auto',
                                    paddingLeft: '10px',
                                    boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                    border: '1px solid #ccc',
                                } }, this.state.sections)),
                        React.createElement("div", { style: {
                                marginTop: '8px',
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                paddingLeft: '20px',
                            } },
                            React.createElement("button", { onClick: this.handleApply, style: getButtonStyle('#4CAF50'), onMouseEnter: e => handleHover(e, '#45a049', '0 4px 8px rgba(0,0,0,0.25)'), onMouseLeave: e => handleHover(e, '#4CAF50', '0 2px 4px rgba(0,0,0,0.2)') }, "Apply")),
                        React.createElement("div", { style: {
                                position: 'absolute',
                                bottom: '0',
                                right: '0',
                                padding: '5px',
                                display: 'flex',
                                flexDirection: 'row',
                                gap: '10px',
                            } },
                            React.createElement("button", { onClick: this.handleConfirm, style: getButtonStyle('#4CAF50'), onMouseEnter: e => handleHover(e, '#45a049', '0 4px 8px rgba(0,0,0,0.25)'), onMouseLeave: e => handleHover(e, '#4CAF50', '0 2px 4px rgba(0,0,0,0.2)') }, "Confirm"),
                            React.createElement("button", { onClick: this.handleCancel, style: getButtonStyle('#f44336'), onMouseEnter: e => handleHover(e, '#d32f2f', '0 4px 8px rgba(0,0,0,0.25)'), onMouseLeave: e => handleHover(e, '#f44336', '0 2px 4px rgba(0,0,0,0.2)') }, "Cancel")))))));
    }
    handelDocumentTitle = (event) => {
        if (event.target.checked) {
            this.documentTitleActive();
        }
        else {
            this.documentTitleDeactive();
        }
    };
    handleLastUpdated = (event) => {
        if (event.target.checked) {
            this.lastUpdatedActive();
        }
        else {
            this.lastUpdatedDeactive();
        }
    };
    handelCitation = (e) => {
        if (e.target.checked) {
            this.citationActive();
        }
        else {
            this.citationDeactive();
        }
    };
    handleTOCChange = (event) => {
        if (event.target.checked) {
            this.tocActive();
        }
        else {
            this.Tocdeactive();
        }
    };
    handleTOTChange = (event) => {
        if (event.target.checked) {
            this.totActive();
        }
        else {
            this.Totdeactive();
        }
    };
    handleTOFChange = (event) => {
        if (event.target.checked) {
            this.tofActive();
        }
        else {
            this.Tofdeactive();
        }
    };
    documentTitleActive = () => {
        PreviewForm.isTitle = true;
    };
    documentTitleDeactive = () => {
        PreviewForm.isTitle = false;
    };
    lastUpdatedActive = () => {
        PreviewForm.lastUpdated = true;
    };
    lastUpdatedDeactive = () => {
        PreviewForm.lastUpdated = false;
    };
    citationActive = () => {
        PreviewForm.isCitation = true;
    };
    insertFooters = (CitationIcons, trialHtml) => {
        const selector = trialHtml.querySelector('.ProseMirror');
        if (CitationIcons.length > 0) {
            for (let i = 0; i < 7; i++) {
                if (i === 4) {
                    const citation_header = document.createElement('h4');
                    citation_header.textContent = 'Endnotes';
                    citation_header.style.color = 'blue';
                    citation_header.setAttribute('stylename', PreviewForm.tocHeader[0]);
                    selector.appendChild(citation_header);
                }
                else if (i === 5) {
                    const underline = document.createElement('div');
                    underline.style.width = '350px';
                    underline.style.height = '1px';
                    underline.style.marginTop = '-5px';
                    underline.style.backgroundColor = '#000000';
                    selector.appendChild(underline);
                }
                else {
                    const blankDiv = document.createElement('div');
                    selector.appendChild(blankDiv);
                    const nbsp = document.createTextNode('\u00A0');
                    selector.appendChild(nbsp);
                }
            }
        }
        CitationIcons.forEach((CitationIcon, index) => {
            const description = CitationIcon.getAttribute('overallcitationcapco') +
                ' ' +
                CitationIcon.getAttribute('author') +
                ' ' +
                CitationIcon.getAttribute('referenceId') +
                ' ' +
                'Date Published' +
                ' ' +
                CitationIcon.getAttribute('publisheddate') +
                ' ' +
                'ICOD Date' +
                ' ' +
                CitationIcon.getAttribute('icod') +
                ' ' +
                CitationIcon.getAttribute('documenttitlecapco') +
                ' ' +
                CitationIcon.getAttribute('documenttitle') +
                ' ' +
                'pp.' +
                ' ' +
                CitationIcon.getAttribute('pages') +
                ' ' +
                'Extracted information is' +
                ' ' +
                CitationIcon.getAttribute('extractedinfocapco') +
                ' ' +
                'Overall document classification is' +
                ' ' +
                CitationIcon.getAttribute('overalldocumentcapco') +
                ' ' +
                'Data Accessed' +
                ' ' +
                CitationIcon.getAttribute('dateaccessed') +
                ' ' +
                CitationIcon.getAttribute('hyperlink') +
                ' ' +
                'Declasify Date' +
                ' ' +
                CitationIcon.getAttribute('declassifydate');
            const newDiv = document.createElement('div');
            const indexSpan = document.createElement('span');
            indexSpan.textContent = `[${index + 1}]`;
            indexSpan.style.fontSize = '80%';
            const spaceTextNode = document.createTextNode('  ');
            const descriptionSpan = document.createElement('span');
            descriptionSpan.textContent = description;
            descriptionSpan.style.fontSize = '80%';
            // Append the span elements to the new div
            newDiv.appendChild(indexSpan);
            newDiv.appendChild(spaceTextNode);
            newDiv.appendChild(descriptionSpan);
            selector.appendChild(newDiv);
        });
    };
    citationDeactive = () => {
        PreviewForm.isCitation = false;
    };
    cloneModifyNode = (data) => {
        return data.cloneNode(true);
    };
    addLinkEventListeners = () => {
        const links = document.querySelectorAll('.exportpdf-preview-container a');
        links.forEach((link) => {
            link.addEventListener('click', this.handleLinkClick);
        });
    };
    handleLinkClick = (event) => {
        const link = event.currentTarget;
        const href = link.getAttribute('href');
        const selectionId = link.getAttribute('selectionid');
        // Skip if no href
        if (!href)
            return;
        if (this.isExternalLink(href) && !selectionId) {
            event.preventDefault();
            this.openExternalLink(href);
        }
        else {
            event.preventDefault();
            this.scrollToInternalTarget(href, selectionId);
        }
    };
    // Check if a link is external if it startsWith http:// ,https:// or mailto:
    isExternalLink = (href) => {
        return href.startsWith('http://') || href.startsWith('https://') || href.startsWith('mailto:');
    };
    // Open external links safely
    openExternalLink = (href) => {
        globalThis.open(href, '_blank', 'noopener,noreferrer');
    };
    // Scroll to internal target
    scrollToInternalTarget = (href, selectionId) => {
        let targetElement = null;
        // Check if href is an ID (starts with #) or a selectionId (starts with #)
        // For TOC links, href will be like #id for internal links selectionId will be like #id
        if (href?.startsWith('#')) {
            const targetId = href.slice(1);
            targetElement = document.getElementById(targetId);
        }
        else if (selectionId?.startsWith('#')) {
            const targetId = selectionId.slice(1);
            const container = document.querySelector('.exportpdf-preview-container');
            if (!container)
                return;
            targetElement = container.querySelector(`p[selectionid="#${CSS.escape(targetId)}"]`);
        }
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth' });
        }
    };
    calcLogic = () => {
        const divContainer = document.getElementById('holder');
        if (!divContainer)
            return;
        divContainer.innerHTML = '';
        const { editorView } = this.props;
        const data = editorView.dom?.parentElement?.parentElement;
        if (!data)
            return;
        let data1 = this.cloneModifyNode(data);
        this.prepareEditorContent(data1);
        data1 = filterDocumentSections(data1, PreviewForm.tocNodeList, this.state.sectionNodesToExclude, this.state.storedStyles);
        if (PreviewForm.isCitation) {
            this.replaceCitations(data1);
        }
        if (PreviewForm.lastUpdated) {
            this.setLastUpdated(editorView);
        }
        this.insertSectionHeaders(data1, editorView);
        this.replaceInfoIcons(data1);
        this.updateImageWidths(data1);
        this.updateTableWidths(data1);
        const paged = new Previewer();
        this._popUp?.close();
        this.showAlert();
        editorView.dispatch(editorView.state.tr?.setMeta('suppressOnChange', true));
        paged.preview(data1, [], divContainer).then(() => {
            const previewContainer = document.querySelector('.exportpdf-preview-container');
            if (previewContainer)
                previewContainer.style.visibility = 'visible';
            this.addLinkEventListeners();
            this._popUp?.close();
        });
    };
    prepareEditorContent(data) {
        const proseMirror = data.querySelector('.ProseMirror');
        if (proseMirror) {
            proseMirror.setAttribute('contenteditable', 'false');
            proseMirror.classList.remove('czi-prosemirror-editor');
            proseMirror.querySelectorAll('.molm-czi-image-view-body-img-clip span').forEach(span => {
                span.style.display = 'flex';
            });
        }
    }
    replaceCitations(data) {
        const citations = data.querySelectorAll('.citationnote');
        citations.forEach((el, idx) => {
            const sup = document.createElement('sup');
            sup.textContent = `[${idx + 1}]`;
            el.parentNode?.replaceChild(sup, el);
        });
        this.insertFooters(citations, data);
    }
    setLastUpdated(editorView) {
        const lastEdited = editorView?.state?.doc?.attrs?.objectMetaData?.lastEditedOn;
        const date = new Date(lastEdited);
        PreviewForm.formattedDate = date.toLocaleString('en-GB', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false,
        });
    }
    insertSectionHeaders(data, editorView) {
        data.querySelectorAll('.titleHead, .forcePageSpacer, .tocHead, .tofHead, .totHead')
            .forEach(n => n.remove());
        let insertBeforeNode = data.firstChild;
        if (PreviewForm.isTitle) {
            const titleDiv = document.createElement('div');
            titleDiv.classList.add('titleHead', 'prepages');
            const header = document.createElement('h4');
            header.style.marginBottom = '40px';
            header.style.color = '#2A6EBB';
            header.style.textAlign = 'center';
            header.style.fontWeight = 'bold';
            header.textContent = editorView?.state?.doc?.attrs?.objectMetaData?.name ?? 'Untitled';
            titleDiv.appendChild(header);
            insertBeforeNode?.before(titleDiv);
            insertBeforeNode = titleDiv.nextSibling;
            const titleSpacer = document.createElement('div');
            titleSpacer.classList.add('forcePageSpacer');
            titleSpacer.innerHTML = '&nbsp;';
            insertBeforeNode?.before(titleSpacer);
            insertBeforeNode = titleSpacer.nextSibling;
        }
        const sections = [
            { flag: PreviewForm.isToc, className: 'tocHead' },
            { flag: PreviewForm.isTof, className: 'tofHead' },
            { flag: PreviewForm.isTot, className: 'totHead' }
        ];
        sections.forEach(({ flag, className }) => {
            if (!flag)
                return;
            const sectionDiv = document.createElement('div');
            sectionDiv.classList.add(className);
            insertBeforeNode?.before(sectionDiv);
            insertBeforeNode = sectionDiv.nextSibling;
            const sectionSpacer = document.createElement('div');
            sectionSpacer.classList.add('forcePageSpacer');
            sectionSpacer.innerHTML = '&nbsp;';
            insertBeforeNode?.before(sectionSpacer);
            insertBeforeNode = sectionSpacer.nextSibling;
        });
    }
    replaceInfoIcons(data) {
        const icons = data.querySelectorAll('.infoicon');
        icons.forEach((icon, index) => {
            const sup = document.createElement('sup');
            sup.textContent = `${index + 1}`;
            icon.textContent = '';
            icon.appendChild(sup);
        });
    }
    updateImageWidths(data) {
        for (const element of data.children) {
            const images = element.querySelectorAll('img');
            images.forEach((img) => {
                this.replaceImageWidth(img, data);
            });
        }
    }
    updateTableWidths(data) {
        for (const element of data.children) {
            const tables = element.querySelectorAll('table');
            for (const table of tables) {
                this.replaceTableWidth(table);
            }
        }
    }
    tocActive = () => {
        PreviewForm.isToc = true;
    };
    tofActive = () => {
        PreviewForm.isTof = true;
    };
    totActive = () => {
        PreviewForm.isTot = true;
    };
    Tocdeactive = () => {
        PreviewForm.isToc = false;
    };
    Tofdeactive = () => {
        PreviewForm.isTof = false;
    };
    Totdeactive = () => {
        PreviewForm.isTot = false;
    };
    handleCancel = () => {
        PreviewForm.isToc = false;
        PreviewForm.isTof = false;
        PreviewForm.isTot = false;
        PreviewForm.general = false;
        PreviewForm.isTitle = false;
        PreviewForm.isCitation = false;
        ExportPDFCommand.closePreviewForm();
        this.props.onClose();
    };
    handleConfirm = () => {
        const printWindow = window.open('', '_blank');
        if (printWindow) {
            let divContainer = document.getElementById('holder');
            printWindow.document.open();
            printWindow.document.writeln('<!DOCTYPE html><html><body></body></html>');
            while (printWindow.document.documentElement.firstChild) {
                printWindow.document.documentElement.removeChild(printWindow.document.documentElement.firstChild);
            }
            for (const childNode of divContainer.childNodes) {
                printWindow.document.documentElement.appendChild(childNode.cloneNode(true));
            }
            printWindow.document.documentElement.appendChild(document.createElement('head'));
            this.prepareCSSRules(printWindow.document);
            printWindow.document.title = 'LICIT';
            printWindow.document.close();
            printWindow.print();
        }
        ExportPDFCommand.closePreviewForm();
        this.props.onClose();
    };
    handleApply = () => {
        this.calcLogic();
    };
    prepareCSSRules = (doc) => {
        const sheets = document.styleSheets;
        for (const sheet of sheets) {
            const rules = sheet.cssRules;
            const styles = [];
            const styleElement = doc.createElement('style');
            for (const rule of rules) {
                styles.push(rule.cssText);
                const attributes = sheet.ownerNode?.attributes;
                for (const attribute of attributes ?? []) {
                    styleElement?.setAttribute(attribute.name, attribute.value);
                }
            }
            const styleText = styles.join('\n');
            styleElement.textContent = styleText;
            doc.head.appendChild(styleElement);
        }
    };
    renderTocList(structure, isChildElement = false) {
        for (const section of structure) {
            const uniqueSectionId = `licit-pdf-export-${section.id}`;
            const indentIncrement = 15;
            let indentAmount = '0';
            if (section.level > 1) {
                indentAmount = `${(section.level - 1) * indentIncrement}px`;
            }
            this.sectionListElements.push(React.createElement("div", { key: section.id, style: {
                    padding: '5px 10px',
                    paddingLeft: indentAmount,
                    display: 'flex',
                    flexDirection: 'row',
                    flexWrap: 'nowrap',
                    alignItems: 'center',
                    minWidth: '100%',
                    width: 'auto',
                    borderBottom: '1px solid #e0e0e0',
                    backgroundColor: '#fff',
                    transition: 'background 0.2s',
                } },
                React.createElement("div", null,
                    React.createElement("input", { style: { cursor: 'pointer' }, type: "checkbox", name: "infoicon", id: uniqueSectionId, value: "on", onChange: () => this.updateDocumentSectionList(section.id), defaultChecked: true }),
                    ' '),
                React.createElement("label", { htmlFor: uniqueSectionId, style: { cursor: 'pointer', marginLeft: '5px', textWrap: 'nowrap' } }, section.title)));
            if (section.children.length) {
                this.renderTocList(section.children, true);
            }
        }
        if (!isChildElement) {
            this.setState((prevState) => {
                return { ...prevState, sections: this.sectionListElements };
            });
        }
    }
}
