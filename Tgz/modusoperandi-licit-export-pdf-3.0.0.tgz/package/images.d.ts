declare const DarkThemeIcon = "assets/images/dark/Icon_pdf.svg";
declare const LightThemeIcon = "assets/images/light/Icon_pdf.svg";
export { DarkThemeIcon, LightThemeIcon };
