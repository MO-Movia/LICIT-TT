import * as React from 'react';
export declare class Loader extends React.PureComponent {
    private interval;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): React.ReactElement;
}
