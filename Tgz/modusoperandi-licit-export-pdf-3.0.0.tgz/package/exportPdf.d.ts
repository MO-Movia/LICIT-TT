import { EditorView } from 'prosemirror-view';
export declare class ExportPDF {
    private _popUp;
    /**
     * Export content to pdf and save locally.
     * @param  {EditorView} view
     * @returns boolean
     */
    exportPdf(view: EditorView, doc: unknown): boolean;
}
export declare function createTable(config: any): void;
