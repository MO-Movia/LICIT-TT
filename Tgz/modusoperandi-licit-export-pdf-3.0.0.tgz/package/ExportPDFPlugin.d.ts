import { Schema } from 'prosemirror-model';
import { Plugin } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
export declare const KEY_EXPORT_PDF: any;
export declare class ExportPDFPlugin extends Plugin {
    showButton: boolean;
    constructor(showButton: boolean);
    getEffectiveSchema(schema: Schema): Schema;
    initKeyCommands(): unknown;
    initButtonCommands(theme: string): unknown;
    /**
     * @deprecated Use ExportPDFPlugin.export(view) instead.
     */
    perform(view: EditorView): boolean;
    static export(view: EditorView): boolean;
}
