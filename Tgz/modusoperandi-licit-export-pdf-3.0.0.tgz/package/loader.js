import * as React from 'react';
import { PDFHandler } from './handlers';
export class Loader extends React.PureComponent {
    interval;
    componentDidMount() {
        // trigger update of static values
        this.interval = setInterval(() => this.setState({ time: Date.now() }), 1000);
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    render() {
        return (React.createElement("div", { className: "epdf-loader-fullscreen" },
            React.createElement("img", { className: "epdf-loader-image", src: "assets/images/modus-loading.gif", alt: "Loading..." }),
            React.createElement("span", null,
                "Parsing section ",
                PDFHandler.state.currentPage,
                "...")));
    }
}
